"""
printer.py
----------
Builds a plain-text receipt sized for a 3-inch (58mm/72mm) thermal
printer and sends it as a RAW print job on Windows. On non-Windows
systems (or if no printer is found) it just saves the receipt as a
.txt file so you can still test the layout.

Also includes save_pdf_receipt() which writes the same bill out as a
proper .pdf file - built by hand with NO external library required
(works fully offline, forever).

NOTE: This app's own window/title is kept generic ("Billing Software")
so it can be used as a general-purpose billing tool. The shop details
below are what actually get printed / saved on every bill, so the
receipt itself always shows your shop's name.
"""

import os
import sys
import textwrap
import unicodedata

SHOP_NAME = "SAKTHI STORES"
SHOP_PHONE = "Ph: 9944993944"
SHOP_ADDRESS = "Bhuvanagiri"
# Shop's own GSTIN. Printed on the bill only when this is non-empty -
# left blank (the default) it is skipped entirely, so shops without a
# GSTIN never get a blank/placeholder line on their receipts.
SHOP_GSTIN = ""
LINE_WIDTH = 48  # 48 chars fits a standard 80mm (3-inch) thermal roll


# ---------------------------------------------------------------------
# Tamil (and other Indic script) text is made of a BASE letter followed
# by one or more COMBINING marks (vowel signs, virama/pulli, etc.) -
# e.g. "மி" is 2 separate Unicode codepoints (ம + ி) but is drawn/read
# as ONE letter. Python's len()/textwrap count every codepoint
# separately, so a Tamil word can measure as much longer than it
# visually is. That was causing item names to wrap too early, and the
# Qty/Rate/Amt numbers to land in the wrong spot instead of lining up
# under their headers. The helpers below measure/wrap/pad text by
# visual letter ("grapheme cluster") instead, so Tamil and English
# text both line up correctly using the same column math.
# ---------------------------------------------------------------------

def _graphemes(text):
    """Split text into visual letters: each combining mark is glued onto
    the base letter before it, so a Tamil letter cluster counts as 1."""
    clusters = []
    cur = ""
    for ch in text:
        if cur and unicodedata.category(ch) in ("Mn", "Mc", "Me"):
            cur += ch
        else:
            if cur:
                clusters.append(cur)
            cur = ch
    if cur:
        clusters.append(cur)
    return clusters


def _vlen(text):
    """Visual length of text (counts combined Tamil letters as 1 each)."""
    return len(_graphemes(text))


def _vpad(text, width):
    """Left-align text, padding with spaces based on VISUAL length so it
    lines up correctly even when text contains Tamil combining marks."""
    pad = max(0, width - _vlen(text))
    return text + (" " * pad)


def _vwrap(text, width):
    """Word-wrap text to `width` VISUAL columns (Tamil-safe). Behaves
    like textwrap.wrap(..., break_long_words=False): a single word
    longer than width is kept whole on its own line rather than being
    sliced apart mid-letter."""
    words = text.split(" ")
    lines = []
    cur = ""
    for w in words:
        if not w:
            continue
        candidate = f"{cur} {w}" if cur else w
        if not cur or _vlen(candidate) <= width:
            cur = candidate
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [text]


def build_receipt_text(bill_no, bill_date, customer_name, contact, items, grand_total, paid, gst_amount=0,
                        amount_received=0, balance=0, gstin="", hsn_code=""):
    line = "-" * LINE_WIDTH
    out = []
    out.append(SHOP_NAME.center(LINE_WIDTH))
    out.append(SHOP_ADDRESS.center(LINE_WIDTH))
    out.append(SHOP_PHONE.center(LINE_WIDTH))
    # Shop's own GSTIN - only printed when set in Settings; skipped
    # entirely (no blank line) when the shop hasn't configured one.
    if SHOP_GSTIN:
        out.append(f"GSTIN: {SHOP_GSTIN}".center(LINE_WIDTH))
    out.append(line)
    
    # Parse date and time from bill_date
    parts = bill_date.split(" ")
    only_date = parts[0]
    only_time = parts[1][:5] if len(parts) > 1 else ""

    # Row 1: Bill No & Date (Horizontal)
    bill_str = f"Bill No: {bill_no}"
    date_str = f"Date: {only_date}"
    spaces_needed = LINE_WIDTH - len(bill_str) - len(date_str)
    if spaces_needed < 1:
        spaces_needed = 1
    out.append(f"{bill_str}{' ' * spaces_needed}{date_str}")

    # Row 2: Customer & Time (Horizontal)
    cust_val = customer_name or "Walk-in"
    cust_str = f"Cust: {cust_val}"
    if only_time:
        time_str = f"Time: {only_time}"
        max_cust_len = LINE_WIDTH - len(time_str) - 8
        if len(cust_val) > max_cust_len:
            cust_str = f"Cust: {cust_val[:max_cust_len]}"
        spaces_needed = LINE_WIDTH - len(cust_str) - len(time_str)
        if spaces_needed < 1:
            spaces_needed = 1
        out.append(f"{cust_str}{' ' * spaces_needed}{time_str}")
    else:
        out.append(cust_str)
        
    out.append(line)
    GAP = 2  # 2-space gap before each number column
    qty_strs = [f"{it['qty']:g}" for it in items]
    price_strs = [f"{it['price']:.2f}" for it in items]
    total_strs = [f"{it['total']:.2f}" for it in items]
    # 4 characters is the minimum/default width for each number column
    # (as requested), but if any actual Qty/Rate/Amt in this bill needs
    # more room than that (e.g. a total like "90.00"), the column grows
    # just enough to fit it. Without this, a wider number would overflow
    # past the paper's width and wrap onto the next line.
    qty_w = max([4] + [len(s) for s in qty_strs])
    rate_w = max([4] + [len(s) for s in price_strs])
    amt_w = max([4] + [len(s) for s in total_strs])
    # This is just used to line the "Item" header up with where Qty/
    # Rate/Amt start - the item NAME itself below gets the FULL line
    # width (see the loop), it doesn't have to squeeze into this.
    header_item_col = LINE_WIDTH - (qty_w + rate_w + amt_w) - (GAP * 3)
    GAP_STR = " " * GAP
    out.append(f"{'Item':<{header_item_col}}{GAP_STR}{'Qty':>{qty_w}}{GAP_STR}{'Rate':>{rate_w}}{GAP_STR}{'Amt':>{amt_w}}")
    out.append(line)
    for it in items:
        name = (it.get("product_name") or "").strip() or "-"
        qty = f"{it['qty']:g}"
        price = f"{it['price']:.2f}"
        total = f"{it['total']:.2f}"
        # Qty/Rate/Amt always stay on the SAME line as the item name -
        # they are never pushed onto their own line. The name is wrapped
        # to fit the item column (header_item_col) so it lines up with
        # the "Item" header above; only the item name itself may spill
        # onto extra line(s) below when it's too long to fit in that
        # column - those extra lines contain ONLY the leftover name text,
        # nothing from the Qty/Rate/Amt columns. A Tamil letter (built
        # from multiple combining characters) is never sliced apart
        # mid-way either, since wrapping only happens at word boundaries.
        wrapped = _vwrap(name, header_item_col)
        first_line, rest_lines = wrapped[0], wrapped[1:]
        out.append(f"{_vpad(first_line, header_item_col)}{GAP_STR}{qty:>{qty_w}}{GAP_STR}{price:>{rate_w}}{GAP_STR}{total:>{amt_w}}")
        for extra in rest_lines:
            out.append(extra)
    out.append(line)
    subtotal = grand_total - (gst_amount or 0)
    if gst_amount:
        out.append(f"{'Sub Total':<20}{subtotal:>12.2f}")
        out.append(f"{'GST':<20}{gst_amount:>12.2f}")
        if hsn_code:
            out.append(f"HSN/SAC: {hsn_code}")
        if gstin:
            out.append(f"GSTIN: {gstin}")
    out.append(f"{'GRAND TOTAL':<20}{grand_total:>12.2f}")
    # Amount paid / balance (change to give back, or amount still due) -
    # only shown when the shopkeeper actually entered a received amount.
    if amount_received:
        out.append(line)
        out.append(f"{'Amount Received':<20}{amount_received:>12.2f}")
        if balance >= 0:
            out.append(f"{'Balance (to give)':<20}{balance:>12.2f}")
        else:
            out.append(f"{'Balance Due':<20}{-balance:>12.2f}")
    out.append(line)
    out.append(("PAID" if paid == "Paid" else "NOT PAID").center(LINE_WIDTH))
    out.append("Thank you! Visit Again".center(LINE_WIDTH))
    out.append("\n\n\n")
    return "\n".join(out)


# ---------------------------------------------------------------------
# IMAGE-BASED RECEIPT (pixel-perfect "invisible table")
# ---------------------------------------------------------------------
# The plain-text version above lines things up by COUNTING characters,
# which only works if every character is drawn at exactly the same
# width. Tamil letters are not the same pixel width as English letters
# in almost any font/printer, so character-counting can never guarantee
# Qty/Rate/Amt land under their headers when the row also has Tamil
# text on it.
#
# This function sidesteps that entirely: it draws the receipt as an
# actual image, with each column (Item / Qty / Rate / Amt) given a
# fixed PIXEL slot - like a table, just with no visible border lines.
# Text is placed by its real measured pixel width (via PIL), so English
# and Tamil always land in exactly the right spot, no matter how the
# font renders each script. This same image is used both for actual
# thermal printing (as a raster/bitmap print job) and for the PDF
# export, so preview, PDF and printout all match exactly.
# ---------------------------------------------------------------------

PAPER_WIDTH_PX = 576  # 80mm (3 inch) thermal roll at ~203dpi. Use 384 for a 58mm roll.


# ---------------------------------------------------------------------
# Why "மேரி" was coming out scrambled in the PDF
# ---------------------------------------------------------------------
# Tamil vowel signs like the one in "மே" (ம + a vowel-sign codepoint)
# are TYPED/STORED after the consonant, but must be DRAWN to its LEFT.
# Pillow only does that repositioning correctly when its "raqm" text-
# shaping engine is available. The code already asked for RAQM
# (layout_engine=ImageFont.Layout.RAQM) - but if raqm isn't actually
# installed on this PC, Pillow does NOT raise an error, it just quietly
# falls back to drawing the letters in raw storage order. That silent
# fallback is exactly what produced the scrambled "மேரி" in the PDF/
# preview - the letters were all there, just in the wrong visual order.
# _has_raqm() checks for this directly (instead of hoping an exception
# gets thrown) and _tamil_visual_reorder() fixes the ordering by hand
# whenever raqm turns out to be missing, so the text is correct either
# way.
# ---------------------------------------------------------------------

_RAQM_CACHE = {"value": None}


def _has_raqm():
    if _RAQM_CACHE["value"] is None:
        try:
            from PIL import features
            _RAQM_CACHE["value"] = bool(features.check("raqm"))
        except Exception:
            _RAQM_CACHE["value"] = False
    return _RAQM_CACHE["value"]


def _shaping_warning():
    """No longer shown to the shopkeeper (the Print/Save popup used to
    show a technical paragraph here about the 'raqm' shaping engine -
    removed on request, since it was confusing on the shop floor). The
    detection itself (_has_raqm) is still used internally below so the
    app still auto-corrects what it can without raqm; this function now
    always returns "" so the popup just shows the plain save/print
    message."""
    return ""


# Tamil vowel signs that are stored AFTER their consonant but drawn
# BEFORE it (the "pre-base" left-side signs): எ/ே/ை.
# NOTE: ொ/ோ/ௌ (U+0BCA/0BCB/0BCC) are NOT included here even though they
# LOOK pre-base too - they're actually TWO visual pieces (a left part +
# a right part straddling the consonant), so moving the whole character
# to the front (what this code used to do) is wrong - it would drag the
# right-side part along with it instead of leaving it after the
# consonant. _tamil_visual_reorder() below decomposes them with
# unicodedata.normalize("NFD", ...) into their two real pieces first
# (e.g. ொ -> ெ + ா), then only the left piece gets moved - so both
# halves land in their correct spot without needing raqm at all.
_TAMIL_PREBASE_VOWELS = "\u0bc6\u0bc7\u0bc8"


def _tamil_visual_reorder(text):
    """Move each pre-base Tamil vowel sign to just before the consonant
    it belongs to. No-op when raqm is available (raqm already handles
    this correctly on its own) or when text has no such marks."""
    if not text or _has_raqm():
        return text
    text = unicodedata.normalize("NFD", text)
    out = []
    for ch in text:
        if ch in _TAMIL_PREBASE_VOWELS and out:
            prev = out.pop()
            out.append(ch)
            out.append(prev)
        else:
            out.append(ch)
    return "".join(out)


def build_receipt_image(bill_no, bill_date, customer_name, contact, items, grand_total, paid, gst_amount=0,
                         amount_received=0, balance=0, gstin="", hsn_code=""):
    """Render the whole receipt as a PIL Image, laid out as a real
    pixel-column table (Item | Qty | Rate | Amt) with no visible
    borders. Returns a PIL Image, or None if Pillow isn't installed."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return None

    MARGIN = 8
    FS = 18        # body text size (px) - smaller, compact receipt
    FS_SHOP = 20   # shop name / address / phone size (px)
    FS_SHOP_NAME = FS_SHOP + 2  # shop name only, bumped +2pt on request
    COL_GAP = 12   # gap between table columns (px)
    LINE_GAP = 4   # extra gap below each text line (px)
    MIN_NAME_FS = 10  # never shrink an item name smaller than this

    font_path = _find_tamil_font()
    _font_cache = {}

    def load_font(size):
        if size in _font_cache:
            return _font_cache[size]
        if font_path:
            try:
                f = ImageFont.truetype(font_path, size, layout_engine=ImageFont.Layout.RAQM)
            except Exception:
                f = ImageFont.truetype(font_path, size)
        else:
            f = ImageFont.load_default(size)
        _font_cache[size] = f
        return f

    font = load_font(FS)
    font_shop = load_font(FS_SHOP)
    font_shop_name = load_font(FS_SHOP_NAME)

    scratch = Image.new("RGB", (10, 10))
    d = ImageDraw.Draw(scratch)

    def tw(text, f=font):
        return d.textlength(_tamil_visual_reorder(text), font=f)

    def line_h(f=font):
        asc, desc = f.getmetrics()
        return asc + desc + LINE_GAP

    def fit_name_font(name, max_w):
        """Shrink the font just enough for this ONE item name to fit
        max_w in a single line (down to MIN_NAME_FS), instead of
        wrapping it onto a second line."""
        size = FS
        f = load_font(size)
        while tw(name, f) > max_w and size > MIN_NAME_FS:
            size -= 1
            f = load_font(size)
        return f

    # ---- table column widths, sized in PIXELS to fit the widest value
    # actually in this bill (mirrors the text version's logic, but with
    # real measured widths instead of character counts) ----
    qty_strs = [f"{it['qty']:g}" for it in items]
    price_strs = [f"{it['price']:.2f}" for it in items]
    total_strs = [f"{it['total']:.2f}" for it in items]
    qty_w = max([tw("Qty")] + [tw(s) for s in qty_strs]) + 4
    rate_w = max([tw("Rate")] + [tw(s) for s in price_strs]) + 4
    amt_w = max([tw("Amt")] + [tw(s) for s in total_strs]) + 4
    item_w = PAPER_WIDTH_PX - 2 * MARGIN - qty_w - rate_w - amt_w - 3 * COL_GAP

    x_item = MARGIN
    x_qty_r = MARGIN + item_w + COL_GAP + qty_w        # right edge of Qty column
    x_rate_r = x_qty_r + COL_GAP + rate_w               # right edge of Rate column
    x_amt_r = x_rate_r + COL_GAP + amt_w                # right edge of Amt column

    # ---- draw onto a generously-tall scratch canvas, then crop to the
    # actual content height at the end. Sized well above what's needed
    # (line height depends on the font's real metrics, not a guess) so
    # nothing drawn ever falls outside the canvas and gets clipped.
    canvas_h = 400 + 60 * len(items)
    img = Image.new("RGB", (PAPER_WIDTH_PX, canvas_h), "white")
    dr = ImageDraw.Draw(img)
    y = MARGIN

    def bold_text(x, y_pos, text, f=font):
        """Light bold - a single 1px horizontal offset, just enough to
        read as bold without the thick, overly dark look the earlier
        4-offset version had on the actual thermal printout.
        Used for EVERYTHING that should look bold: shop name, grand
        total, bill no, date, customer, time, and the Item/Qty/Rate/Amt
        column headers."""
        dr.text((x, y_pos), text, font=f, fill="black")
        dr.text((x + 1, y_pos), text, font=f, fill="black")

    def center(text, f=font_shop, bold=False):
        nonlocal y
        text = _tamil_visual_reorder(text)
        w = tw(text, f)
        x = (PAPER_WIDTH_PX - w) / 2
        if bold:
            bold_text(x, y, text, f)
        else:
            dr.text((x, y), text, font=f, fill="black")
        y += line_h(f)

    def left(text, f=font, bold=False):
        nonlocal y
        text = _tamil_visual_reorder(text)
        if bold:
            bold_text(MARGIN, y, text, f)
        else:
            dr.text((MARGIN, y), text, font=f, fill="black")
        y += line_h(f)

    def right(text, right_x, f=font, bold=False):
        text = _tamil_visual_reorder(text)
        w = tw(text, f)
        if bold:
            bold_text(right_x - w, y, text, f)
        else:
            dr.text((right_x - w, y), text, font=f, fill="black")

    def dashed_line():
        nonlocal y
        y += 4
        xx = MARGIN
        while xx < PAPER_WIDTH_PX - MARGIN:
            dr.line([(xx, y), (min(xx + 6, PAPER_WIDTH_PX - MARGIN), y)], fill="black", width=1)
            xx += 10
        y += 8

    def kv_row(label, value, bold=False):
        nonlocal y
        label = _tamil_visual_reorder(label)
        value = _tamil_visual_reorder(value)
        w = tw(value)
        if bold:
            bold_text(MARGIN, y, label, font)
            bold_text(PAPER_WIDTH_PX - MARGIN - w, y, value, font)
        else:
            dr.text((MARGIN, y), label, font=font, fill="black")
            dr.text((PAPER_WIDTH_PX - MARGIN - w, y), value, font=font, fill="black")
        y += line_h()

    center(SHOP_NAME, font_shop_name, bold=True)
    center(SHOP_ADDRESS, font_shop)
    center(SHOP_PHONE, font_shop)
    # Shop's own GSTIN - only printed when set in Settings; skipped
    # entirely (no blank line) when the shop hasn't configured one.
    if SHOP_GSTIN:
        center(f"GSTIN: {SHOP_GSTIN}", font_shop)
    dashed_line()
    
    # Parse date and time
    parts = bill_date.split(" ")
    only_date = parts[0]
    only_time = parts[1][:5] if len(parts) > 1 else ""

    # Draw Bill No & Date horizontally - bold, same weight as shop name /
    # grand total (see bold_text above).
    bill_str = f"Bill No: {bill_no}"
    date_str = f"Date: {only_date}"
    bold_text(MARGIN, y, bill_str, font)
    bold_text(PAPER_WIDTH_PX - MARGIN - tw(date_str), y, date_str, font)
    y += line_h()

    # Draw Customer & Time horizontally - bold, same as above.
    cust_str = f"Cust: {customer_name or 'Walk-in'}"
    bold_text(MARGIN, y, cust_str, font)
    if only_time:
        time_str = f"Time: {only_time}"
        bold_text(PAPER_WIDTH_PX - MARGIN - tw(time_str), y, time_str, font)
    y += line_h()
    
    dashed_line()

    # table header - this is the "table", just with invisible borders:
    # each label sits in its own fixed pixel column. Bold, same as the
    # shop name / grand total, so the column headings stand out clearly.
    bold_text(x_item, y, "Item", font)
    right("Qty", x_qty_r, bold=True)
    right("Rate", x_rate_r, bold=True)
    right("Amt", x_amt_r, bold=True)
    y += line_h()
    dashed_line()

    for it in items:
        name = (it.get("product_name") or "").strip() or "-"
        qty = f"{it['qty']:g}"
        price = f"{it['price']:.2f}"
        total = f"{it['total']:.2f}"
        # Item name always stays on ONE line - if it's too wide for the
        # column, this row's font shrinks just enough to fit (instead of
        # wrapping to a second line). Qty/Rate/Amt use the same font so
        # they still sit level with the name on the same baseline.
        row_font = fit_name_font(name, item_w)
        dr.text((x_item, y), _tamil_visual_reorder(name), font=row_font, fill="black")
        right(qty, x_qty_r, row_font)
        right(price, x_rate_r, row_font)
        right(total, x_amt_r, row_font)
        y += line_h(row_font)

    dashed_line()
    subtotal = grand_total - (gst_amount or 0)
    if gst_amount:
        kv_row("Sub Total", f"{subtotal:.2f}")
        kv_row("GST", f"{gst_amount:.2f}")
        if hsn_code:
            kv_row("HSN/SAC", hsn_code)
        if gstin:
            kv_row("GSTIN", gstin)
    kv_row("GRAND TOTAL", f"{grand_total:.2f}", bold=True)
    if amount_received:
        dashed_line()
        kv_row("Amount Received", f"{amount_received:.2f}")
        if balance >= 0:
            kv_row("Balance (to give)", f"{balance:.2f}")
        else:
            kv_row("Balance Due", f"{-balance:.2f}")
    dashed_line()
    center("PAID" if paid == "Paid" else "NOT PAID", font, bold=True)
    center("Thank you! Visit Again", font)
    y += MARGIN

    return img.crop((0, 0, PAPER_WIDTH_PX, int(y)))


def _image_to_escpos_raster(img, threshold=160, band_height=200):
    """Convert a PIL image to ESC/POS 'GS v 0' raster bitmap print
    command bytes - the standard way thermal printers print a picture.
    Printing the receipt as a bitmap (instead of as text) is what
    actually guarantees the Item/Qty/Rate/Amt columns line up exactly
    as laid out, since the printer just reproduces the pixels we
    already measured and placed - it doesn't re-render the text with
    its own (Tamil-unaware) font.

    IMPORTANT - why this is split into BANDS instead of one big image:
    Sending the whole receipt as a single GS v 0 command works fine for a
    short bill, but most cheap 58mm thermal printers (and the generic
    Windows RAW driver feeding them) have a small internal receive
    buffer. A tall image (many items on the bill) overflows that buffer
    mid-command, and the printer silently drops/stops the rest - which
    shows up as the BOTTOM of the receipt (often the GRAND TOTAL /
    "Thank you" lines) being cut off on the physical printout, even
    though the same image is complete and fine in the PDF (a PDF is just
    drawn to a file - it never goes through the printer's buffer).
    Splitting into short horizontal bands and sending each as its own
    small GS v 0 command keeps every command well under that buffer
    limit, so nothing gets dropped no matter how long the bill is."""
    img = img.convert("L")
    width, height = img.size
    width_bytes = (width + 7) // 8
    padded_width = width_bytes * 8
    if padded_width != width:
        from PIL import Image
        canvas = Image.new("L", (padded_width, height), 255)
        canvas.paste(img, (0, 0))
        img = canvas
        width = padded_width
    px = img.load()

    out = bytearray()
    out += b"\x1b\x40"  # ESC @ - initialize printer, sent once at the start

    y = 0
    while y < height:
        band_h = min(band_height, height - y)
        data = bytearray()
        for row in range(y, y + band_h):
            for xb in range(width_bytes):
                byte = 0
                for bit in range(8):
                    x = xb * 8 + bit
                    if px[x, row] < threshold:  # dark pixel -> print this dot
                        byte |= (1 << (7 - bit))
                data.append(byte)
        header = bytes([0x1D, 0x76, 0x30, 0x00,
                         width_bytes & 0xFF, (width_bytes >> 8) & 0xFF,
                         band_h & 0xFF, (band_h >> 8) & 0xFF])
        out += header + bytes(data)
        y += band_h

    # Feed/cut once at the very end, after every band has been sent.
    # Feeds 2 blank lines before cutting - enough clearance so the
    # cutter blade doesn't slice through the last printed line
    # ("Thank you! Visit Again"), without wasting extra blank paper
    # below the bill like the old 3-line feed did.
    out += b"\n\n\x1d\x56\x00"
    return bytes(out)


def print_receipt(receipt_text, printer_name=None, receipt_image=None):
    """
    Sends the receipt to the Windows default (or named) printer.

    If receipt_image (a PIL Image from build_receipt_image) is given
    and Pillow is available, it's sent as a pixel-perfect bitmap/raster
    job - this is what keeps Qty/Rate/Amt lined up correctly under
    their headers even with Tamil text on the row. Otherwise falls
    back to sending receipt_text as plain RAW text.

    Falls back to saving a preview file if printing isn't possible
    (e.g. running on Linux/macOS for testing, or no printer configured).
    """
    if sys.platform.startswith("win"):
        try:
            import win32print

            if printer_name is None:
                printer_name = win32print.GetDefaultPrinter()
            hPrinter = win32print.OpenPrinter(printer_name)
            try:
                hJob = win32print.StartDocPrinter(hPrinter, 1, ("Bill", None, "RAW"))
                win32print.StartPagePrinter(hPrinter)
                if receipt_image is not None:
                    payload = _image_to_escpos_raster(receipt_image)
                else:
                    payload = receipt_text.encode("utf-8", errors="ignore")
                win32print.WritePrinter(hPrinter, payload)
                win32print.EndPagePrinter(hPrinter)
                win32print.EndDocPrinter(hPrinter)
            finally:
                win32print.ClosePrinter(hPrinter)
            return True, f"Sent to printer: {printer_name}{_shaping_warning()}"
        except ImportError:
            return _save_fallback(receipt_text, "pywin32 not installed (pip install pywin32)", receipt_image)
        except Exception as e:
            return _save_fallback(receipt_text, str(e), receipt_image)
    else:
        return _save_fallback(receipt_text, "Not on Windows - preview saved instead", receipt_image)


def _save_fallback(receipt_text, reason, receipt_image=None):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, "last_receipt_preview.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(receipt_text)
    if receipt_image is not None:
        try:
            img_path = os.path.join(base_dir, "last_receipt_preview.png")
            receipt_image.save(img_path)
            return False, (f"Could not print directly ({reason}). Preview saved to {path} "
                            f"and {img_path} (this image is exactly what would be printed)."
                            f"{_shaping_warning()}")
        except Exception:
            pass
    return False, f"Could not print directly ({reason}). Preview saved to {path}{_shaping_warning()}"


# ---------------------------------------------------------------------
# PDF export
# ---------------------------------------------------------------------
# The bill can contain Tamil product/customer names. PDF's built-in
# fonts (Courier etc.) only support Latin-1, so Tamil text can't be
# drawn with them directly. To show real Tamil in the PDF, any line
# that contains non-English letters is instead RENDERED AS A PICTURE
# using a Tamil font already on this PC and pasted into the PDF; plain
# English/number lines are still drawn as normal PDF text (so they stay
# small, sharp and searchable).
#
# This needs the "reportlab" and "pillow" packages (pip install
# reportlab). If they aren't installed, or no Tamil font can be found
# on this PC, the app automatically falls back to the old plain-text
# PDF builder, where Tamil letters show as "?" (everything else about
# the bill - printing, on-screen view - is unaffected either way).
#
# This app deliberately does NOT bundle any Tamil font of its own -
# it uses NIRMALA (Nirmala UI), the Tamil-capable font Windows itself
# ships with every Windows 8/10/11 PC, as the font. Since it's a normal
# system font, this needs no extra download, no font file to carry
# around in the .exe, and no "which font is this really" guessing.
# Latha/Vijaya (older Windows Tamil fonts) are kept as a fallback for
# older Windows versions that predate Nirmala. If truly no Tamil font
# is found (e.g. a stripped-down PC), you can still drop any Tamil
# .ttf font (e.g. "Noto Sans Tamil") into a "fonts" folder next to
# these .py files and name it tamil_font.ttf - see _find_tamil_font()
# below; this manual option is checked LAST, after Nirmala, so Nirmala
# is always what's actually used on a normal Windows PC.
# ---------------------------------------------------------------------

def _is_ascii(text):
    return all(ord(ch) < 128 for ch in text)


_TAMIL_FONT_CACHE = {"path": "unset"}  # module-level cache so we only scan once per run


def _font_has_tamil(path):
    """Return True if the font file at `path` has glyphs for Tamil letters
    (checked via its cmap table, i.e. does it actually contain Tamil
    characters, not just whether the filename looks Tamil-ish)."""
    try:
        from fontTools.ttLib import TTFont
    except ImportError:
        # fontTools not installed - fall back to a best-effort PIL render
        # test: draw a Tamil letter and see if it produced a real glyph
        # (a "missing glyph" box/blank is typically a tiny/empty bitmap).
        try:
            from PIL import Image, ImageDraw, ImageFont
            font = ImageFont.truetype(path, 40)
            img = Image.new("L", (60, 60))
            d = ImageDraw.Draw(img)
            bbox = d.textbbox((0, 0), "\u0b95", font=font)  # 'க'
            return (bbox[2] - bbox[0]) > 3 and (bbox[3] - bbox[1]) > 3
        except Exception:
            return False
    try:
        tt = TTFont(path, fontNumber=0, lazy=True)
        for table in tt["cmap"].tables:
            if 0x0B95 in table.cmap:  # 'க' - a common Tamil consonant
                return True
        return False
    except Exception:
        return False
    finally:
        try:
            tt.close()
        except Exception:
            pass


def _find_tamil_font():
    """Look for a Tamil-capable font already available on this PC.
    Returns a filesystem path (and, for .ttc collections, an index), or
    None if none could be found. Result is cached for the life of the
    program so repeated PDF saves don't re-scan every time."""
    if _TAMIL_FONT_CACHE["path"] != "unset":
        return _TAMIL_FONT_CACHE["path"]

    # base_dir: where THIS SOURCE FILE physically sits when running as a
    # normal .py (dev machine) - used below as one of several places to
    # look for a manually-dropped-in font.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # bundled_dir: where PyInstaller extracts bundled data files (added
    # via main.spec's datas=[...]) at runtime, e.g. sys._MEIPASS. This is
    # what makes a "fonts" folder added to main.spec actually get found
    # INSIDE the built .exe, instead of only working when a "fonts"
    # folder happens to be sitting loose next to the .exe on disk.
    bundled_dir = getattr(sys, "_MEIPASS", base_dir)
    # exe_dir: the folder the actual .exe file lives in (only meaningful
    # when frozen) - still checked too, so a shopkeeper can swap in a
    # different font by dropping a fonts/ folder next to the .exe,
    # without needing to rebuild it.
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else base_dir
    windir = os.environ.get("WINDIR", r"C:\Windows")
    local_appdata = os.environ.get("LOCALAPPDATA", "")

    # 1) NIRMALA first - this is the font this app is built around. It
    # covers both the newer Windows 10/11 layout, where Nirmala lives
    # inside a single "Nirmala.ttc" collection file, and the older
    # "Nirmala.ttf"/"NirmalaB.ttf"/"NirmalaS.ttf" file names from
    # Windows 8/8.1 (older code here only looked for "Nirmala.ttf",
    # which is why some Windows 10/11 PCs used to show "no Tamil font
    # found" even though Tamil text was typed correctly - .ttc is
    # checked first now). Latha/Vijaya are kept only as a fallback for
    # the rare PC running a Windows version that predates Nirmala.
    named_candidates = [
        os.path.join(windir, "Fonts", "Nirmala.ttc"),
        os.path.join(windir, "Fonts", "Nirmala.ttf"),
        os.path.join(windir, "Fonts", "NirmalaB.ttf"),
        os.path.join(windir, "Fonts", "NirmalaS.ttf"),
        os.path.join(local_appdata, "Microsoft", "Windows", "Fonts", "Nirmala.ttc"),
        os.path.join(windir, "Fonts", "latha.ttf"),
        os.path.join(windir, "Fonts", "vijaya.ttf"),
        os.path.join(windir, "Fonts", "vijayab.ttf"),
        "/usr/share/fonts/truetype/noto/NotoSansTamil-Regular.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansTamil-Regular.ttf",
        "/System/Library/Fonts/Supplemental/Tamil Sangam MN.ttc",
        "/Library/Fonts/Tamil Sangam MN.ttc",
    ]
    for path in named_candidates:
        if path and os.path.isfile(path) and _font_has_tamil(path):
            _TAMIL_FONT_CACHE["path"] = path
            return path

    # 2) manual/dropped-in font - only used as a fallback now, for a PC
    # where Nirmala genuinely isn't present (this app no longer ships
    # its own font file). A shopkeeper can still drop a Tamil .ttf into
    # a "fonts" folder next to main.py / the .exe and name it
    # tamil_font.ttf to have it picked up automatically. Checked in
    # bundled .exe resources first, then next to the .exe, then next
    # to this .py file - covers dev machine, onefile .exe and onedir
    # .exe alike.
    manual_candidates = []
    for folder in (bundled_dir, exe_dir, base_dir):
        manual_candidates.append(os.path.join(folder, "fonts", "tamil_font.ttf"))
        manual_candidates.append(os.path.join(folder, "fonts", "NotoSansTamil-Regular.ttf"))
    for path in manual_candidates:
        if os.path.isfile(path):
            _TAMIL_FONT_CACHE["path"] = path
            return path

    # 3) last resort: scan every font file actually installed on this PC
    # (both the system fonts folder and the per-user one - Windows lets
    # fonts be installed to either) and pick the first one whose cmap
    # really contains Tamil glyphs. This makes detection work regardless
    # of which exact Tamil font/version happens to be on the PC.
    scan_dirs = [
        os.path.join(windir, "Fonts"),
        os.path.join(local_appdata, "Microsoft", "Windows", "Fonts"),
        "/usr/share/fonts",
        "/System/Library/Fonts",
        "/Library/Fonts",
    ]
    for d in scan_dirs:
        if not d or not os.path.isdir(d):
            continue
        try:
            for root, _dirs, files in os.walk(d):
                for fname in files:
                    if fname.lower().endswith((".ttf", ".ttc", ".otf")):
                        fpath = os.path.join(root, fname)
                        if _font_has_tamil(fpath):
                            _TAMIL_FONT_CACHE["path"] = fpath
                            return fpath
        except Exception:
            continue

    _TAMIL_FONT_CACHE["path"] = None
    return None


def _render_text_image(text, font_path, px_size=34):
    """Render one line of text to a transparent RGBA image using PIL, with
    proper complex-script (Tamil) shaping via the raqm layout engine when
    available. Returns (image, ascent_px, descent_px) - ascent/descent are
    the FONT's own metrics at px_size (a fixed reference that's the same
    for every line rendered with this font), used by the caller to scale
    every Tamil line to the exact same visual size as the English text."""
    from PIL import Image, ImageDraw, ImageFont
    try:
        font = ImageFont.truetype(font_path, px_size, layout_engine=ImageFont.Layout.RAQM)
    except Exception:
        font = ImageFont.truetype(font_path, px_size)
    text = _tamil_visual_reorder(text or " ")
    dummy = Image.new("RGBA", (10, 10))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), text or " ", font=font)
    w = max(1, bbox[2] - bbox[0] + 6)
    h = max(1, bbox[3] - bbox[1] + 6)
    img = Image.new("RGBA", (w, h), (255, 255, 255, 0))
    d = ImageDraw.Draw(img)
    d.text((-bbox[0] + 3, -bbox[1] + 3), text or " ", font=font, fill=(0, 0, 0, 255))
    ascent, descent = font.getmetrics()
    return img, ascent, descent


def save_pdf_receipt(receipt_text, filepath, receipt_image=None):
    """Write the receipt out as a PDF file at filepath.

    If receipt_image (a PIL Image from build_receipt_image) is given,
    it's pasted straight into the PDF - this is the SAME pixel-perfect
    bitmap used for actual printing, so the PDF, the printout and the
    preview all match exactly, with Qty/Rate/Amt correctly aligned.

    Otherwise falls back to the older per-line text/Tamil-image PDF
    builder, and if reportlab isn't installed at all, to a plain-text
    (English/numbers only) PDF. Returns (ok, message)."""
    try:
        from reportlab.pdfgen import canvas as rl_canvas
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.utils import ImageReader
    except ImportError:
        return _save_pdf_receipt_ascii_only(receipt_text, filepath)

    if receipt_image is not None:
        try:
            a4_width, a4_height = A4
            margin = 40
            # Scale the receipt bitmap to fit the page WIDTH, preserving
            # its aspect ratio, so every column stays exactly where it
            # was pixel-placed in build_receipt_image().
            avail_w = a4_width - 2 * margin
            scale = avail_w / receipt_image.width
            draw_w = receipt_image.width * scale
            draw_h = receipt_image.height * scale

            # IMPORTANT: a bill with more items makes build_receipt_image()
            # taller. Forcing that onto a fixed A4-height page (old code)
            # meant anything past ~5 items got pushed below the bottom of
            # the page and simply wasn't drawn - it looked "cut in half".
            # Instead, make the PAGE itself as tall as the receipt needs
            # (never shorter than a normal A4 sheet, so small bills still
            # look like a normal page) - this way every item, the total
            # and "Thank you" line always fit on the ONE page, no matter
            # how many products are on the bill.
            page_width = a4_width
            page_height = max(a4_height, draw_h + 2 * margin)

            c = rl_canvas.Canvas(filepath, pagesize=(page_width, page_height))
            y_top = page_height - margin - draw_h
            c.drawImage(ImageReader(receipt_image), margin, y_top, width=draw_w, height=draw_h)
            c.save()
            return True, f"Bill saved as PDF: {filepath}{_shaping_warning()}"
        except Exception as e:
            return False, f"Could not save PDF: {e}"

    tamil_font_path = _find_tamil_font()

    try:
        c = rl_canvas.Canvas(filepath, pagesize=A4)
        page_width, page_height = A4
        left_margin = 40
        top_margin = 40
        font_size = 10
        line_height = 14
        px_size = 34  # render resolution for Tamil-line images

        def new_page():
            c.setFont("Courier", font_size)
            return page_height - top_margin

        y = new_page()
        for ln in receipt_text.split("\n"):
            if y < top_margin:
                c.showPage()
                y = new_page()
            if not ln.strip() or _is_ascii(ln):
                c.setFont("Courier", font_size)
                c.drawString(left_margin, y, ln)
            elif tamil_font_path:
                img, ascent_px, descent_px = _render_text_image(ln, tamil_font_path, px_size)
                # Scale using the FONT's own ascent+descent (a fixed
                # reference for this font at px_size) rather than this
                # specific line's ink height. Some Tamil lines have tall
                # vowel signs sticking up/down further than others, so
                # scaling off each line's own bbox (old behaviour) made
                # different lines - and the whole Tamil text vs. the
                # English Courier text around it - come out different,
                # oversized sizes. Matching font_size here makes Tamil
                # lines the same visual size as the English lines.
                line_metric_px = ascent_px + descent_px
                scale = font_size / line_metric_px
                target_w = img.width * scale
                target_h = img.height * scale
                baseline_gap = descent_px * scale  # keeps the line sitting on the same baseline as the English text
                c.drawImage(ImageReader(img), left_margin, y - baseline_gap,
                            width=target_w, height=target_h, mask="auto")
            else:
                safe = "".join(ch if ord(ch) < 256 else "?" for ch in ln)
                c.setFont("Courier", font_size)
                c.drawString(left_margin, y, safe)
            y -= line_height
        c.save()

        if tamil_font_path:
            return True, f"Bill saved as PDF: {filepath}"
        return True, (
            f"Bill saved as PDF: {filepath}\n"
            "(No Tamil font found on this PC, so Tamil text shows as '?' in "
            "the PDF only - see README for how to add one.)"
        )
    except Exception as e:
        return False, f"Could not save PDF: {e}"


# ---------------------------------------------------------------------
# Old hand-built PDF fallback - used automatically only if reportlab
# isn't installed. No external library needed, English/numbers only.
# ---------------------------------------------------------------------

def _pdf_escape(text):
    text = text.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
    # Core PDF fonts only support Latin-1; replace anything else safely
    safe = []
    for ch in text:
        safe.append(ch if ord(ch) < 256 else "?")
    return "".join(safe)


def _save_pdf_receipt_ascii_only(receipt_text, filepath):
    """Write receipt_text into a simple one-page-per-40-lines PDF file
    at filepath, using the built-in Courier font. Returns (ok, message)."""
    try:
        lines = receipt_text.split("\n")
        lines_per_page = 55
        pages_lines = [lines[i:i + lines_per_page] for i in range(0, len(lines), lines_per_page)] or [[""]]

        objects = []  # list of (obj_num, content_bytes)
        content_obj_nums = []
        page_obj_nums = []

        obj_num = 4  # 1=Catalog, 2=Pages, 3=Font -> content/page objects start at 4
        for page_lines in pages_lines:
            y = 800
            stream_parts = ["BT", "/F1 10 Tf", "12 TL"]
            first = True
            for ln in page_lines:
                safe_ln = _pdf_escape(ln)
                if first:
                    stream_parts.append(f"40 {y} Td")
                    first = False
                else:
                    stream_parts.append("T*")
                stream_parts.append(f"({safe_ln}) Tj")
            stream_parts.append("ET")
            stream = "\n".join(stream_parts).encode("latin-1", errors="replace")

            content_num = obj_num
            objects.append((content_num, b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream"))
            content_obj_nums.append(content_num)
            obj_num += 1

            page_num = obj_num
            objects.append((page_num, (
                f"<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 3 0 R >> >> "
                f"/MediaBox [0 0 595 842] /Contents {content_num} 0 R >>"
            ).encode("latin-1")))
            page_obj_nums.append(page_num)
            obj_num += 1

        kids = " ".join(f"{n} 0 R" for n in page_obj_nums)
        header_objects = [
            (1, b"<< /Type /Catalog /Pages 2 0 R >>"),
            (2, f"<< /Type /Pages /Kids [{kids}] /Count {len(page_obj_nums)} >>".encode("latin-1")),
            (3, b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"),
        ]
        all_objects = header_objects + objects
        all_objects.sort(key=lambda o: o[0])

        pdf = bytearray()
        pdf += b"%PDF-1.4\n"
        offsets = {}
        for num, body in all_objects:
            offsets[num] = len(pdf)
            pdf += f"{num} 0 obj\n".encode("latin-1")
            pdf += body
            pdf += b"\nendobj\n"

        xref_start = len(pdf)
        total = len(all_objects) + 1
        pdf += f"xref\n0 {total}\n".encode("latin-1")
        pdf += b"0000000000 65535 f \n"
        for num, _ in all_objects:
            pdf += f"{offsets[num]:010d} 00000 n \n".encode("latin-1")
        pdf += (
            f"trailer\n<< /Size {total} /Root 1 0 R >>\nstartxref\n{xref_start}\n%%EOF"
        ).encode("latin-1")

        with open(filepath, "wb") as f:
            f.write(pdf)
        return True, (
            f"Bill saved as PDF: {filepath}\n"
            "(Install 'reportlab' - pip install reportlab - for proper Tamil "
            "text support in the PDF.)"
        )
    except Exception as e:
        return False, f"Could not save PDF: {e}"
