# ==========================================
# 1. FIRST: Add DLL Directory for Raqm support
# ==========================================
import os
import sys

if getattr(sys, 'frozen', False):
    # .exe ah maaruna apram load aagurathuku
    os.add_dll_directory(sys._MEIPASS)
else:
    # VS Code-la run aagum podhu project root-la irundhu edukkarathuku
    os.add_dll_directory(os.path.dirname(os.path.abspath(__file__)))
# ==========================================

# 2. NOW: Unga normal imports ellaam inga thaan varanum
import atexit
import database as db
import license_lock
from billing_app import BillingApp


def _warn_if_expiring_soon(app):
    """If the saved license is a subscription that's about to run out (or
    ran out today), pop up a reminder with the renewal contact number -
    every launch during that window, so it isn't missed."""
    status = license_lock.get_saved_license_status()
    if not status or not status.get("should_warn") or status.get("expired"):
        return
    from tkinter import messagebox
    days = status["days_left"]
    when = "today" if days == 0 else f"in {days} day{'s' if days != 1 else ''}"
    messagebox.showwarning(
        "Subscription Expiring Soon",
        f"Your subscription expires {when} (on {status['expiry'].strftime('%d-%m-%Y')}).\n\n"
        f"Please contact {license_lock.SUPPORT_CONTACT} to renew and avoid any interruption.",
        parent=app,
    )


def start_app():
    db.init_db()
    atexit.register(db.mirror_db_near_exe)  # keep the visible copy next
                                             # to the .exe fresh when the
                                             # app closes normally too
    app = BillingApp()
    _warn_if_expiring_soon(app)
    app.mainloop()


if __name__ == "__main__":
    if license_lock.is_activated():
        start_app()
    else:
        # Shows the activation screen; only calls start_app() once this
        # exact PC has been activated with a matching license key.
        license_lock.show_activation_window(on_success=start_app)