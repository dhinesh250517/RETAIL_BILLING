"""
database.py
-----------
All local data storage for the Billing Software.
Uses SQLite (single file: shop_data.db) - fully offline.
Because shop_data.db sits next to the .exe / .py file, copying the
whole folder to a pendrive and running it on another PC carries all
the data with it.
"""

import sqlite3
import os
import sys
import json
from datetime import datetime, timedelta

# When running as a normal .py file, __file__ points to this script's
# real folder - fine. But when running as a PyInstaller-built .exe,
# __file__ points *inside the temporary extraction folder* (sys._MEIPASS),
# which PyInstaller wipes and recreates fresh on every single launch.
# Any password/setting/bill saved there was being thrown away the moment
# the app closed - so the app always looked like it "forgot" changes and
# fell back to the original bundled defaults. Using sys.executable's
# folder instead keeps the database sitting permanently next to the
# actual .exe file, so all changes persist across restarts.
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- Where the actual shop_data.db LIVES -----------------------------
# Storing the DB next to the .exe (old behaviour, BASE_DIR above) is
# risky: every time the .exe is rebuilt/replaced (e.g. after changing
# and re-running the code) or the folder is moved/re-copied, the new
# .exe can end up in a different folder or overwrite the old one, and
# the app then looks for shop_data.db right next to itself, finds
# nothing, and silently creates a brand-new EMPTY database - which
# looks exactly like every customer/product got deleted, even though
# nothing was ever actually deleted on purpose.
#
# To make this safe, the real database is kept in a fixed OS-level
# per-user data folder that has nothing to do with where the .exe
# happens to sit, so rebuilding/moving/renaming the .exe never affects
# it:
#   Windows:  %LOCALAPPDATA%\BillingApp\shop_data.db
#   Other OS: ~/.billingapp/shop_data.db
# The very first time the app runs after this change, if that fixed
# location doesn't have a database yet but an OLD shop_data.db is
# found sitting next to the .exe/.py (from before this change), it is
# copied over automatically so no existing customers/bills/dues are
# lost in the switch.
if sys.platform.startswith("win"):
    _APP_DATA_DIR = os.path.join(
        os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local"),
        "BillingApp",
    )
else:
    _APP_DATA_DIR = os.path.join(os.path.expanduser("~"), ".billingapp")

os.makedirs(_APP_DATA_DIR, exist_ok=True)
DB_FILE = os.path.join(_APP_DATA_DIR, "shop_data.db")

_OLD_DB_FILE = os.path.join(BASE_DIR, "shop_data.db")
if not os.path.exists(DB_FILE) and os.path.exists(_OLD_DB_FILE):
    import shutil
    try:
        shutil.copy2(_OLD_DB_FILE, DB_FILE)
    except Exception:
        pass  # if the copy fails for any reason, init_db() below still
              # creates a fresh empty DB at DB_FILE rather than crashing

# --- Automatic daily backups, as a safety net -------------------------
# Moving the live DB_FILE out of the exe's folder (above) already stops
# it from being accidentally selected/deleted while poking around in
# the exe's folder. On top of that, keep a rolling set of dated copies
# in a separate "backups" folder, so that even if shop_data.db itself
# is ever deleted, damaged, or the drive has a problem, a recent copy
# from any of the last BACKUP_KEEP_DAYS days can just be renamed back
# to shop_data.db (or restored via Admin Panel -> Restore Database) to
# get the shop running again with only that day's data missing at most.
_BACKUP_DIR = os.path.join(_APP_DATA_DIR, "backups")
BACKUP_KEEP_DAYS = 15


def auto_backup_db():
    """Copy today's shop_data.db into the backups folder (once per day)
    and delete backup copies older than BACKUP_KEEP_DAYS. Never raises -
    a backup failure should never stop the app from starting."""
    try:
        if not os.path.exists(DB_FILE):
            return
        os.makedirs(_BACKUP_DIR, exist_ok=True)
        today_tag = datetime.now().strftime("%Y-%m-%d")
        today_backup = os.path.join(_BACKUP_DIR, f"shop_data_{today_tag}.db")
        if not os.path.exists(today_backup):
            import shutil
            shutil.copy2(DB_FILE, today_backup)

        # Prune anything older than BACKUP_KEEP_DAYS days
        cutoff = datetime.now() - timedelta(days=BACKUP_KEEP_DAYS)
        for fname in os.listdir(_BACKUP_DIR):
            if not (fname.startswith("shop_data_") and fname.endswith(".db")):
                continue
            date_part = fname[len("shop_data_"):-len(".db")]
            try:
                file_dt = datetime.strptime(date_part, "%Y-%m-%d")
            except ValueError:
                continue
            if file_dt < cutoff:
                try:
                    os.remove(os.path.join(_BACKUP_DIR, fname))
                except Exception:
                    pass
    except Exception:
        pass


def mirror_db_near_exe():
    """Keep a plain, visible COPY of the database sitting next to the
    .exe too (at _OLD_DB_FILE), same as before - purely so the whole
    app folder can still be copied to a pendrive/another PC and carry
    all the data with it, same as the original design.

    This copy is NEVER the one the app actually reads/writes - the real,
    live database is always DB_FILE (the safe AppData location). This
    mirror is refreshed every time the app starts and every time it
    closes normally, so it's always at most one session old. Because
    it's just a mirror, if it's ever accidentally deleted from next to
    the .exe, nothing is lost - the next app start/close just writes it
    again from the real copy in AppData."""
    try:
        if not os.path.exists(DB_FILE):
            return
        import shutil
        shutil.copy2(DB_FILE, _OLD_DB_FILE)
    except Exception:
        pass

DUES_RETENTION_MONTHS_DEFAULT = 8  # Completed (fully paid) dues are
                           # auto-cleared this many months after they were
                           # completed - editable in Settings. Products,
                           # customers, and OPEN (unpaid) dues are NEVER
                           # auto-deleted. Bills are also never auto-deleted
                           # any more - see delete_bills_older_than() below,
                           # which is a manual, Settings-triggered action.


def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("PRAGMA foreign_keys = ON")
    # WAL mode lets reads and writes happen without blocking each other and
    # avoids a full disk-sync on every single commit (NORMAL still syncs at
    # the right moments to keep the data safe). Without this, every item
    # added to a bill - which silently saves the product in the background
    # - does a full fsync, and that adds up to real, noticeable lag over a
    # full day of ~300 bills. Cheap to run on every connect; only actually
    # does anything the very first time.
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def _column_exists(c, table, column):
    c.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in c.fetchall())


def init_db():
    conn = get_connection()
    c = conn.cursor()
    # "name" holds the product name (shopkeeper can type it in Tamil or
    # English directly). "tamil_name" is kept only so old data files
    # still open correctly; it is no longer shown separately in the UI.
    c.execute("""CREATE TABLE IF NOT EXISTS products (
        product_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        tamil_name TEXT,
        stock REAL DEFAULT 0,
        price REAL NOT NULL,
        gst_percent REAL DEFAULT 0,
        cost_price REAL DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS customers (
        customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact TEXT,
        address TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bills (
        bill_no INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_date TEXT NOT NULL,
        customer_id INTEGER,
        customer_name TEXT,
        contact TEXT,
        address TEXT,
        grand_total REAL,
        gst_amount REAL DEFAULT 0,
        paid TEXT,
        amount_received REAL DEFAULT 0,
        balance REAL DEFAULT 0,
        gstin TEXT DEFAULT '',
        hsn_code TEXT DEFAULT '',
        FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bill_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_no INTEGER,
        product_id TEXT,
        product_name TEXT,
        tamil_name TEXT,
        qty REAL,
        price REAL,
        total REAL,
        cost_price REAL DEFAULT 0,
        FOREIGN KEY(bill_no) REFERENCES bills(bill_no)
    )""")

    # Create settings table
    c.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )""")

    # Create dues and due payments tables
    c.execute("""CREATE TABLE IF NOT EXISTS customer_dues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        customer_name TEXT NOT NULL,
        contact TEXT,
        total_due REAL NOT NULL,
        balance_due REAL NOT NULL,
        created_at TEXT NOT NULL,
        status TEXT DEFAULT 'Pending',
        FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS due_payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        due_id INTEGER,
        amount_paid REAL NOT NULL,
        payment_date TEXT NOT NULL,
        remarks TEXT,
        entry_type TEXT DEFAULT 'payment',
        FOREIGN KEY(due_id) REFERENCES customer_dues(id) ON DELETE CASCADE
    )""")

    # ---- lightweight migration for people upgrading from the old version ----
    if not _column_exists(c, "due_payments", "entry_type"):
        c.execute("ALTER TABLE due_payments ADD COLUMN entry_type TEXT DEFAULT 'payment'")
    if not _column_exists(c, "products", "gst_percent"):
        c.execute("ALTER TABLE products ADD COLUMN gst_percent REAL DEFAULT 0")
    if not _column_exists(c, "bills", "gst_amount"):
        c.execute("ALTER TABLE bills ADD COLUMN gst_amount REAL DEFAULT 0")
    if not _column_exists(c, "bills", "amount_received"):
        c.execute("ALTER TABLE bills ADD COLUMN amount_received REAL DEFAULT 0")
    if not _column_exists(c, "bills", "balance"):
        c.execute("ALTER TABLE bills ADD COLUMN balance REAL DEFAULT 0")
    if not _column_exists(c, "products", "cost_price"):
        c.execute("ALTER TABLE products ADD COLUMN cost_price REAL DEFAULT 0")
    if not _column_exists(c, "bill_items", "cost_price"):
        c.execute("ALTER TABLE bill_items ADD COLUMN cost_price REAL DEFAULT 0")
    if not _column_exists(c, "bills", "gstin"):
        c.execute("ALTER TABLE bills ADD COLUMN gstin TEXT DEFAULT ''")
    if not _column_exists(c, "bills", "hsn_code"):
        c.execute("ALTER TABLE bills ADD COLUMN hsn_code TEXT DEFAULT ''")
    if not _column_exists(c, "bills", "due_adjustment_amount"):
        # Remembers how much of THIS bill's shortfall/overpayment has
        # already been pushed into the customer's Dues Ledger via the
        # "Add/Reduce Due" checkbox. Without this, re-opening the same
        # bill later and ticking the checkbox again would push the whole
        # amount into the ledger a SECOND time (double-counting the due -
        # a real money-losing bug), instead of only topping up whatever
        # changed since the last time it was applied.
        c.execute("ALTER TABLE bills ADD COLUMN due_adjustment_amount REAL DEFAULT 0")
    if not _column_exists(c, "customer_dues", "completed_at"):
        # When a due is fully paid off, it's no longer deleted - it's kept
        # with status='Paid' and this timestamp, so it can still be
        # reviewed later under Completed Dues.
        c.execute("ALTER TABLE customer_dues ADD COLUMN completed_at TEXT")

    # ---- indexes so search/autocomplete and invoice listing stay instant
    # as products, customers, and (especially) the bills history grow ----
    c.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_customers_contact ON customers(contact)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_bills_date ON bills(bill_date)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_bill_items_billno ON bill_items(bill_no)")

    conn.commit()
    conn.close()
    # Take today's safety-net backup (see auto_backup_db() above DB_FILE
    # setup) right after the schema is confirmed ready.
    auto_backup_db()
    # Also refresh the visible copy next to the .exe, for pendrive/folder
    # portability (see mirror_db_near_exe() docstring above DB_FILE setup).
    mirror_db_near_exe()
    # If the shopkeeper has turned on "GST Auto-Save" in Settings, make
    # sure today's GST Excel is safely exported to disk BEFORE any bills
    # older than BILL_RETENTION_DAYS (~3 months) get auto-deleted below -
    # otherwise that sales data would be lost forever with no record for
    # GST filing.
    auto_export_gst_if_due()
    # Bills are NEVER auto-deleted any more - only a manual "Delete Bills"
    # action from Settings removes them (see delete_bills_older_than()).
    # Completed (fully paid) dues DO still auto-clear, but only after the
    # configurable retention period below (default 8 months, editable in
    # Settings) - open/unpaid dues are never touched by this.
    auto_delete_old_completed_dues()


def get_desktop_folder():
    """Best-effort path to the current Windows user's Desktop folder, for
    the automatic pre-delete Excel backup. Falls back to the folder next
    to the app if a real Desktop folder can't be found (e.g. on
    Linux/macOS while testing)."""
    candidate = os.path.join(os.path.expanduser("~"), "Desktop")
    if os.path.isdir(candidate):
        return candidate
    return BASE_DIR


def get_bills_for_backup(days):
    """Every bill (and its line items, with cost_price so profit can be
    worked out later) matching the same 'older than `days` days' filter
    used by delete_bills_older_than() - pass days=None for ALL bills.
    Used to build the automatic Excel backup taken right before a
    Settings > Delete Bills run, so nothing (including profit history)
    is ever lost even after the bills themselves are gone."""
    conn = get_connection()
    c = conn.cursor()
    if days is None:
        c.execute(
            "SELECT bill_no, bill_date, customer_name, contact, grand_total, gst_amount, "
            "paid, amount_received, balance FROM bills ORDER BY bill_no"
        )
    else:
        cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        c.execute(
            "SELECT bill_no, bill_date, customer_name, contact, grand_total, gst_amount, "
            "paid, amount_received, balance FROM bills WHERE bill_date < ? ORDER BY bill_no",
            (cutoff,),
        )
    bills = c.fetchall()

    items_by_bill = {}
    for b in bills:
        bill_no = b[0]
        c.execute(
            "SELECT product_name, qty, price, total, cost_price FROM bill_items WHERE bill_no=?",
            (bill_no,),
        )
        items_by_bill[bill_no] = c.fetchall()
    conn.close()
    return bills, items_by_bill


def export_bills_backup_excel(days, folder=None):
    """Writes a 2-sheet Excel backup (Bills summary + Item-level detail
    with Cost Price/Profit) of every bill that Settings > Delete Bills is
    about to remove, and saves it to the Desktop automatically - no save
    dialog, no extra click. Called right before delete_bills_older_than()
    so profit history for those bills is never lost, even though the
    bills themselves are about to be permanently deleted.

    Returns (path, bill_count) - or (None, 0) if there was nothing to
    back up (e.g. the range matched zero bills, so nothing runs)."""
    bills, items_by_bill = get_bills_for_backup(days)
    if not bills:
        return None, 0

    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    if folder is None:
        folder = get_desktop_folder()
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    filename = f"Deleted_Bills_Backup_{stamp}.xlsx"
    path = os.path.join(folder, filename)

    shop = get_shop_details()
    bold = Font(bold=True)
    title_font = Font(bold=True, size=14)
    header_fill = PatternFill("solid", fgColor="1E3A5F")
    header_font = Font(bold=True, color="FFFFFF")
    thin = Side(style="thin", color="94A3B8")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center")
    right = Alignment(horizontal="right", vertical="center")

    wb = Workbook()

    # ---- Sheet 1: Bills summary ----
    ws1 = wb.active
    ws1.title = "Bills Summary"
    headers1 = ["S.No", "Bill No", "Date", "Customer Name", "Contact", "Paid Status",
                "Grand Total (₹)", "GST Amount (₹)", "Amount Received (₹)", "Balance (₹)"]
    ws1.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers1))
    ws1.cell(row=1, column=1, value=f"{shop['shop_name']} - Deleted Bills Backup").font = title_font
    ws1.cell(row=1, column=1).alignment = center
    ws1.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(headers1))
    ws1.cell(row=2, column=1, value=f"Backed up on: {datetime.now().strftime('%d-%b-%Y %H:%M')} - "
                                     f"{len(bills)} bill(s) about to be deleted").font = bold
    ws1.cell(row=2, column=1).alignment = center

    header_row = 4
    for col, text in enumerate(headers1, start=1):
        cell = ws1.cell(row=header_row, column=col, value=text)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center
        cell.border = border

    row_num = header_row + 1
    for i, (bno, date, name, contact, grand_total, gst_amount, paid, received, balance) in enumerate(bills, start=1):
        values = [i, bno, date, name or "Walk-in Customer", contact, paid,
                  round(grand_total, 2), round(gst_amount or 0, 2),
                  round(received or 0, 2), round(balance or 0, 2)]
        for col, val in enumerate(values, start=1):
            cell = ws1.cell(row=row_num, column=col, value=val)
            cell.border = border
            if col in (7, 8, 9, 10):
                cell.number_format = "#,##0.00"
                cell.alignment = right
            else:
                cell.alignment = center
        row_num += 1

    widths1 = [6, 10, 16, 24, 14, 12, 14, 12, 16, 12]
    for col, w in enumerate(widths1, start=1):
        ws1.column_dimensions[get_column_letter(col)].width = w
    ws1.freeze_panes = ws1.cell(row=header_row + 1, column=1)

    # ---- Sheet 2: Item-level detail, with Cost Price + Profit so this
    # backup is enough to reconstruct profit reports for these bills even
    # after they're gone from the app. ----
    ws2 = wb.create_sheet("Item Detail (Profit)")
    headers2 = ["Bill No", "Date", "Product Name", "Qty", "Price (₹)", "Line Total (₹)",
                "Cost Price (₹)", "Profit (₹)"]
    for col, text in enumerate(headers2, start=1):
        cell = ws2.cell(row=1, column=col, value=text)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center
        cell.border = border

    row_num = 2
    total_profit = 0.0
    for bno, date, name, contact, grand_total, gst_amount, paid, received, balance in bills:
        for pname, qty, price, total, cost_price in items_by_bill.get(bno, []):
            profit = (price - (cost_price or 0)) * qty
            total_profit += profit
            values = [bno, date[:10], pname, qty, round(price, 2), round(total, 2),
                      round(cost_price or 0, 2), round(profit, 2)]
            for col, val in enumerate(values, start=1):
                cell = ws2.cell(row=row_num, column=col, value=val)
                cell.border = border
                if col in (5, 6, 7, 8):
                    cell.number_format = "#,##0.00"
                    cell.alignment = right
                else:
                    cell.alignment = center
            row_num += 1

    ws2.cell(row=row_num, column=7, value="TOTAL PROFIT:").font = bold
    ws2.cell(row=row_num, column=7).alignment = right
    tot_cell = ws2.cell(row=row_num, column=8, value=round(total_profit, 2))
    tot_cell.font = bold
    tot_cell.number_format = "#,##0.00"
    tot_cell.alignment = right

    widths2 = [10, 13, 26, 8, 12, 14, 14, 12]
    for col, w in enumerate(widths2, start=1):
        ws2.column_dimensions[get_column_letter(col)].width = w
    ws2.freeze_panes = ws2.cell(row=2, column=1)

    wb.save(path)
    return path, len(bills)


def delete_bills_older_than(days):
    """Manually delete every bill (and its line items) whose bill_date is
    older than `days` days ago. Pass days=None to delete ALL bills.
    Products, customers, and dues are completely untouched - only the
    bills/invoices themselves and their line items are removed. This is
    ONLY ever called when the shopkeeper explicitly asks for it from the
    Settings > "Delete Bills" section - nothing here runs automatically.
    Returns how many bills were deleted."""
    conn = get_connection()
    c = conn.cursor()
    if days is None:
        c.execute("SELECT bill_no FROM bills")
    else:
        cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        c.execute("SELECT bill_no FROM bills WHERE bill_date < ?", (cutoff,))
    old_bills = [row[0] for row in c.fetchall()]
    for bn in old_bills:
        c.execute("DELETE FROM bill_items WHERE bill_no=?", (bn,))
        c.execute("DELETE FROM bills WHERE bill_no=?", (bn,))
    conn.commit()
    conn.close()
    return len(old_bills)


def count_bills_older_than(days):
    """How many bills are older than `days` days - shown in Settings next
    to the Delete Bills option so the shopkeeper knows what they're about
    to delete before confirming. Pass days=None to count ALL bills."""
    conn = get_connection()
    c = conn.cursor()
    if days is None:
        c.execute("SELECT COUNT(*) FROM bills")
    else:
        cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        c.execute("SELECT COUNT(*) FROM bills WHERE bill_date < ?", (cutoff,))
    count = c.fetchone()[0] or 0
    conn.close()
    return count


def auto_delete_old_completed_dues():
    """Removes fully-PAID dues (and their payment history) once they've
    been sitting completed for longer than the configurable retention
    period (Settings > Completed Dues, default 8 months - see
    DUES_RETENTION_MONTHS_DEFAULT / the 'dues_retention_months' setting).

    Only status='Paid' entries with a completed_at date are ever touched -
    an open/pending due is NEVER auto-deleted no matter how old it is."""
    try:
        months = float(get_setting("dues_retention_months", str(DUES_RETENTION_MONTHS_DEFAULT)))
    except ValueError:
        months = DUES_RETENTION_MONTHS_DEFAULT
    if months <= 0:
        return  # 0 (or negative) means "keep completed dues forever"
    cutoff_days = int(months * 30.44)  # average days/month, good enough here
    cutoff = (datetime.now() - timedelta(days=cutoff_days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT id FROM customer_dues WHERE status='Paid' AND completed_at IS NOT NULL AND completed_at < ?",
        (cutoff,),
    )
    old_dues = [row[0] for row in c.fetchall()]
    for due_id in old_dues:
        c.execute("DELETE FROM due_payments WHERE due_id=?", (due_id,))
        c.execute("DELETE FROM customer_dues WHERE id=?", (due_id,))
    conn.commit()
    conn.close()
    return len(old_dues)


# ---------------- GST AUTO-SAVE (daily) ----------------
# Bills are no longer auto-deleted (deleting bills is now a manual,
# Settings-triggered action - see delete_bills_older_than()). If the
# shopkeeper has switched on "GST Auto-Save" in Settings, this quietly
# writes out a GST-filing-ready Excel of every bill since the last
# auto-save, once every day, so nothing needed for GST returns is ever
# lost, with zero manual effort.
GST_AUTOSAVE_FOLDER = os.path.join(BASE_DIR, "GST_AutoSaved_Reports")
GST_AUTOSAVE_INTERVAL_DAYS = 1  # how often the auto-save runs, when ON
GST_AUTOSAVE_FIRST_RUN_LOOKBACK_DAYS = 90  # on the very first auto-save
                           # ever (no "last saved" date yet), look back
                           # this many days to pick up existing bills too.


def auto_export_gst_if_due():
    """Runs quietly (no popups) on every app startup. Does nothing unless
    the 'gst_autosave_enabled' setting is ON and at least
    GST_AUTOSAVE_INTERVAL_DAYS (1 day) have passed since the last
    auto-save."""
    try:
        if get_setting("gst_autosave_enabled", "0") != "1":
            return
        last = get_setting("gst_last_autosave", "")
        now = datetime.now()
        if last:
            try:
                last_dt = datetime.strptime(last, "%Y-%m-%d")
            except ValueError:
                last_dt = None
        else:
            last_dt = None

        if last_dt and (now - last_dt).days < GST_AUTOSAVE_INTERVAL_DAYS:
            return  # not due yet

        start_date = last_dt.strftime("%Y-%m-%d 00:00:00") if last_dt else \
            (now - timedelta(days=GST_AUTOSAVE_FIRST_RUN_LOOKBACK_DAYS)).strftime("%Y-%m-%d 00:00:00")
        bills = get_bills_for_gst_export(start_date)
        if bills:
            _write_gst_excel(bills, GST_AUTOSAVE_FOLDER,
                              f"GST_AutoSave_{now.strftime('%Y-%m-%d')}.xlsx")
        # Mark as done even if there were no bills today, so it doesn't
        # try again until the next daily window is due.
        save_setting("gst_last_autosave", now.strftime("%Y-%m-%d"))
    except Exception:
        # Never let a background auto-save problem stop the app opening.
        pass


def _write_gst_excel(bills, folder, filename):
    """Shared plain-openpyxl writer used by the automatic daily GST
    Auto-Save. Columns: S.No, Invoice No, Invoice Date, Customer Name,
    Contact No, GSTIN, HSN/SAC Code, Taxable Value, CGST, SGST, IGST,
    Total Invoice Value - the same GST-filing layout as the manual
    'Export to Excel (GST Filing Format)' button, minus Payment Status
    (not needed for GST filing) and plus GSTIN/HSN so it is ready to
    hand straight to an accountant."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = "GST Sales Report"

    shop = get_shop_details()
    bold = Font(bold=True)
    title_font = Font(bold=True, size=14)
    header_fill = PatternFill("solid", fgColor="1E3A5F")
    header_font = Font(bold=True, color="FFFFFF")
    thin = Side(style="thin", color="94A3B8")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center")
    right = Alignment(horizontal="right", vertical="center")

    headers = ["S.No", "Invoice No", "Invoice Date", "Customer Name", "Contact No",
               "GSTIN", "HSN/SAC Code", "Taxable Value (₹)", "CGST (₹)", "SGST (₹)",
               "IGST (₹)", "Total Invoice Value (₹)"]

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    ws.cell(row=1, column=1, value=f"{shop['shop_name']} - GST Auto-Saved Sales Report").font = title_font
    ws.cell(row=1, column=1).alignment = center

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(headers))
    ws.cell(row=2, column=1, value=f"Auto-saved on: {datetime.now().strftime('%d-%b-%Y')}").font = bold
    ws.cell(row=2, column=1).alignment = center

    header_row = 4
    for col, text in enumerate(headers, start=1):
        cell = ws.cell(row=header_row, column=col, value=text)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center
        cell.border = border

    total_taxable = total_cgst = total_sgst = total_igst = total_invoice = 0.0
    row_num = header_row + 1
    for i, (bno, date, name, contact, gstin, hsn_code, grand_total, gst_amount) in enumerate(bills, start=1):
        taxable_value = grand_total - gst_amount
        cgst = gst_amount / 2
        sgst = gst_amount / 2
        igst = 0.0

        values = [i, bno, date[:10], name, contact, gstin or "", hsn_code or "",
                  round(taxable_value, 2), round(cgst, 2), round(sgst, 2), round(igst, 2),
                  round(grand_total, 2)]
        for col, val in enumerate(values, start=1):
            cell = ws.cell(row=row_num, column=col, value=val)
            cell.border = border
            if col in (1, 2, 3, 6, 7):
                cell.alignment = center
            elif col in (8, 9, 10, 11, 12):
                cell.alignment = right
                cell.number_format = "#,##0.00"

        total_taxable += taxable_value
        total_cgst += cgst
        total_sgst += sgst
        total_igst += igst
        total_invoice += grand_total
        row_num += 1

    ws.merge_cells(start_row=row_num, start_column=1, end_row=row_num, end_column=7)
    total_label_cell = ws.cell(row=row_num, column=1, value="TOTAL")
    total_label_cell.font = bold
    total_label_cell.alignment = center
    total_label_cell.border = border
    for col in range(2, 8):
        ws.cell(row=row_num, column=col).border = border

    totals = [total_taxable, total_cgst, total_sgst, total_igst, total_invoice]
    for offset, val in enumerate(totals):
        col = 8 + offset
        cell = ws.cell(row=row_num, column=col, value=round(val, 2))
        cell.font = bold
        cell.number_format = "#,##0.00"
        cell.alignment = right
        cell.border = border

    widths = [6, 10, 13, 24, 14, 18, 14, 16, 12, 12, 12, 18]
    for col, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col)].width = w

    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
    wb.save(path)
    return path


# ---------------- PRODUCTS ----------------
# name = the product name as typed by the shopkeeper (Tamil or English).
# tamil_name is kept equal to name (only for old-file compatibility).

def add_product(product_id, name, price, gst_percent=0, cost_price=0, stock=0):
    conn = get_connection()
    conn.execute(
        "INSERT INTO products (product_id, name, tamil_name, stock, price, gst_percent, cost_price) "
        "VALUES (?,?,?,?,?,?,?)",
        (product_id, name, name, stock, price, gst_percent, cost_price),
    )
    conn.commit()
    conn.close()


def update_product(product_id, name, price, gst_percent=0, cost_price=None):
    """cost_price=None leaves the product's existing cost price untouched
    (the Products popup doesn't manage cost price - only Stock Entry does)."""
    conn = get_connection()
    if cost_price is None:
        conn.execute(
            "UPDATE products SET name=?, tamil_name=?, price=?, gst_percent=? WHERE product_id=?",
            (name, name, price, gst_percent, product_id),
        )
    else:
        conn.execute(
            "UPDATE products SET name=?, tamil_name=?, price=?, gst_percent=?, cost_price=? WHERE product_id=?",
            (name, name, price, gst_percent, cost_price, product_id),
        )
    conn.commit()
    conn.close()


def upsert_product(product_id, name, price, gst_percent=0):
    """Add the product if product_id is new, or silently update its name /
    price / gst if that product_id already exists - never raises a
    duplicate-ID error. Used by the billing screen so a shopkeeper can
    correct a product's name right there while making a bill and have it
    saved back to the product list automatically."""
    conn = get_connection()
    conn.execute(
        """INSERT INTO products (product_id, name, tamil_name, stock, price, gst_percent)
           VALUES (?,?,?,0,?,?)
           ON CONFLICT(product_id) DO UPDATE SET
               name=excluded.name,
               tamil_name=excluded.tamil_name,
               price=excluded.price,
               gst_percent=excluded.gst_percent""",
        (product_id, name, name, price, gst_percent),
    )
    conn.commit()
    conn.close()


def delete_product(product_id):
    conn = get_connection()
    conn.execute("DELETE FROM products WHERE product_id=?", (product_id,))
    conn.commit()
    conn.close()


def get_product(product_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT product_id, name, price, gst_percent FROM products WHERE product_id=?", (product_id,))
    row = c.fetchone()
    conn.close()
    return row


def get_product_by_name(name):
    """Case/space-insensitive lookup used to warn the shopkeeper before a
    duplicate product (same name, different Product ID) gets added."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT product_id, name, price, gst_percent FROM products "
        "WHERE TRIM(LOWER(name)) = TRIM(LOWER(?)) LIMIT 1",
        (name,),
    )
    row = c.fetchone()
    conn.close()
    return row


def search_products(prefix):
    conn = get_connection()
    c = conn.cursor()
    like = f"%{prefix}%"
    c.execute(
        "SELECT product_id, name, price, gst_percent FROM products "
        "WHERE product_id LIKE ? OR name LIKE ? ORDER BY name",
        (like, like),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def search_products_by_id(prefix):
    """Same as search_products, but matches ONLY on Product ID (not on
    name). Used by the billing screen's Product ID box so its dropdown
    stays purely ID-based - typing a product NAME there should not pull
    up matches."""
    conn = get_connection()
    c = conn.cursor()
    like = f"%{prefix}%"
    c.execute(
        "SELECT product_id, name, price, gst_percent FROM products "
        "WHERE product_id LIKE ? ORDER BY name",
        (like,),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_products():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT product_id, name, price, gst_percent FROM products ORDER BY name")
    rows = c.fetchall()
    conn.close()
    return rows


# ---------------- PRODUCT STOCK ENTRY (stock / cost price / selling price) ----------------
# Cost Price (CP) is only ever used to calculate profit in Stats - it is
# never shown or printed on a bill. Selling Price (SP) is the same
# "price" column products/billing already use everywhere else, so
# changing it here updates it for the whole app (billing screen,
# Products popup, receipts) too.

def get_product_full(product_id):
    """product_id, name, stock, price (selling price), cost_price, gst_percent"""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT product_id, name, stock, price, cost_price, gst_percent FROM products WHERE product_id=?",
        (product_id,),
    )
    row = c.fetchone()
    conn.close()
    return row


def search_products_full(prefix):
    conn = get_connection()
    c = conn.cursor()
    like = f"%{prefix}%"
    c.execute(
        "SELECT product_id, name, stock, price, cost_price FROM products "
        "WHERE product_id LIKE ? OR name LIKE ? ORDER BY name",
        (like, like),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_products_full():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT product_id, name, stock, price, cost_price FROM products ORDER BY name")
    rows = c.fetchall()
    conn.close()
    return rows


def export_products_to_file(path):
    """Save every product's full data (ID, name, Tamil name, stock,
    price, GST %, cost price) to a JSON file - a standalone products-only
    backup, separate from the full database backup, so it doesn't carry
    any customer/bill/dues data along with it.

    Returns the number of products written."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT product_id, name, tamil_name, stock, price, gst_percent, cost_price "
        "FROM products ORDER BY name"
    )
    rows = c.fetchall()
    conn.close()

    products = [
        {
            "product_id": pid,
            "name": name,
            "tamil_name": tamil_name,
            "stock": stock,
            "price": price,
            "gst_percent": gst_percent,
            "cost_price": cost_price,
        }
        for pid, name, tamil_name, stock, price, gst_percent, cost_price in rows
    ]

    with open(path, "w", encoding="utf-8") as f:
        json.dump({"products": products}, f, ensure_ascii=False, indent=2)

    return len(products)


def import_products_from_file(path):
    """Restore products from a JSON file created by
    export_products_to_file(). This REPLACES the entire products table
    with whatever's in the file (same as how the full database Restore
    works) - customers, bills, and dues are completely untouched since
    they live in separate tables.

    Returns the number of products restored."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    products = data.get("products", []) if isinstance(data, dict) else data

    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM products")
    for p in products:
        c.execute(
            "INSERT INTO products (product_id, name, tamil_name, stock, price, gst_percent, cost_price) "
            "VALUES (?,?,?,?,?,?,?)",
            (
                p.get("product_id"),
                p.get("name"),
                p.get("tamil_name"),
                p.get("stock", 0),
                p.get("price", 0),
                p.get("gst_percent", 0),
                p.get("cost_price", 0),
            )
        )
    conn.commit()
    conn.close()
    return len(products)


def update_stock_entry(product_id, stock, cost_price, price):
    """Sets a product's Stock Count, Cost Price, and Selling Price from the
    Stock Entry screen. Stock is set directly (not added on top) - however
    negative it ends up, it's saved as-is, no error is raised (a shop can
    genuinely go stock-negative if it's not been counted in a while - this
    never blocks the update). Selling Price written here is the SAME
    "price" column used everywhere else, so it updates instantly across
    the whole app (billing screen, Products list, receipts)."""
    conn = get_connection()
    conn.execute(
        "UPDATE products SET stock=?, cost_price=?, price=? WHERE product_id=?",
        (stock, cost_price, price, product_id),
    )
    conn.commit()
    conn.close()


# ---------------- CUSTOMERS ----------------

def add_customer(name, contact, address):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT INTO customers (name, contact, address) VALUES (?,?,?)", (name, contact, address))
    conn.commit()
    cid = c.lastrowid
    conn.close()
    return cid


def update_customer(customer_id, name, contact, address):
    conn = get_connection()
    conn.execute(
        "UPDATE customers SET name=?, contact=?, address=? WHERE customer_id=?",
        (name, contact, address, customer_id),
    )
    conn.commit()
    conn.close()


def delete_customer(customer_id):
    conn = get_connection()
    conn.execute("DELETE FROM customers WHERE customer_id=?", (customer_id,))
    conn.commit()
    conn.close()


def search_customers(prefix):
    conn = get_connection()
    c = conn.cursor()
    like = f"%{prefix}%"
    c.execute(
        "SELECT customer_id, name, contact, address FROM customers "
        "WHERE name LIKE ? OR contact LIKE ? ORDER BY name",
        (like, like),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_customers():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT customer_id, name, contact, address FROM customers ORDER BY name")
    rows = c.fetchall()
    conn.close()
    return rows


def get_customer(customer_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT customer_id, name, contact, address FROM customers WHERE customer_id=?", (customer_id,))
    row = c.fetchone()
    conn.close()
    return row


def get_recent_customer_product_prices(customer_id, product_id, limit=5):
    """Last `limit` prices this exact customer was billed for this exact
    product, most recent first. Used by the billing screen to suggest a
    rate while typing the Price field, so a shopkeeper can quickly see
    'what did we charge this person for this item last time'."""
    if not customer_id or not product_id:
        return []
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bi.price, bi.qty, b.bill_date FROM bill_items bi "
        "JOIN bills b ON bi.bill_no = b.bill_no "
        "WHERE b.customer_id=? AND bi.product_id=? "
        "ORDER BY b.bill_no DESC LIMIT ?",
        (customer_id, product_id, limit),
    )
    rows = c.fetchall()
    conn.close()
    return rows


# ---------------- BILLS ----------------

def _insert_bill_items_and_take_stock(c, bill_no, items):
    """Shared by create_bill/update_bill: inserts each line, stamping in
    that product's CURRENT Cost Price at the moment of billing (so Stats
    profit stays correct even if CP is changed later in Stock Entry), and
    reduces that product's stock by the qty sold. If stock runs out or
    goes below zero, nothing blocks the sale - it's simply saved as a
    negative stock number, same as Stock Entry allows."""
    for it in items:
        c.execute("SELECT stock, cost_price FROM products WHERE product_id=?", (it["product_id"],))
        row = c.fetchone()
        cost_price = row[1] if row else 0
        c.execute(
            "INSERT INTO bill_items (bill_no, product_id, product_name, tamil_name, qty, price, total, cost_price) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (bill_no, it["product_id"], it["product_name"], it["product_name"],
             it["qty"], it["price"], it["total"], cost_price),
        )
        if row is not None:
            new_stock = row[0] - it["qty"]
            c.execute("UPDATE products SET stock=? WHERE product_id=?", (new_stock, it["product_id"]))


def create_bill(customer_id, customer_name, contact, address, grand_total, gst_amount, paid, items,
                 amount_received=0, balance=0, gstin="", hsn_code=""):
    """items = list of dicts: product_id, product_name, qty, price, total"""
    conn = get_connection()
    c = conn.cursor()
    bill_date = datetime.now().strftime("%Y-%m-%d %H:%M")
    c.execute(
        "INSERT INTO bills (bill_date, customer_id, customer_name, contact, address, "
        "grand_total, gst_amount, paid, amount_received, balance, gstin, hsn_code) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (bill_date, customer_id, customer_name, contact, address, grand_total, gst_amount, paid,
         amount_received, balance, gstin, hsn_code),
    )
    bill_no = c.lastrowid
    _insert_bill_items_and_take_stock(c, bill_no, items)
    conn.commit()
    conn.close()
    return bill_no, bill_date


def update_bill(bill_no, customer_id, customer_name, contact, address, grand_total, gst_amount, paid, items,
                 amount_received=0, balance=0, gstin="", hsn_code=""):
    """Overwrite an existing bill's items/details (used when re-opening a
    saved bill from Invoices to add/edit products, then saving again).
    The old items' quantities are first added back to stock, then the
    (possibly changed) new items are re-deducted - so re-editing a bill
    never double-counts stock taken out."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "UPDATE bills SET customer_id=?, customer_name=?, contact=?, address=?, "
        "grand_total=?, gst_amount=?, paid=?, amount_received=?, balance=?, gstin=?, hsn_code=? WHERE bill_no=?",
        (customer_id, customer_name, contact, address, grand_total, gst_amount, paid,
         amount_received, balance, gstin, hsn_code, bill_no),
    )
    c.execute("SELECT product_id, qty FROM bill_items WHERE bill_no=?", (bill_no,))
    old_items = c.fetchall()
    for pid, qty in old_items:
        c.execute("UPDATE products SET stock = stock + ? WHERE product_id=?", (qty, pid))
    c.execute("DELETE FROM bill_items WHERE bill_no=?", (bill_no,))
    _insert_bill_items_and_take_stock(c, bill_no, items)
    conn.commit()
    conn.close()


def get_all_bills():
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bill_no, bill_date, customer_name, contact, grand_total, paid, "
        "amount_received, balance FROM bills ORDER BY bill_no DESC"
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_bills_page(from_date=None, to_date=None, search=None, before_bill_no=None, limit=150):
    """Fetch one page of bills, newest first, for the Invoice Viewer.

    - from_date/to_date: 'YYYY-MM-DD' strings (inclusive on both ends),
      or None for no bound on that side.
    - search: matches Bill No, Customer, Contact, Date, or Status.
    - before_bill_no: only bills with bill_no < this are returned, so
      calling again with the smallest bill_no seen so far pages further
      back in time ("Load More") without re-scanning rows already shown.
    - limit: max rows returned - keeps the viewer fast even when a shop
      has years of bills (bills are kept forever - never auto-deleted).
    """
    conn = get_connection()
    c = conn.cursor()
    where = []
    params = []
    if from_date:
        where.append("bill_date >= ?")
        params.append(from_date)
    if to_date:
        where.append("bill_date <= ?")
        params.append(f"{to_date} 23:59:59")
    if before_bill_no is not None:
        where.append("bill_no < ?")
        params.append(before_bill_no)
    if search:
        where.append(
            "(CAST(bill_no AS TEXT) LIKE ? OR bill_date LIKE ? OR "
            "customer_name LIKE ? OR contact LIKE ? OR paid LIKE ?)"
        )
        like = f"%{search}%"
        params.extend([like, like, like, like, like])
    sql = ("SELECT bill_no, bill_date, customer_name, contact, grand_total, paid, "
           "amount_received, balance FROM bills")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY bill_no DESC LIMIT ?"
    params.append(limit)
    c.execute(sql, params)
    rows = c.fetchall()
    conn.close()
    return rows


def get_earliest_bill_date():
    """Returns the bill_date (text) of the very oldest bill on record, or
    None if there are no bills yet. Used by the Invoice Viewer to know
    when "Load More" has reached the beginning of history and can stop."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT MIN(bill_date) FROM bills")
    row = c.fetchone()
    conn.close()
    return row[0] if row else None


def get_bill(bill_no):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bill_no, bill_date, customer_id, customer_name, contact, address, "
        "grand_total, gst_amount, paid, amount_received, balance, "
        "COALESCE(gstin, ''), COALESCE(hsn_code, '') FROM bills WHERE bill_no=?",
        (bill_no,),
    )
    bill = c.fetchone()
    c.execute(
        "SELECT product_id, product_name, qty, price, total FROM bill_items WHERE bill_no=?",
        (bill_no,),
    )
    items = c.fetchall()
    conn.close()
    return bill, items


def update_paid_status(bill_no, paid):
    conn = get_connection()
    conn.execute("UPDATE bills SET paid=? WHERE bill_no=?", (paid, bill_no))
    conn.commit()
    conn.close()


# ---------------- SETTINGS & ADMIN FUNCTIONS ----------------

def get_shop_details():
    """Load shop details from the settings table, returning defaults if not configured."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT key, value FROM settings")
    rows = c.fetchall()
    conn.close()
    
    details = {
        "shop_name": "SAKTHI STORES",
        "shop_address": "Bhuvanagiri",
        "shop_phone": "Ph: 9944993944",
        # Shop's own GSTIN, shown on printed bills only when set here.
        # Left blank by default - printing skips the GSTIN line entirely
        # for shops that don't have one yet.
        "shop_gstin": ""
    }
    for k, v in rows:
        if k in details:
            details[k] = v
    return details


def save_shop_details(name, address, phone, gstin=""):
    """Save or update shop details in the settings table."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_name', ?)", (name,))
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_address', ?)", (address,))
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_phone', ?)", (phone,))
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_gstin', ?)", (gstin,))
    conn.commit()
    conn.close()


def get_db_stats():
    """Retrieve total count of customers, products, bills, and outstanding dues info."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM customers")
    cust_count = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM products")
    prod_count = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM bills")
    bill_count = c.fetchone()[0]
    
    # Dues count and total outstanding balance - only OPEN dues; completed
    # ones now persist in this table (for Completed Dues) but shouldn't
    # count toward outstanding totals.
    c.execute("SELECT COUNT(*), SUM(balance_due) FROM customer_dues WHERE status!='Paid'")
    due_row = c.fetchone()
    due_count = due_row[0] if due_row else 0
    due_sum = due_row[1] if due_row and due_row[1] else 0.0
    
    conn.close()
    return {
        "customers": cust_count,
        "products": prod_count,
        "bills": bill_count,
        "dues_count": due_count,
        "dues_sum": due_sum
    }


def delete_all_customers():
    """Delete all customers from database safely, clearing foreign key references in bills."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE bills SET customer_id = NULL")
    c.execute("DELETE FROM customers")
    conn.commit()
    conn.close()


def delete_all_products():
    """Delete all products from the products table."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM products")
    conn.commit()
    conn.close()


def delete_all_bills():
    """Delete all bills and their corresponding bill items from database."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM bill_items")
    c.execute("DELETE FROM bills")
    conn.commit()
    conn.close()


def reset_everything():
    """Wipe the ENTIRE database - customers, products, bills, dues/payment
    history, and shop settings (name/address/phone) - back to a clean
    slate. Used to re-purpose one installation of the app for a brand new
    shop."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM bill_items")
    c.execute("DELETE FROM bills")
    c.execute("DELETE FROM due_payments")
    c.execute("DELETE FROM customer_dues")
    c.execute("DELETE FROM customers")
    c.execute("DELETE FROM products")
    c.execute("DELETE FROM settings")
    conn.commit()
    conn.close()


def get_total_sales_pie_stats():
    """Sum total sales grouped by paid status (Paid vs Not Paid) overall."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT COALESCE(paid, 'Not Paid') as status, SUM(grand_total) FROM bills "
        "GROUP BY status"
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_product_high_sales_stats(start_date):
    """Retrieve product sales revenue grouped by product name since start_date."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bi.product_name, SUM(bi.total) as revenue FROM bill_items bi "
        "JOIN bills b ON bi.bill_no = b.bill_no "
        "WHERE b.bill_date >= ? "
        "GROUP BY bi.product_name ORDER BY revenue DESC",
        (start_date,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_customer_repeated_stats(start_date):
    """Count repeat visits/bills per customer name since start_date."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT COALESCE(customer_name, 'Walk-in Customer') as name, COUNT(bill_no) as visit_count FROM bills "
        "WHERE bill_date >= ? "
        "GROUP BY name ORDER BY visit_count DESC",
        (start_date,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_product_sales_stats(start_date):
    """Fetch all product sales statistics (quantity and total revenue) since start_date."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bi.product_name, SUM(bi.qty) as total_qty, SUM(bi.total) as total_revenue FROM bill_items bi "
        "JOIN bills b ON bi.bill_no = b.bill_no "
        "WHERE b.bill_date >= ? "
        "GROUP BY bi.product_name ORDER BY total_revenue DESC",
        (start_date,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_customer_sales_stats(start_date):
    """Fetch all customer purchase statistics (visit/bill count and total purchase amount) since start_date."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT COALESCE(customer_name, 'Walk-in Customer') as cust_name, COUNT(bill_no) as bill_count, SUM(grand_total) as total_amount FROM bills "
        "WHERE bill_date >= ? "
        "GROUP BY cust_name ORDER BY total_amount DESC",
        (start_date,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_all_bills_in_range(start_date):
    """Fetch all bills/invoices including transaction details since start_date."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT bill_no, bill_date, COALESCE(customer_name, 'Walk-in Customer'), grand_total, paid FROM bills "
        "WHERE bill_date >= ? ORDER BY bill_no DESC",
        (start_date,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_bills_for_gst_export(start_date, end_date=None):
    """Bill-wise data laid out the way GST return filing (Sales/Outward
    Supply register) needs: Invoice No, Invoice Date, Customer Name,
    Contact, GSTIN, HSN/SAC Code, Taxable Value (sale amount before GST),
    CGST, SGST (GST is split evenly between the two for intra-state
    sales - IGST is left at 0 since this is a single local shop), and
    Total Invoice Value. (Payment Status isn't included here - it isn't
    needed for GST filing.)

    If end_date is given, only bills between start_date and end_date
    (inclusive) are returned; otherwise everything from start_date
    onwards is returned, same as before."""
    conn = get_connection()
    c = conn.cursor()
    if end_date:
        c.execute(
            "SELECT bill_no, bill_date, COALESCE(customer_name, 'Walk-in Customer'), "
            "COALESCE(contact, ''), COALESCE(gstin, ''), COALESCE(hsn_code, ''), "
            "grand_total, COALESCE(gst_amount, 0) FROM bills "
            "WHERE bill_date >= ? AND bill_date <= ? ORDER BY bill_no ASC",
            (start_date, end_date)
        )
    else:
        c.execute(
            "SELECT bill_no, bill_date, COALESCE(customer_name, 'Walk-in Customer'), "
            "COALESCE(contact, ''), COALESCE(gstin, ''), COALESCE(hsn_code, ''), "
            "grand_total, COALESCE(gst_amount, 0) FROM bills "
            "WHERE bill_date >= ? ORDER BY bill_no ASC",
            (start_date,)
        )
    rows = c.fetchall()
    conn.close()
    return rows


def get_profit_summary():
    """Today's total profit and this calendar month's total profit, both
    computed automatically from each bill line's Selling Price minus the
    Cost Price that was saved for that product at the time it was billed:
    profit = qty * (price - cost_price), summed up."""
    conn = get_connection()
    c = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    month = datetime.now().strftime("%Y-%m")
    c.execute(
        "SELECT COALESCE(SUM(bi.qty * (bi.price - bi.cost_price)), 0) FROM bill_items bi "
        "JOIN bills b ON bi.bill_no = b.bill_no WHERE substr(b.bill_date, 1, 10) = ?",
        (today,),
    )
    daily_profit = c.fetchone()[0] or 0.0
    c.execute(
        "SELECT COALESCE(SUM(bi.qty * (bi.price - bi.cost_price)), 0) FROM bill_items bi "
        "JOIN bills b ON bi.bill_no = b.bill_no WHERE substr(b.bill_date, 1, 7) = ?",
        (month,),
    )
    monthly_profit = c.fetchone()[0] or 0.0
    conn.close()
    return daily_profit, monthly_profit


def get_monthly_profit_report(months=12):
    """Month-wise profit for the trailing `months` calendar months
    (this month included), oldest to newest - e.g. Aug-2025, Sep-2025,
    ... Jul-2026. Each entry is (year, month, "Mon-YYYY" label, total
    profit for that month).

    This is calculated fresh from the bills every time rather than
    stored anywhere, so it always reflects a rolling last-12-months
    window automatically: once August 2026 arrives, August 2025 simply
    falls outside the window and is no longer included - there's no
    separate "last year's Jan" record sitting around to manually delete
    or replace, the window just moves forward with today's date.
    """
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT substr(b.bill_date, 1, 7) as ym, "
        "COALESCE(SUM(bi.qty * (bi.price - bi.cost_price)), 0) as profit "
        "FROM bills b LEFT JOIN bill_items bi ON b.bill_no = bi.bill_no "
        "GROUP BY ym"
    )
    profit_by_ym = {row[0]: row[1] or 0.0 for row in c.fetchall()}
    conn.close()

    # Build the last `months` calendar months ending with the current
    # one, oldest first, filling in 0 profit for months with no bills.
    today = datetime.now().date().replace(day=1)
    result = []
    for i in range(months - 1, -1, -1):
        y, m = today.year, today.month - i
        while m <= 0:
            m += 12
            y -= 1
        ym = f"{y:04d}-{m:02d}"
        label = f"{datetime(y, m, 1).strftime('%b')}-{y}"
        result.append((y, m, label, profit_by_ym.get(ym, 0.0)))
    return result


def get_bill_profit_report(start_date):
    """Per-bill profit table since start_date: each bill's total sale
    amount alongside its profit (Selling Price - Cost Price, per line,
    summed for that bill) - calculated automatically, nothing to type in."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT b.bill_no, b.bill_date, COALESCE(b.customer_name, 'Walk-in Customer'), "
        "b.grand_total, COALESCE(SUM(bi.qty * (bi.price - bi.cost_price)), 0) as profit "
        "FROM bills b LEFT JOIN bill_items bi ON b.bill_no = bi.bill_no "
        "WHERE b.bill_date >= ? GROUP BY b.bill_no ORDER BY b.bill_no DESC",
        (start_date,),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_due_adjustment_amount(bill_no):
    """How much of this bill's shortfall/overpayment (balance) was already
    pushed into the Dues Ledger the last time it was saved with 'Add/
    Reduce Due' ticked. 0 means never applied yet (or the balance was
    exactly 0 last time, which needs no adjustment either way)."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT due_adjustment_amount FROM bills WHERE bill_no=?", (bill_no,))
    row = c.fetchone()
    conn.close()
    return row[0] if row and row[0] is not None else 0.0


def set_due_adjustment_amount(bill_no, amount):
    """Record that this bill's due ledger adjustment now stands at
    `amount` (same sign convention as the billing screen's balance:
    negative = shortfall added to due, positive = overpayment reducing
    due). Called right after applying an adjustment so the same bill,
    if reopened and saved again later, only tops up the difference."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE bills SET due_adjustment_amount=? WHERE bill_no=?", (amount, bill_no))
    conn.commit()
    conn.close()


def add_customer_due(customer_id, customer_name, contact, total_due, bill_no=None):
    """Add a customer credit/due amount.

    If this customer already has an open (not-yet-fully-paid) due entry,
    the new amount is added onto that SAME entry instead of creating a
    separate duplicate row - so a customer only ever has one running due
    entry at a time. A brand new entry is only created if they have no
    open due (either it's their first due, or their previous due was
    already fully paid off and removed).

    `bill_no`: pass this when the due is being added/adjusted automatically
    from a bill (the "Add/Reduce Due" checkbox on the billing screen) so
    the repayment-log remarks show exactly which bill it came from, e.g.
    "Additional due added (Bill #123)". Left as None for dues added
    manually from the Dues Ledger screen, which aren't tied to any bill."""
    conn = get_connection()
    c = conn.cursor()

    if customer_id:
        c.execute(
            "SELECT id, total_due, balance_due FROM customer_dues "
            "WHERE customer_id=? AND status!='Paid' ORDER BY id DESC LIMIT 1",
            (customer_id,)
        )
    else:
        c.execute(
            "SELECT id, total_due, balance_due FROM customer_dues "
            "WHERE customer_id IS NULL AND customer_name=? AND status!='Paid' ORDER BY id DESC LIMIT 1",
            (customer_name,)
        )
    existing = c.fetchone()

    if existing:
        due_id, old_total, old_balance = existing
        new_total = old_total + total_due
        new_balance = old_balance + total_due
        if contact:
            c.execute(
                "UPDATE customer_dues SET total_due=?, balance_due=?, contact=?, status='Pending' WHERE id=?",
                (new_total, new_balance, contact, due_id)
            )
        else:
            c.execute(
                "UPDATE customer_dues SET total_due=?, balance_due=?, status='Pending' WHERE id=?",
                (new_total, new_balance, due_id)
            )
        # Log this as a "due added" event in the same timeline as
        # repayments, so the log shows exactly when extra credit was
        # given on top of an already-open due.
        event_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        remarks = f"Additional due added (Bill #{bill_no})" if bill_no else "Additional due added"
        c.execute(
            "INSERT INTO due_payments (due_id, amount_paid, payment_date, remarks, entry_type) VALUES (?,?,?,?,?)",
            (due_id, total_due, event_date, remarks, "due_added")
        )
        conn.commit()
        conn.close()
        return due_id

    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute(
        "INSERT INTO customer_dues (customer_id, customer_name, contact, total_due, balance_due, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (customer_id, customer_name, contact, total_due, total_due, created_at)
    )
    new_id = c.lastrowid
    # Log the very FIRST due too, in the same due_payments timeline used
    # for later "additional due added" / payment events. Previously only
    # entries added onto an ALREADY-open due got logged here, so a
    # customer's first-ever due entry never showed up in the Repayment
    # Log table until their second entry or first payment came in.
    first_entry_remarks = f"First due entry (Bill #{bill_no})" if bill_no else "First due entry"
    c.execute(
        "INSERT INTO due_payments (due_id, amount_paid, payment_date, remarks, entry_type) VALUES (?,?,?,?,?)",
        (new_id, total_due, created_at, first_entry_remarks, "due_added")
    )
    conn.commit()
    conn.close()
    return new_id


def record_due_payment(due_id, amount_paid, remarks=""):
    """Log a repayment and update the remaining due balance.

    Every partial payment (and any additional due added later) is logged
    to due_payments so the full timeline is visible while the due is
    still open. Once a payment brings the balance down to ₹0, the due is
    considered fully settled: it's marked status='Paid' with a
    completed_at timestamp and disappears from the active Dues Registry,
    but the entry AND its complete payment history are kept (not
    deleted) so they can still be reviewed under Completed Dues.

    Returns True if this payment fully cleared the due, False if the due
    is still open."""
    conn = get_connection()
    c = conn.cursor()
    payment_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute(
        "INSERT INTO due_payments (due_id, amount_paid, payment_date, remarks, entry_type) VALUES (?,?,?,?,?)",
        (due_id, amount_paid, payment_date, remarks, "payment")
    )
    c.execute("SELECT total_due, balance_due FROM customer_dues WHERE id=?", (due_id,))
    row = c.fetchone()
    fully_paid = False
    if row:
        total_due, balance_due = row
        new_balance = max(0.0, balance_due - amount_paid)
        if new_balance <= 0:
            fully_paid = True
            # Due complete - keep the record, just mark it settled.
            c.execute(
                "UPDATE customer_dues SET balance_due=0, status='Paid', completed_at=? WHERE id=?",
                (payment_date, due_id)
            )
        else:
            c.execute(
                "UPDATE customer_dues SET balance_due=?, status='Pending' WHERE id=?",
                (new_balance, due_id)
            )
    conn.commit()
    conn.close()
    return fully_paid


def get_open_due_for_customer(customer_id, customer_name):
    """Look up this customer's single open (not fully paid) due entry, if
    any - used by the billing screen's 'Adjust to Due' option to check
    whether there's an existing due to reduce before it tries to.
    Returns (due_id, total_due, balance_due) or None."""
    conn = get_connection()
    c = conn.cursor()
    if customer_id:
        c.execute(
            "SELECT id, total_due, balance_due FROM customer_dues "
            "WHERE customer_id=? AND status!='Paid' ORDER BY id DESC LIMIT 1",
            (customer_id,)
        )
    else:
        c.execute(
            "SELECT id, total_due, balance_due FROM customer_dues "
            "WHERE customer_id IS NULL AND customer_name=? AND status!='Paid' ORDER BY id DESC LIMIT 1",
            (customer_name,)
        )
    row = c.fetchone()
    conn.close()
    return row


def get_all_dues(search_text=""):
    """Retrieve list of OPEN (not yet fully paid) dues, optionally
    filtered by customer name search. Completed dues are kept in the
    database but shown separately via get_completed_dues()."""
    conn = get_connection()
    c = conn.cursor()
    if search_text:
        c.execute(
            "SELECT id, customer_name, contact, total_due, balance_due, status, created_at FROM customer_dues "
            "WHERE customer_name LIKE ? AND status!='Paid' ORDER BY status DESC, id DESC",
            (f"%{search_text}%",)
        )
    else:
        c.execute(
            "SELECT id, customer_name, contact, total_due, balance_due, status, created_at FROM customer_dues "
            "WHERE status!='Paid' ORDER BY status DESC, id DESC"
        )
    rows = c.fetchall()
    conn.close()
    return rows


def get_completed_dues(search_text=""):
    """Retrieve fully-paid (status='Paid') dues, most recently completed
    first, optionally filtered by customer name search. Used by the
    Completed Dues screen in the Dues Ledger."""
    conn = get_connection()
    c = conn.cursor()
    if search_text:
        c.execute(
            "SELECT id, customer_name, contact, total_due, created_at, completed_at FROM customer_dues "
            "WHERE customer_name LIKE ? AND status='Paid' ORDER BY completed_at DESC, id DESC",
            (f"%{search_text}%",)
        )
    else:
        c.execute(
            "SELECT id, customer_name, contact, total_due, created_at, completed_at FROM customer_dues "
            "WHERE status='Paid' ORDER BY completed_at DESC, id DESC"
        )
    rows = c.fetchall()
    conn.close()
    return rows


def get_due_payments(due_id):
    """Retrieve the full timeline (partial payments + additional-due
    events) for a given due record, newest first."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT id, amount_paid, payment_date, remarks, entry_type FROM due_payments WHERE due_id=? ORDER BY id DESC",
        (due_id,)
    )
    rows = c.fetchall()
    conn.close()
    return rows


def update_due_customer_info(due_id, customer_name, contact):
    """Correct a typo in the customer name / contact number shown on a
    Dues Registry row. Deliberately does NOT touch total_due / balance_due
    - those numbers are always driven by the Repayment Log underneath
    (see update_due_payment_entry / recalc_customer_due below), so there
    is only ever ONE place amounts get corrected and the two tables can
    never drift out of sync with each other."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "UPDATE customer_dues SET customer_name=?, contact=? WHERE id=?",
        (customer_name, contact, due_id)
    )
    conn.commit()
    conn.close()


def recalc_customer_due(due_id):
    """Recompute total_due & balance_due for a due entry from scratch by
    replaying its own due_payments log:
      total_due   = sum of all 'due_added' entries
      balance_due = total_due - sum of all 'payment' entries
    Used after a log entry is corrected, so the running totals shown in
    the Dues Registry never drift out of sync with the log itself - the
    log is always the single source of truth.

    If the corrected log brings the balance down to ₹0 or below, the due
    is fully settled: it's marked status='Paid' (kept for Completed
    Dues, not deleted). If there are no log entries left at all (e.g.
    the only entry was corrected away), there's nothing left to keep a
    record of, so the due entry itself is removed.

    Returns True if the due was fully paid off (or had nothing left),
    False if it is still open (and updated in place)."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT amount_paid, entry_type FROM due_payments WHERE due_id=?", (due_id,))
    rows = c.fetchall()

    total_due = sum(amt for amt, etype in rows if etype == "due_added")
    balance_due = total_due - sum(amt for amt, etype in rows if etype == "payment")

    if not rows:
        c.execute("DELETE FROM due_payments WHERE due_id=?", (due_id,))
        c.execute("DELETE FROM customer_dues WHERE id=?", (due_id,))
        conn.commit()
        conn.close()
        return True

    if balance_due <= 0:
        completed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute(
            "UPDATE customer_dues SET total_due=?, balance_due=0, status='Paid', completed_at=? WHERE id=?",
            (total_due, completed_at, due_id)
        )
        conn.commit()
        conn.close()
        return True

    c.execute(
        "UPDATE customer_dues SET total_due=?, balance_due=?, status='Pending' WHERE id=?",
        (total_due, balance_due, due_id)
    )
    conn.commit()
    conn.close()
    return False


def update_due_payment_entry(entry_id, amount_paid, remarks, entry_type):
    """Correct a wrongly-entered Repayment Log row (amount / remarks /
    whether it was a payment or an additional-due-added entry), then
    recalculate the parent due's total_due & balance_due from the whole
    corrected log so everything stays consistent.

    Returns (due_id, fully_paid) - fully_paid is True if this correction
    brought the balance to ₹0 and the whole due entry was removed."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT due_id FROM due_payments WHERE id=?", (entry_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        return None, False
    due_id = row[0]
    c.execute(
        "UPDATE due_payments SET amount_paid=?, remarks=?, entry_type=? WHERE id=?",
        (amount_paid, remarks, entry_type, entry_id)
    )
    conn.commit()
    conn.close()
    fully_paid = recalc_customer_due(due_id)
    return due_id, fully_paid


def delete_customer_due(due_id):
    """Delete a customer due entry and all associated payment entries."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM due_payments WHERE due_id=?", (due_id,))
    c.execute("DELETE FROM customer_dues WHERE id=?", (due_id,))
    conn.commit()
    conn.close()


def delete_all_dues():
    """Wipe all customer credit and payment ledger history."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM due_payments")
    c.execute("DELETE FROM customer_dues")
    conn.commit()
    conn.close()


def get_setting(key, default_value=""):
    """Fetch setting value from database config by key."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key=?", (key,))
    row = c.fetchone()
    conn.close()
    return row[0] if row else default_value


# Fixed master override password. Works on every pwd_* gate (app unlock,
# settings, dues ledger, profit report, etc.) NO MATTER what the shop has
# set that gate's own password to in Settings. Changing a password in
# Settings only ever changes the "12345"-style default for that one gate -
# this master word is intentionally hardcoded here (not stored in the DB)
# so it can never be edited, overwritten, or reset by the Settings screen.
MASTER_PASSWORD = "DHINESH"


def check_password(entered, key, default_value="12345"):
    """True if `entered` matches either the shop's saved password for
    `key` (falling back to `default_value` when nothing's been set) or
    the fixed master password. Use this for every password-gated screen
    instead of comparing against get_setting(...) directly."""
    if entered == MASTER_PASSWORD:
        return True
    saved = get_setting(key, default_value)
    return entered == saved


def save_setting(key, value):
    """Save or replace setting value inside SQLite config by key."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()


