"""
stats_window.py
---------------
Business performance and statistics window displaying:
1. Product Sales Count & Revenue (Last 30 Days)
2. Customer Purchase Volume & Count (Last 30 Days)
3. Total Sales Report (Last 30 Days) - Password Protected (pass: "12345")
Uses clean tabbed Notebook and ttk.Treeview tables.
Includes a live search bar at the top to filter tables.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from datetime import datetime, timedelta

import database as db
from ui_theme import apply_theme, stripe_treeview, stripe_tag, FONT_BIG, FONT_BOLD, HEADER_BG, HEADER_FG, CustomPasswordDialog, bordered_table_frame, maximize_window


class DateRangeDialog(tk.Toplevel):
    """Small popup asking for a From Date and To Date (DD-MM-YYYY) before
    exporting the GST Excel report, so the shopkeeper can pick exactly the
    period they need instead of always getting the last 30 days."""

    def __init__(self, parent, default_from, default_to):
        super().__init__(parent)
        self.title("Select Date Range")
        self.geometry("380x230")
        self.resizable(False, False)
        apply_theme(self)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        if parent and parent.winfo_viewable() and parent.winfo_width() > 50 and parent.winfo_height() > 50:
            px = parent.winfo_rootx() + (parent.winfo_width() - 380) // 2
            py = parent.winfo_rooty() + (parent.winfo_height() - 230) // 2
        else:
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            px = (sw - 380) // 2
            py = (sh - 230) // 2
        self.geometry(f"380x230+{max(0, px)}+{max(0, py)}")

        self.result = None  # (start_date, end_date) as datetime.date, or None if cancelled

        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="📅 Select Report Period", font=FONT_BOLD).pack(anchor="w", pady=(0, 12))

        row1 = ttk.Frame(frame)
        row1.pack(fill="x", pady=6)
        ttk.Label(row1, text="From Date (DD-MM-YYYY):", width=22, anchor="w").pack(side="left")
        self.e_from = ttk.Entry(row1, width=14, font=("Segoe UI", 11))
        self.e_from.insert(0, default_from.strftime("%d-%m-%Y"))
        self.e_from.pack(side="left")

        row2 = ttk.Frame(frame)
        row2.pack(fill="x", pady=6)
        ttk.Label(row2, text="To Date (DD-MM-YYYY):", width=22, anchor="w").pack(side="left")
        self.e_to = ttk.Entry(row2, width=14, font=("Segoe UI", 11))
        self.e_to.insert(0, default_to.strftime("%d-%m-%Y"))
        self.e_to.pack(side="left")

        self.e_from.bind("<Return>", self._on_submit)
        self.e_to.bind("<Return>", self._on_submit)
        self.bind("<Escape>", self._on_cancel)

        btn_frame = ttk.Frame(frame, padding=(0, 18, 0, 0))
        btn_frame.pack(fill="x")
        ttk.Button(btn_frame, text="📥 Export", style="Success.TButton",
                   command=self._on_submit).pack(side="left", padx=5, expand=True, fill="x")
        ttk.Button(btn_frame, text="Cancel", style="Secondary.TButton",
                   command=self._on_cancel).pack(side="right", padx=5, expand=True, fill="x")

        self.protocol("WM_DELETE_WINDOW", self._on_cancel)
        self.deiconify()
        self.lift()
        self.attributes("-topmost", True)
        self.after(150, lambda: self.attributes("-topmost", False))
        self.focus_force()
        self.e_from.focus_set()
        self.e_from.selection_range(0, "end")

        self.wait_window()

    def _on_submit(self, event=None):
        from_text = self.e_from.get().strip()
        to_text = self.e_to.get().strip()
        try:
            start = datetime.strptime(from_text, "%d-%m-%Y").date()
            end = datetime.strptime(to_text, "%d-%m-%Y").date()
        except ValueError:
            messagebox.showerror(
                "Invalid Date",
                "Please enter both dates as DD-MM-YYYY (e.g. 05-07-2026).",
                parent=self
            )
            return
        if start > end:
            messagebox.showerror("Invalid Range", "From Date cannot be after To Date.", parent=self)
            return
        self.result = (start, end)
        self.destroy()

    def _on_cancel(self, event=None):
        self.result = None
        self.destroy()


class StatsWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("📊 Business Statistics & Sales Report")
        self.geometry("950x650")
        self.minsize(850, 520)
        apply_theme(self)
        # Opens at a comfortable medium size by default; the user can
        # still maximize it themselves (OS maximize button) if needed.
        # maximize_window(self)
        self.grab_set()

        self.thirty_days_ago = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d 00:00:00")
        self.sales_unlocked = False  # Track password unlock state
        self.profit_unlocked = False  # Track password unlock state for Profit Report

        # Title block
        title_frame = tk.Frame(self, bg=HEADER_BG, pady=10)
        title_frame.pack(fill="x")
        date_str = (datetime.now() - timedelta(days=30)).strftime("%d-%b-%Y")
        title_text = f"📊 Business Stats & Sales Report (Since {date_str})"
        ttk.Label(title_frame, text=title_text, font=FONT_BIG, background=HEADER_BG, foreground=HEADER_FG).pack(anchor="center")

        # Search Block at the top (below title)
        search_frame = ttk.Frame(self, padding=(10, 8, 10, 0))
        search_frame.pack(fill="x")
        
        ttk.Label(search_frame, text="🔍 Live Search Name/Bill No:").pack(side="left", padx=5)
        self.e_search = ttk.Entry(search_frame, font=("Segoe UI", 10), width=35)
        self.e_search.pack(side="left", padx=5)
        self.e_search.bind("<KeyRelease>", self._on_search_key)
        
        btn_clear = ttk.Button(search_frame, text="Clear Search", command=self._clear_search)
        btn_clear.pack(side="left", padx=5)

        # Tabbed Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Tab 1: Product Sales Count
        self.tab_products = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_products, text="📦 Product Sales Count")
        self._build_products_tab()

        # Tab 2: Customer Purchases
        self.tab_customers = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_customers, text="👥 Customer Purchases")
        self._build_customers_tab()

        # Tab 3: Total Sales Report (Gated by password)
        self.tab_sales = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_sales, text="🔒 Total Sales Report")

        # Tab 4: Profit Report - Daily/Monthly profit + per-bill profit table
        # (Gated by its own password, default "12345", editable in Settings)
        self.tab_profit = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_profit, text="🔒 Profit Report")

        # Bind tab changed event
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)

    def _build_products_tab(self):
        table_frame = ttk.Frame(self.tab_products)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("name", "qty", "revenue")
        self.prod_tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=15)
        self.prod_tree.heading("name", text="Product Name")
        self.prod_tree.heading("qty", text="Quantity Sold")
        self.prod_tree.heading("revenue", text="Total Sales Revenue")

        self.prod_tree.column("name", width=400, anchor="w")
        self.prod_tree.column("qty", width=150, anchor="center")
        self.prod_tree.column("revenue", width=200, anchor="e")

        self.prod_tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.prod_tree.yview)
        scroll.pack(side="right", fill="y")
        self.prod_tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.prod_tree)

        self._load_products()

    def _load_products(self, query=""):
        for row in self.prod_tree.get_children():
            self.prod_tree.delete(row)
        try:
            data = db.get_all_product_sales_stats(self.thirty_days_ago)
            idx = 0
            for name, qty, amt in data:
                if query and query not in name.lower():
                    continue
                self.prod_tree.insert("", "end", values=(name, f"{qty:g}", f"₹{amt:,.2f}"), tags=(stripe_tag(idx),))
                idx += 1
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load products stats:\n{str(e)}", parent=self)

    def _build_customers_tab(self):
        table_frame = ttk.Frame(self.tab_customers)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("name", "count", "amount")
        self.cust_tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=15)
        self.cust_tree.heading("name", text="Customer Name")
        self.cust_tree.heading("count", text="Total Bills / Visits")
        self.cust_tree.heading("amount", text="Total Purchase Amount")

        self.cust_tree.column("name", width=400, anchor="w")
        self.cust_tree.column("count", width=150, anchor="center")
        self.cust_tree.column("amount", width=200, anchor="e")

        self.cust_tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.cust_tree.yview)
        scroll.pack(side="right", fill="y")
        self.cust_tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.cust_tree)

        self._load_customers()

    def _load_customers(self, query=""):
        for row in self.cust_tree.get_children():
            self.cust_tree.delete(row)
        try:
            data = db.get_all_customer_sales_stats(self.thirty_days_ago)
            idx = 0
            for name, count, amt in data:
                if query and query not in name.lower():
                    continue
                self.cust_tree.insert("", "end", values=(name, count, f"₹{amt:,.2f}"), tags=(stripe_tag(idx),))
                idx += 1
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load customers stats:\n{str(e)}", parent=self)

    def _build_sales_tab(self):
        if hasattr(self, 'sales_tree'):
            return

        summary_frame = ttk.Frame(self.tab_sales, padding=(0, 5, 0, 15))
        summary_frame.pack(fill="x")

        self.lbl_total_sales = ttk.Label(summary_frame, text="Total Revenue: ₹0.00", font=FONT_BOLD)
        self.lbl_total_sales.pack(side="left", padx=20)

        self.lbl_paid_sales = ttk.Label(summary_frame, text="Paid: ₹0.00", font=FONT_BOLD, foreground="#16a34a")
        self.lbl_paid_sales.pack(side="left", padx=20)

        self.lbl_unpaid_sales = ttk.Label(summary_frame, text="Unpaid: ₹0.00", font=FONT_BOLD, foreground="#dc2626")
        self.lbl_unpaid_sales.pack(side="left", padx=20)

        ttk.Button(summary_frame, text="📥 Export to Excel (GST Filing Format)", style="Success.TButton",
                   command=self.export_sales_excel).pack(side="right", padx=10)

        table_frame = ttk.Frame(self.tab_sales)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("bill_no", "date", "name", "amount", "status")
        self.sales_tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=12)
        self.sales_tree.heading("bill_no", text="Bill No")
        self.sales_tree.heading("date", text="Date")
        self.sales_tree.heading("name", text="Customer Name")
        self.sales_tree.heading("amount", text="Grand Total")
        self.sales_tree.heading("status", text="Payment Status")

        self.sales_tree.column("bill_no", width=80, anchor="center")
        self.sales_tree.column("date", width=150, anchor="center")
        self.sales_tree.column("name", width=300, anchor="w")
        self.sales_tree.column("amount", width=130, anchor="e")
        self.sales_tree.column("status", width=120, anchor="center")

        self.sales_tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.sales_tree.yview)
        scroll.pack(side="right", fill="y")
        self.sales_tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.sales_tree)

        self._load_sales_report()

    def _load_sales_report(self, query=""):
        for row in self.sales_tree.get_children():
            self.sales_tree.delete(row)
        try:
            bills = db.get_all_bills_in_range(self.thirty_days_ago)
            total = 0
            paid = 0
            unpaid = 0
            idx = 0
            for bno, date, name, amt, status in bills:
                if query and (query not in name.lower() and query not in str(bno)):
                    continue
                self.sales_tree.insert("", "end", values=(bno, date[:10], name, f"₹{amt:,.2f}", status), tags=(stripe_tag(idx),))
                total += amt
                if status == "Paid":
                    paid += amt
                else:
                    unpaid += amt
                idx += 1

            self.lbl_total_sales.configure(text=f"Total Revenue: ₹{total:,.2f}")
            self.lbl_paid_sales.configure(text=f"Paid: ₹{paid:,.2f}")
            self.lbl_unpaid_sales.configure(text=f"Unpaid: ₹{unpaid:,.2f}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load sales report:\n{str(e)}", parent=self)

    def export_sales_excel(self):
        """Asks the user to pick a From Date / To Date, then saves the Sales
        Report for exactly that period as a real .xlsx file laid out the
        way an accountant needs it for GST return filing: one row per
        invoice with GSTIN, HSN/SAC Code, Taxable Value, CGST, SGST (GST
        split evenly for intra-state sales - IGST is left at 0 since this
        is one local shop), and Total Invoice Value, plus a totals row at
        the bottom. (Payment Status isn't included - it isn't needed for
        GST filing.)"""
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            messagebox.showerror(
                "Excel export needs one extra package",
                "Saving as Excel needs the 'openpyxl' package, which isn't installed yet.\n\n"
                "Install it once with:\n    pip install openpyxl\n\n"
                "(It's also listed in requirements.txt now - just run "
                "'pip install -r requirements.txt' again.)",
                parent=self,
            )
            return

        # Let the shopkeeper pick exactly which period to export, defaulting
        # to the same last-30-days window shown on screen.
        default_from = (datetime.now() - timedelta(days=30)).date()
        default_to = datetime.now().date()
        dialog = DateRangeDialog(self, default_from, default_to)
        if not dialog.result:
            return  # cancelled
        start_date, end_date = dialog.result

        start_str = start_date.strftime("%Y-%m-%d 00:00:00")
        end_str = end_date.strftime("%Y-%m-%d 23:59:59")

        try:
            bills = db.get_bills_for_gst_export(start_str, end_str)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch sales data:\n{str(e)}", parent=self)
            return

        if not bills:
            messagebox.showinfo("Nothing to export", "There are no bills in the selected date range.", parent=self)
            return

        shop = db.get_shop_details()
        period_start = start_date.strftime("%d-%b-%Y")
        period_end = end_date.strftime("%d-%b-%Y")
        default_name = f"GST_Sales_Report_{start_date.strftime('%Y-%m-%d')}_to_{end_date.strftime('%Y-%m-%d')}.xlsx"

        path = filedialog.asksaveasfilename(
            parent=self,
            title="Save Sales Report as Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel file", "*.xlsx")],
            initialfile=default_name,
        )
        if not path:
            return

        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Sales Report"

            bold = Font(bold=True)
            title_font = Font(bold=True, size=14)
            header_fill = PatternFill("solid", fgColor="1E3A5F")
            header_font = Font(bold=True, color="FFFFFF")
            thin = Side(style="thin", color="94A3B8")
            border = Border(left=thin, right=thin, top=thin, bottom=thin)
            center = Alignment(horizontal="center", vertical="center")
            right = Alignment(horizontal="right", vertical="center")

            headers = ["S.No", "Invoice No", "Invoice Date", "Customer Name", "Contact No",
                       "GSTIN", "HSN/SAC Code", "Taxable Value (₹)", "CGST (₹)", "SGST (₹)", "IGST (₹)",
                       "Total Invoice Value (₹)"]

            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
            ws.cell(row=1, column=1, value=f"{shop['shop_name']} - Sales / Outward Supply Report").font = title_font
            ws.cell(row=1, column=1).alignment = center

            ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(headers))
            ws.cell(row=2, column=1, value=f"Period: {period_start} to {period_end}").font = bold
            ws.cell(row=2, column=1).alignment = center

            header_row = 4
            for col, text in enumerate(headers, start=1):
                cell = ws.cell(row=header_row, column=col, value=text)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center
                cell.border = border

            total_taxable = total_cgst = total_sgst = total_igst = total_invoice = 0.0
            row_num = header_row + 1
            for i, (bno, date, name, contact, gstin, hsn_code, grand_total, gst_amount) in enumerate(bills, start=1):
                taxable_value = grand_total - gst_amount
                cgst = gst_amount / 2
                sgst = gst_amount / 2
                igst = 0.0

                values = [i, bno, date[:10], name, contact, gstin or "", hsn_code or "",
                          round(taxable_value, 2), round(cgst, 2), round(sgst, 2), round(igst, 2),
                          round(grand_total, 2)]
                for col, val in enumerate(values, start=1):
                    cell = ws.cell(row=row_num, column=col, value=val)
                    cell.border = border
                    if col in (1, 2, 3, 6, 7):
                        cell.alignment = center
                    elif col in (8, 9, 10, 11, 12):
                        cell.alignment = right
                        cell.number_format = "#,##0.00"

                total_taxable += taxable_value
                total_cgst += cgst
                total_sgst += sgst
                total_igst += igst
                total_invoice += grand_total
                row_num += 1

            # ---- totals row ----
            ws.merge_cells(start_row=row_num, start_column=1, end_row=row_num, end_column=7)
            total_label_cell = ws.cell(row=row_num, column=1, value="TOTAL")
            total_label_cell.font = bold
            total_label_cell.alignment = center
            total_label_cell.border = border
            for col in range(2, 8):
                ws.cell(row=row_num, column=col).border = border

            totals = [total_taxable, total_cgst, total_sgst, total_igst, total_invoice]
            for offset, val in enumerate(totals):
                col = 8 + offset
                cell = ws.cell(row=row_num, column=col, value=round(val, 2))
                cell.font = bold
                cell.number_format = "#,##0.00"
                cell.alignment = right
                cell.border = border

            # ---- column widths ----
            widths = [6, 10, 13, 24, 14, 18, 14, 16, 12, 12, 12, 18]
            for col, w in enumerate(widths, start=1):
                ws.column_dimensions[get_column_letter(col)].width = w

            ws.freeze_panes = ws.cell(row=header_row + 1, column=1)

            wb.save(path)
            messagebox.showinfo(
                "Saved",
                f"Sales Report saved as Excel:\n{path}\n\n"
                "Laid out as an Invoice-wise Sales Register with Taxable "
                "Value, CGST, SGST, IGST and Total - ready to hand to your "
                "accountant or use for GST return filing.",
                parent=self,
            )
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save Excel file:\n{str(e)}", parent=self)

    def _build_profit_tab(self):
        if hasattr(self, 'profit_tree'):
            return

        summary_frame = ttk.Frame(self.tab_profit, padding=(0, 5, 0, 15))
        summary_frame.pack(fill="x")

        self.lbl_daily_profit = ttk.Label(summary_frame, text="Today's Profit: ₹0.00", font=FONT_BOLD, foreground="#16a34a")
        self.lbl_daily_profit.pack(side="left", padx=20)

        self.lbl_monthly_profit = ttk.Label(summary_frame, text="This Month's Profit: ₹0.00", font=FONT_BOLD, foreground="#2563eb")
        self.lbl_monthly_profit.pack(side="left", padx=20)

        ttk.Label(self.tab_profit, text="Profit per Bill (Last 30 Days)", font=FONT_BOLD).pack(anchor="w", pady=(0, 6))

        table_frame = ttk.Frame(self.tab_profit)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("bill_no", "date", "name", "amount", "profit")
        self.profit_tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=12)
        self.profit_tree.heading("bill_no", text="Bill No")
        self.profit_tree.heading("date", text="Date")
        self.profit_tree.heading("name", text="Customer Name")
        self.profit_tree.heading("amount", text="Grand Total")
        self.profit_tree.heading("profit", text="Profit")

        self.profit_tree.column("bill_no", width=80, anchor="center")
        self.profit_tree.column("date", width=150, anchor="center")
        self.profit_tree.column("name", width=280, anchor="w")
        self.profit_tree.column("amount", width=130, anchor="e")
        self.profit_tree.column("profit", width=130, anchor="e")

        self.profit_tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.profit_tree.yview)
        scroll.pack(side="right", fill="y")
        self.profit_tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.profit_tree)

        self._load_profit_report()

    def _load_profit_report(self, query=""):
        try:
            daily_profit, monthly_profit = db.get_profit_summary()
            self.lbl_daily_profit.configure(text=f"Today's Profit: ₹{daily_profit:,.2f}")
            self.lbl_monthly_profit.configure(text=f"This Month's Profit: ₹{monthly_profit:,.2f}")

            for row in self.profit_tree.get_children():
                self.profit_tree.delete(row)
            bills = db.get_bill_profit_report(self.thirty_days_ago)
            idx = 0
            for bno, date, name, amt, profit in bills:
                if query and (query not in name.lower() and query not in str(bno)):
                    continue
                self.profit_tree.insert(
                    "", "end",
                    values=(bno, date[:10], name, f"₹{amt:,.2f}", f"₹{profit:,.2f}"),
                    tags=(stripe_tag(idx),),
                )
                idx += 1
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load profit report:\n{str(e)}", parent=self)

    def _on_search_key(self, event=None):
        selected_tab = self.notebook.index(self.notebook.select())
        query = self.e_search.get().strip().lower()
        if selected_tab == 0:
            self._load_products(query)
        elif selected_tab == 1:
            self._load_customers(query)
        elif selected_tab == 2 and self.sales_unlocked:
            self._load_sales_report(query)
        elif selected_tab == 3 and self.profit_unlocked:
            self._load_profit_report(query)

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self._on_search_key()

    def _on_tab_changed(self, event):
        selected_tab = self.notebook.index(self.notebook.select())
        if hasattr(self, 'e_search'):
            self.e_search.delete(0, "end")
        
        if selected_tab == 2 and not self.sales_unlocked:
            pwd = CustomPasswordDialog(self, title="Sales Report Access", prompt="Enter password to view Total Sales:").result
            if db.check_password(pwd, "pwd_dues", "12345"):
                self.sales_unlocked = True
                self.notebook.tab(self.tab_sales, text="💰 Total Sales Report")
                self._build_sales_tab()
            else:
                if pwd is not None:
                    messagebox.showerror("Access Denied", "Incorrect Password!", parent=self)
                self.notebook.select(0)
        elif selected_tab == 3 and not self.profit_unlocked:
            pwd = CustomPasswordDialog(self, title="Profit Report Access", prompt="Enter password to view Profit Report:").result
            if db.check_password(pwd, "pwd_profit", "12345"):
                self.profit_unlocked = True
                self.notebook.tab(self.tab_profit, text="💹 Profit Report")
                self._build_profit_tab()
            else:
                if pwd is not None:
                    messagebox.showerror("Access Denied", "Incorrect Password!", parent=self)
                self.notebook.select(0)
