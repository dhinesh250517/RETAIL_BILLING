"""
billing_app.py
----------------
Main window of the Billing Software.

Layout:
 - Top bar: Products | Customers | Invoices | New Bill | Exit
 - Left half : customer search + auto-fill, ONE horizontal product-entry
               row (Product ID, Name, Qty, Price, Total), optional GST,
               paid/not-paid
 - Right half: current bill list (S.No, Name, Qty, Price, Total),
               Bill No & Grand Total shown big on top,
               Save / Print / Save as PDF / Exit buttons below.

Opening a bill from Invoices loads it back in here for editing - Save
then updates that same bill instead of creating a new one.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import os
import sys
import shutil


def resource_path(relative_path):
    """Return an absolute path to a bundled resource.

    Works both when running from source (python main.py) and when
    running as a PyInstaller-built .exe (onefile or onedir), where
    bundled files are extracted to sys._MEIPASS at runtime.
    """
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)

import database as db
import printer
import license_lock
from product_manager import ProductManagerWindow
from stock_entry import StockEntryWindow
from customer_manager import CustomerManagerWindow
from invoice_viewer import InvoiceViewerWindow
from autocomplete import AutocompletePopup, PricePopup
from admin_panel import AdminPanelWindow
from stats_window import StatsWindow
from dues_ledger import DuesLedgerWindow
from ui_theme import (apply_theme, ICON, FONT_BIG, FONT_HUGE, FONT_BOLD, FONT_ENTRY,
                       FONT_ENTRY_LG, HEADER_BG, HEADER_FG, stripe_treeview, stripe_tag, CustomPasswordDialog,
                       bordered_table_frame)


class BillingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("D's billing v1.1.0")   # product name + version (the printed bill still shows your shop name)
        self.geometry("1280x800")
        self.minsize(1150, 680)
        self._start_maximized()
        apply_theme(self)

        # Load shop details from database and update printer variables
        try:
            shop_details = db.get_shop_details()
            printer.SHOP_NAME = shop_details["shop_name"]
            printer.SHOP_ADDRESS = shop_details["shop_address"]
            printer.SHOP_PHONE = shop_details["shop_phone"]
        except Exception:
            pass

        self.current_customer_id = None
        self.current_customer_name = None
        self.sno_counter = 0
        self.bill_items = []
        self.editing_bill_no = None   # set when a saved bill was opened from Invoices to edit
        self.is_saved = True
        self.last_saved_bill = None
        # True while a bill-list item has been pulled out into the entry
        # row for editing but hasn't been re-added with Enter yet.
        self._editing_pending = False

        self._build_top_bar()
        self._build_main_area()
        self._refresh_bill_no_preview()
        self._bind_shortcuts()

        # Whatever bill is currently open gets auto-saved before the app
        # actually closes - whether that's the person clicking Exit, the
        # window's own [X] close button, or the app hitting an unexpected
        # error and going down. Nothing typed in gets lost silently.
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.report_callback_exception = self._on_unexpected_error

        # Show the billing screen right away, dimmed/locked behind a
        # centered password prompt - nothing underneath can be clicked
        # until the correct password is entered.
        self.after(80, self._show_startup_lock)

    # ---------------- STARTUP LOCK OVERLAY ----------------
    def _show_startup_lock(self):
        """Covers the whole billing window with a dimmed overlay and a
        centered password box the moment the app opens. The billing
        screen is fully built and visible underneath (blurred/dimmed),
        but nothing is clickable until the shopkeeper enters the correct
        password (Settings > pwd_app, default '12345')."""
        self.update_idletasks()

        self._lock_overlay = tk.Frame(self, bg="#11182a")
        self._lock_overlay.place(x=0, y=0, relwidth=1, relheight=1)

        # Dim/"blur" effect: a stippled semi-transparent rectangle laid
        # over the entire window so the billing screen underneath reads
        # as hazy/greyed-out rather than a plain solid block.
        dim_canvas = tk.Canvas(self._lock_overlay, bg="#11182a", highlightthickness=0, bd=0)
        dim_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        w = max(self.winfo_width(), 1280)
        h = max(self.winfo_height(), 800)
        dim_canvas.create_rectangle(0, 0, w, h, fill="#0b1120", stipple="gray50", outline="")

        # Centered password card
        card = tk.Frame(self._lock_overlay, bg="#ffffff", padx=45, pady=38,
                         highlightbackground="#334155", highlightthickness=1)
        card.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(card, text="🔒", font=("Segoe UI", 34), bg="#ffffff").pack(pady=(0, 8))
        tk.Label(card, text="Billing Software Locked", font=("Segoe UI", 15, "bold"), bg="#ffffff").pack()
        tk.Label(card, text="Enter password to continue", font=("Segoe UI", 10), bg="#ffffff", fg="#6b7280").pack(pady=(2, 16))

        self._lock_entry = ttk.Entry(card, show="*", font=("Segoe UI", 13), width=24, justify="center")
        self._lock_entry.pack(ipady=4)
        self._lock_entry.focus_set()

        self._lock_error = tk.Label(card, text="", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#dc2626")
        self._lock_error.pack(pady=(6, 0))

        btn_unlock = ttk.Button(card, text="Unlock", style="Success.TButton", command=self._check_startup_password)
        btn_unlock.pack(pady=(14, 0), fill="x")

        self._lock_entry.bind("<Return>", lambda e: self._check_startup_password())

        # Bring window to front so the lock screen isn't missed on launch.
        self.lift()
        self.attributes("-topmost", True)
        self.after(200, lambda: self.attributes("-topmost", False))

    def _check_startup_password(self):
        entered = self._lock_entry.get()
        if db.check_password(entered, "pwd_app", "12345"):
            self._lock_overlay.destroy()
        else:
            self._lock_error.configure(text="Incorrect password. Try again.")
            self._lock_entry.delete(0, "end")
            self._lock_entry.focus_set()

    # ---- Keyboard shortcuts (work anywhere on the main billing screen;
    # deliberately bound with self.bind(), not bind_all(), so they don't
    # also fire while a Products/Customers/Invoices popup window is open
    # and focused). ----
    def _bind_shortcuts(self):
        self.bind("<F2>", lambda e: self.save_bill())
        self.bind("<F3>", self.print_bill)
        self.bind("<F4>", self.save_bill_pdf)
        self.bind("<F5>", self.new_bill)
        self.bind("<F9>", lambda e: self._on_close())
        # Many laptops map F2/F3/etc. to hardware brightness/volume keys at
        # the firmware level instead of sending them to the app (F2 = dim
        # screen being the classic one), and there's no reliable way for
        # any app to override that. So every shortcut also has a Ctrl+
        # alternate that always reaches the app regardless of the laptop's
        # F-key behaviour.
        self.bind("<Control-s>", lambda e: self.save_bill())
        self.bind("<Control-S>", lambda e: self.save_bill())
        self.bind("<Control-p>", self.print_bill)
        self.bind("<Control-P>", self.print_bill)
        self.bind("<Control-d>", self.save_bill_pdf)
        self.bind("<Control-D>", self.save_bill_pdf)
        self.bind("<Control-n>", self.new_bill)
        self.bind("<Control-N>", self.new_bill)
        self.bind("<Control-q>", lambda e: self._on_close())
        self.bind("<Control-Q>", lambda e: self._on_close())
        # Remove the selected line from the Current Bill list. Simple and
        # memorable (Ctrl+X = cut/remove) instead of an F-key.
        self.bind("<Control-x>", self._delete_selected_bill_item)
        self.bind("<Control-X>", self._delete_selected_bill_item)

    def _start_maximized(self):
        """Opens the app filling the screen, so nothing (like the Save/
        Print buttons) ever ends up hidden below a too-small window."""
        try:
            self.state("zoomed")  # Windows/most Linux window managers
        except Exception:
            try:
                self.attributes("-zoomed", True)  # some Linux/X11 setups
            except Exception:
                pass  # keep the geometry() size set above as a fallback

    # ---------------- TOP BAR ----------------
    def _build_top_bar(self):
        bar = tk.Frame(self, bg=HEADER_BG)
        bar.pack(fill="x")

        btnbar = tk.Frame(bar, bg=HEADER_BG, pady=6)
        btnbar.pack(fill="x", padx=8)
        ttk.Button(btnbar, text=f"{ICON['product']} Products", style="Purple.TButton",
                   command=self.open_products).pack(side="left", padx=4)
        ttk.Button(btnbar, text=f"{ICON['product']} Stock Entry", style="Primary.TButton",
                   command=self.open_stock_entry).pack(side="left", padx=4)
        ttk.Button(btnbar, text=f"{ICON['customer']} Customers", style="Teal.TButton",
                   command=self.open_customers).pack(side="left", padx=4)
        ttk.Button(btnbar, text=f"{ICON['invoice']} Invoices", style="Indigo.TButton",
                   command=self.open_invoices).pack(side="left", padx=4)
        ttk.Button(btnbar, text=f"{ICON['new']} New Bill (F5 / Ctrl+N)", style="Success.TButton",
                   command=self.new_bill).pack(side="left", padx=4)
        # Statistics button in navigation
        ttk.Button(btnbar, text="📊 Stats", style="Indigo.TButton",
                   command=self.open_stats).pack(side="left", padx=4)
        # Dues Ledger button in navigation
        ttk.Button(btnbar, text=f"{ICON['cash']} Dues Ledger", style="Warn.TButton",
                   command=self.open_dues_ledger).pack(side="left", padx=4)
        # Single Exit button, now up here with the other top-bar actions
        # instead of down among the Save/Print/PDF buttons.
        ttk.Button(btnbar, text=f"{ICON['exit']} Exit (F9 / Ctrl+Q)", style="Danger.TButton",
                   command=self._on_close).pack(side="left", padx=4)

        # Settings button on the top-right
        ttk.Button(btnbar, text="⚙️ Settings", style="Secondary.TButton",
                   command=self.open_settings).pack(side="right", padx=4)

        tk.Label(bar, text="🧾 Billing Software", bg=HEADER_BG, fg=HEADER_FG,
                 font=("Segoe UI", 14, "bold")).pack(side="right", padx=16, pady=6)

        self.lbl_edit_flag = tk.Label(bar, text="", bg=HEADER_BG, fg="#fbbf24", font=("Segoe UI", 11, "bold"))
        self.lbl_edit_flag.pack(side="right", padx=10)

    # ---------------- MAIN SPLIT AREA ----------------
    def _build_main_area(self):
        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=10, pady=10)
        # Right panel (Current Bill) gets a bit more width than the left
        # one, so the bill table - including its Total column - and the
        # Grand Total figure always have full room and are never clipped.
        container.columnconfigure(0, weight=4)
        container.columnconfigure(1, weight=5)
        container.rowconfigure(0, weight=1)

        self._build_left_panel(container)
        self._build_right_panel(container)

    # ---- helper: Enter key moves focus to the next box and selects its text ----
    def _goto(self, widget_or_getter):
        def handler(event=None):
            widget = widget_or_getter() if callable(widget_or_getter) else widget_or_getter
            widget.focus_set()
            try:
                widget.selection_range(0, "end")
            except Exception:
                pass
            return "break"
        return handler

    # ---- LEFT PANEL: customer + product entry ----
    def _build_left_panel(self, parent):
        left = ttk.LabelFrame(parent, text=" Customer & Product Entry ", padding=14)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.columnconfigure(4, weight=1)

        # Customer search
        ttk.Label(left, text="Customer Name:", font=FONT_BOLD).grid(row=0, column=0, sticky="w", pady=6)
        self.e_customer = ttk.Entry(left, width=30, font=FONT_ENTRY)
        self.e_customer.grid(row=0, column=1, columnspan=4, sticky="w", pady=6)
        AutocompletePopup(self.e_customer, self._search_customers, self._pick_customer,
                           on_enter_no_match=self._goto_pid_from_customer)
        self.e_customer.bind("<KeyRelease>", lambda e: self._mark_dirty(), add="+")

        ttk.Label(left, text="Contact:", font=FONT_BOLD).grid(row=1, column=0, sticky="w", pady=6)
        self.e_contact = ttk.Entry(left, width=22, state="readonly", font=FONT_ENTRY)
        self.e_contact.grid(row=1, column=1, sticky="w", pady=6)

        ttk.Label(left, text="Address:", font=FONT_BOLD).grid(row=2, column=0, sticky="w", pady=6)
        self.e_address = ttk.Entry(left, width=42, state="readonly", font=FONT_ENTRY)
        self.e_address.grid(row=2, column=1, columnspan=4, sticky="w", pady=6)

        ttk.Separator(left, orient="horizontal").grid(row=3, column=0, columnspan=5, sticky="ew", pady=14)

        # ---- ONE horizontal line: Product ID -> Name -> Qty -> Price -> Total ----
        # Headers get the same left padding as the boxes below them so
        # each label sits directly above its own box instead of drifting.
        ttk.Label(left, text="Product ID", font=FONT_BOLD).grid(row=4, column=0, padx=3, sticky="w")
        ttk.Label(left, text="Product Name (editable)", font=FONT_BOLD).grid(row=4, column=1, padx=3, sticky="w")
        ttk.Label(left, text="Qty", font=FONT_BOLD).grid(row=4, column=2, padx=3, sticky="w")
        ttk.Label(left, text="Price", font=FONT_BOLD).grid(row=4, column=3, padx=3, sticky="w")
        ttk.Label(left, text="Total", font=FONT_BOLD).grid(row=4, column=4, padx=3, sticky="w")

        # Bigger font + slightly bigger boxes here so Product ID / Name /
        # Qty / Price / Total don't look small next to the rest of the screen.
        self.e_pid = ttk.Entry(left, width=11, font=FONT_ENTRY_LG)
        self.e_pid.grid(row=5, column=0, padx=3, pady=6, sticky="w")
        AutocompletePopup(self.e_pid, self._search_products, self._pick_product,
                           on_enter_no_match=self._goto(lambda: self.e_pname))

        # Product name is editable directly here: type a new name (or
        # correct an existing one) for THIS bill only - it is never saved
        # back to the product list, only used on the printed bill.
        self.e_pname = ttk.Entry(left, width=20, font=FONT_ENTRY_LG)
        self.e_pname.grid(row=5, column=1, padx=3, pady=6, sticky="w")
        self.e_pname.bind("<Return>", self._goto(lambda: self.e_qty))

        self.e_qty = ttk.Entry(left, width=6, font=FONT_ENTRY_LG)
        self.e_qty.grid(row=5, column=2, padx=3, pady=6, sticky="w")
        # Default Qty to 1 - most items are sold one at a time, so this way
        # you can just press Enter through Qty and only need to type a
        # number when it's actually more than 1.
        self.e_qty.insert(0, "1")
        self.e_qty.bind("<Return>", self._goto(lambda: self.e_price))
        self.e_qty.bind("<KeyRelease>", self._update_live_total, add="+")

        self.e_price = ttk.Entry(left, width=9, font=FONT_ENTRY_LG)  # editable, can be corrected
        self.e_price.grid(row=5, column=3, padx=3, pady=6, sticky="w")
        PricePopup(self.e_price,
                   get_prices_func=self._get_price_choices,
                   on_pick=self._pick_price_choice,
                   on_enter_no_match=self._on_qty_or_price_enter)
        self.e_price.bind("<KeyRelease>", self._update_live_total, add="+")

        # Total for this line: always shown live as soon as Qty & Price are
        # entered, but never directly editable (calculated only).
        self.e_total = ttk.Entry(left, width=10, state="readonly", font=FONT_ENTRY_LG)
        self.e_total.grid(row=5, column=4, padx=3, pady=6, sticky="w")

        # ---- Amount received / balance (change to give, or amount still
        # due if the customer paid less than the bill) - on its own
        # full-width line below the item entry row, since it was getting
        # squeezed/hidden next to it before. ----
        pay_frame = ttk.Frame(left)
        pay_frame.grid(row=8, column=0, columnspan=5, pady=(0, 14), sticky="w")
        ttk.Label(pay_frame, text="Amount Received:", font=FONT_BOLD).pack(side="left")
        self.e_received = ttk.Entry(pay_frame, width=12, font=FONT_ENTRY_LG)
        self.e_received.pack(side="left", padx=(8, 20))
        self.e_received.bind("<KeyRelease>", self._recalc_balance)
        # After typing the amount the customer handed over, pressing Enter
        # asks whether to Print or just Save the bill, instead of making
        # the shopkeeper reach for a mouse/button.
        self.e_received.bind("<Return>", self._on_received_enter)
        self.lbl_balance = ttk.Label(pay_frame, text="Balance: 0.00", style="Big.TLabel")
        self.lbl_balance.pack(side="left")

        # ---- GST Details ----
        # A single small ON/OFF toggle: leave it OFF for a normal bill
        # with no GST, or turn it ON to reveal the fields actually needed
        # to file GST (GSTIN, HSN/SAC Code, GST %). It's just an on/off
        # switch, not a primary action, so it's kept small and left-
        # aligned instead of stretched across the full width.
        self.gst_enabled = tk.BooleanVar(value=False)
        gst_toggle_row = ttk.Frame(left)
        gst_toggle_row.grid(row=9, column=0, columnspan=5, sticky="w", pady=(6, 0))
        self.chk_gst_toggle = ttk.Checkbutton(gst_toggle_row, text=f"{ICON['gst']} Apply GST",
                                               variable=self.gst_enabled, command=self._toggle_gst)
        self.chk_gst_toggle.pack(side="left")

        # Shortfall/excess vs the bill total can be pushed straight into
        # this customer's running due automatically the moment the bill
        # is saved/printed. Kept on this fixed row (next to GST) instead
        # of on the Amount Received/Balance line, since a longer Balance
        # figure there was pushing this checkbox off-screen.
        self.auto_due_adjust = tk.BooleanVar(value=False)
        self.chk_adjust_due = ttk.Checkbutton(gst_toggle_row, text="Add/Reduce Due",
                                               variable=self.auto_due_adjust)
        self.chk_adjust_due.pack(side="left", padx=(20, 0))

        # Tells the cashier up-front, before they even tick the box, that
        # this particular bill's due was already pushed to the Dues
        # Ledger earlier - so re-ticking it and saving again won't add it
        # a second time (see _apply_due_adjustment_if_enabled for the
        # actual double-counting guard).
        self.lbl_due_already = ttk.Label(gst_toggle_row, text="", foreground="#b45309",
                                          font=("Segoe UI", 9, "italic"))
        self.lbl_due_already.pack(side="left", padx=(10, 0))

        # GST Details box always stays at its normal, readable font size
        # (no separate "shrink it" option) so the fields never end up too
        # small to read.
        self.gst_frame = ttk.LabelFrame(left, text=f" {ICON['gst']} GST Details ", padding=10)
        self.gst_frame.grid(row=10, column=0, columnspan=5, sticky="ew", pady=(6, 12))
        self.gst_frame.columnconfigure(1, weight=1)
        self.gst_frame.columnconfigure(3, weight=1)

        self.lbl_gstin = ttk.Label(self.gst_frame, text="Customer GSTIN:", font=FONT_BOLD)
        self.lbl_gstin.grid(row=0, column=0, sticky="w", pady=4)
        self.e_gstin = ttk.Entry(self.gst_frame, width=18, font=FONT_ENTRY)
        self.e_gstin.grid(row=0, column=1, sticky="w", pady=4, padx=4)
        self.e_gstin.bind("<KeyRelease>", lambda e: self._mark_dirty(), add="+")

        self.lbl_hsn = ttk.Label(self.gst_frame, text="HSN/SAC Code:", font=FONT_BOLD)
        self.lbl_hsn.grid(row=0, column=2, sticky="w", pady=4, padx=(16, 0))
        self.e_hsn = ttk.Entry(self.gst_frame, width=14, font=FONT_ENTRY)
        self.e_hsn.grid(row=0, column=3, sticky="w", pady=4, padx=4)
        self.e_hsn.bind("<KeyRelease>", lambda e: self._mark_dirty(), add="+")

        self.lbl_gst_pct = ttk.Label(self.gst_frame, text="GST %:", font=FONT_BOLD)
        self.lbl_gst_pct.grid(row=1, column=0, sticky="w", pady=4)
        self.e_gst_pct = ttk.Entry(self.gst_frame, width=8, font=FONT_ENTRY)
        self.e_gst_pct.insert(0, "0")
        self.e_gst_pct.grid(row=1, column=1, sticky="w", pady=4, padx=4)
        self.e_gst_pct.bind("<KeyRelease>", lambda e: self._recalc_totals())
        self.e_gst_pct.bind("<Return>", self._check_admin_trigger)

        # GST Details start hidden (GST OFF by default) - shown only once
        # the toggle button above is switched ON, so the form stays short
        # and simple for the many bills that don't need GST at all.
        self.gst_frame.grid_remove()

        # Paid / Not paid
        self.paid_var = tk.StringVar(value="Not Paid")
        paid_frame = ttk.Frame(left)
        paid_frame.grid(row=11, column=0, columnspan=5, sticky="w", pady=10)
        ttk.Label(paid_frame, text="Status: ", font=FONT_BOLD).pack(side="left")
        ttk.Radiobutton(paid_frame, text=f"{ICON['paid']} Paid", variable=self.paid_var, value="Paid",
                         command=self._mark_dirty).pack(side="left", padx=4)
        ttk.Radiobutton(paid_frame, text=f"{ICON['notpaid']} Not Paid", variable=self.paid_var, value="Not Paid",
                         command=self._mark_dirty).pack(side="left", padx=4)

        ttk.Separator(left, orient="horizontal").grid(row=12, column=0, columnspan=5, sticky="ew", pady=14)

        self.e_pid.focus_set()

    def _goto_pid_from_customer(self, event=None):
        self.e_pid.focus_set()
        return "break"

    # ---- RIGHT PANEL: bill list ----
    def _build_right_panel(self, parent):
        right = ttk.LabelFrame(parent, text=" Current Bill ", padding=14)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        right.columnconfigure(0, weight=1)

        top_info = ttk.Frame(right)
        top_info.pack(fill="x", pady=(0, 6))
        top_info.columnconfigure(0, weight=1)
        top_info.columnconfigure(1, weight=1)
        self.lbl_billno = ttk.Label(top_info, text="Bill No: -", style="Big.TLabel")
        self.lbl_billno.grid(row=0, column=0, sticky="w")
        # Grand Total: always shown big, and is a read-only label (not an
        # entry box), so it can never accidentally be typed into/edited.
        # Kept on a grid column (with its own right padding) instead of
        # pack(side="right") so it always stays fully inside the panel and
        # is never pushed off the visible edge.
        self.lbl_grandtotal = ttk.Label(top_info, text="Grand Total: 0.00", style="Huge.TLabel", anchor="e")
        self.lbl_grandtotal.grid(row=0, column=1, sticky="e", padx=(0, 6))

        # Buttons + hint are packed to the BOTTOM first, so they always
        # keep their space reserved and stay visible - the bill list
        # below simply shrinks to fit whatever room is left, instead of
        # ever being able to push these off the bottom of the screen.
        # Labels keep "Bill" out and show shortcuts inline as (C+key)
        # (C = Ctrl) so all three - including Save as PDF - always have
        # enough room to fit on screen and are never clipped, even on
        # smaller/lower-resolution screens.
        btn_frame = ttk.Frame(right)
        btn_frame.pack(side="bottom", fill="x", pady=6)
        btn_frame.columnconfigure((0, 1, 2), weight=1)
        ttk.Button(btn_frame, text=f"{ICON['save']} Save (C+S)", style="Success.TButton",
                   command=self.save_bill).grid(row=0, column=0, sticky="ew", padx=3)
        ttk.Button(btn_frame, text=f"{ICON['print']} Print (C+P)", style="Primary.TButton",
                   command=self.print_bill).grid(row=0, column=1, sticky="ew", padx=3)
        ttk.Button(btn_frame, text=f"{ICON['pdf']} Save as PDF (C+D)", style="Warn.TButton",
                   command=self.save_bill_pdf).grid(row=0, column=2, sticky="ew", padx=3)

        ttk.Label(
            right, text=f"{ICON['editrow']} Tip: select a row above, Enter (or double-click) to edit it, Ctrl+X to remove it.",
            font=("Segoe UI", 9, "italic"), foreground="#64748b"
        ).pack(side="bottom", fill="x", pady=(0, 8))

        tree_frame = ttk.Frame(right)
        tree_frame.pack(fill="both", expand=True, pady=8)

        grid_frame = bordered_table_frame(tree_frame)

        cols = ("sno", "name", "qty", "price", "total")
        self.bill_tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=15)
        headings = {"sno": "S.No", "name": "Product Name", "qty": "Count", "price": "Price", "total": "Total"}
        widths = {"sno": 50, "name": 220, "qty": 70, "price": 90, "total": 110}
        for c in cols:
            self.bill_tree.heading(c, text=headings[c])
            self.bill_tree.column(c, width=widths[c])
        self.bill_tree.pack(fill="both", expand=True, side="left")
        # Scrollbar - needed once the bill has more items than fit on screen.
        bill_scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.bill_tree.yview)
        bill_scroll.pack(side="right", fill="y")
        self.bill_tree.configure(yscrollcommand=bill_scroll.set)
        stripe_treeview(self.bill_tree)
        self.bill_tree.bind("<Return>", self._edit_selected_bill_item)
        self.bill_tree.bind("<Double-1>", self._edit_selected_bill_item)
        self.bill_tree.bind("<Delete>", self._delete_selected_bill_item)

    # ---------------- SEARCH / AUTOCOMPLETE CALLBACKS ----------------
    def _search_customers(self, text):
        rows = db.search_customers(text)
        return [(r[1], f"{r[1]} - {r[2]} ({r[3]})", r) for r in rows]

    def _pick_customer(self, row):
        name, display, full = row
        cid, cust_name, contact, address = full
        self.current_customer_id = cid
        self.current_customer_name = cust_name
        self.e_customer.delete(0, "end")
        self.e_customer.insert(0, cust_name)
        for widget, value in ((self.e_contact, contact), (self.e_address, address)):
            widget.configure(state="normal")
            widget.delete(0, "end")
            widget.insert(0, value or "")
            widget.configure(state="readonly")
        self._mark_dirty()
        self.e_pid.focus_set()

    def _search_products(self, text):
        rows = db.search_products_by_id(text)
        return [(r[0], f"{r[0]} - {r[1]}", r) for r in rows]

    def _pick_product(self, row):
        _id, _display, full = row
        pid, name, price, gst_percent = full
        self.e_pid.delete(0, "end")
        self.e_pid.insert(0, pid)
        self.e_pname.delete(0, "end")
        self.e_pname.insert(0, name)
        self.e_price.delete(0, "end")
        self.e_price.insert(0, f"{price:.2f}")
        self.e_qty.focus_set()
        self.e_qty.selection_range(0, "end")

    # ---------------- BILL ITEM ENTRY ----------------
    def _on_qty_or_price_enter(self, event):
        self._add_item_to_bill()

    def _get_price_choices(self):
        cust_name = self.e_customer.get().strip()
        if not cust_name:
            return []
        if not self.current_customer_id or getattr(self, "current_customer_name", None) != cust_name:
            return []
        pid = self.e_pid.get().strip()
        if not pid:
            return []
        try:
            rows = db.get_recent_customer_product_prices(self.current_customer_id, pid, 5)
        except Exception:
            return []
        # If the same sale price has been used every single time (or there's
        # only one past bill to compare), there's nothing useful to pick
        # from - skip the popup entirely. Only show it when the price has
        # actually changed across the last 5 bills, so it's there to help
        # pick the right one instead of just repeating what's already typed.
        distinct_prices = {round(r[0], 2) for r in rows}
        if len(distinct_prices) <= 1:
            return []
        return rows

    def _pick_price_choice(self, price):
        self.e_price.delete(0, "end")
        self.e_price.insert(0, f"{price:.2f}")
        self._update_live_total()

    def _update_live_total(self, event=None):
        """Keeps the (read-only) Total box live-updated as soon as Qty and
        Price are typed, even before the item is added to the bill."""
        qty_text = self.e_qty.get().strip()
        price_text = self.e_price.get().strip()
        self.e_total.configure(state="normal")
        self.e_total.delete(0, "end")
        try:
            qty = float(qty_text)
            price = float(price_text)
            self.e_total.insert(0, f"{qty * price:.2f}")
        except ValueError:
            pass
        self.e_total.configure(state="readonly")

    def _add_item_to_bill(self):
        pid = self.e_pid.get().strip()
        name = self.e_pname.get().strip()
        qty_text = self.e_qty.get().strip()
        price_text = self.e_price.get().strip()

        # Nothing was really typed here (shopkeeper just pressed Enter
        # through an empty row, e.g. by accident) - don't show an error
        # popup for that, just quietly send the cursor back to Product ID
        # so they can start the next item.
        if not pid and not name and not price_text:
            self._clear_product_row()
            self.e_pid.focus_set()
            return

        if not pid or not name:
            messagebox.showerror("Missing product", "Enter/pick a Product ID and Product Name first.")
            return
        try:
            qty = float(qty_text)
            price = float(price_text)
        except ValueError:
            messagebox.showerror("Invalid number", "Qty and Price must be numbers.")
            return
        if qty <= 0:
            messagebox.showerror("Invalid qty", "Qty must be greater than 0.")
            return

        # Warn (but don't block) if this item is about to be sold for less
        # than what it cost to stock - easy to miss during a busy day, and
        # this catches it right when the item is being added to the bill.
        full_lookup_ok = True
        try:
            full = db.get_product_full(pid)
        except Exception:
            full = None
            full_lookup_ok = False
        cost_price = full[4] if full else 0

        # Low Stock Alert - only if turned ON in Settings. Warns when the
        # product's current stock is already at/below the threshold, or
        # when billing this qty would take it to 0 or below. Purely a
        # warning (Yes/No) - saying "yes" still lets the bill go through
        # and stock is still allowed to go negative, same as always.
        if full_lookup_ok and full and db.get_setting("stock_alert_enabled", "0") == "1":
            current_stock = full[2]
            try:
                threshold = float(db.get_setting("stock_alert_threshold", "10"))
            except ValueError:
                threshold = 10
            already_in_bill = next((it["qty"] for it in self.bill_items if it["product_id"] == pid), 0)
            remaining_after = current_stock - already_in_bill - qty
            if current_stock <= threshold or remaining_after <= 0:
                proceed = messagebox.askyesno(
                    "Low Stock Alert",
                    f"{name} has only {current_stock:g} in stock.\n\n"
                    f"Billing {qty:g} will leave {remaining_after:g} in stock"
                    f"{' (going negative!)' if remaining_after < 0 else ''}.\n\n"
                    f"Add it to the bill anyway?"
                )
                if not proceed:
                    self.e_qty.focus_set()
                    self.e_qty.selection_range(0, "end")
                    return
        if cost_price and price < cost_price:
            loss = (cost_price - price) * qty
            proceed = messagebox.askyesno(
                "Selling Below Cost Price",
                f"{name} costs ₹{cost_price:.2f} but is being billed at ₹{price:.2f}.\n\n"
                f"This line will run at a loss of ₹{loss:.2f}.\n\n"
                f"Add it anyway?"
            )
            if not proceed:
                self.e_price.focus_set()
                self.e_price.selection_range(0, "end")
                return

        # The product's saved details are meant to be fixed - set once
        # from Stock Entry (or when the product is first created here).
        # Editing the Product Name box on this screen only relabels THIS
        # bill's line item; it must never be written back to the products
        # table. If the Product ID is brand new, don't silently create a
        # bare record here - open the full Add Product window instead so
        # stock count and cost price get set properly, same as any other
        # new product.
        if full_lookup_ok and full is None:
            self._open_new_product_dialog(pid, name, price)
            return

        # If this Product ID is already a line in the current bill, don't
        # add a second row for it - add the new qty on top of the existing
        # line instead. If the price typed this time is different from
        # when it was first billed, keep using the FIRST-billed price (only
        # the qty changes) so the line total stays consistent.
        existing_idx = None
        for i, it in enumerate(self.bill_items):
            if it["product_id"] == pid:
                existing_idx = i
                break

        if existing_idx is not None:
            existing = self.bill_items[existing_idx]
            merged_qty = existing["qty"] + qty
            use_price = existing["price"]  # first-billed price wins
            merged_total = merged_qty * use_price
            existing["qty"] = merged_qty
            existing["price"] = use_price
            existing["total"] = merged_total
            existing["product_name"] = name

            self.e_total.configure(state="normal")
            self.e_total.delete(0, "end")
            self.e_total.insert(0, f"{merged_total:.2f}")
            self.e_total.configure(state="readonly")

            children = self.bill_tree.get_children()
            iid = children[existing_idx]
            self.bill_tree.item(
                iid,
                values=(existing["sno"], existing["product_name"], f"{merged_qty:g}",
                        f"{use_price:.2f}", f"{merged_total:.2f}"),
            )
        else:
            total = qty * price
            self.e_total.configure(state="normal")
            self.e_total.delete(0, "end")
            self.e_total.insert(0, f"{total:.2f}")
            self.e_total.configure(state="readonly")

            self.sno_counter += 1
            item = {
                "sno": self.sno_counter,
                "product_id": pid,
                "product_name": name,
                "qty": qty,
                "price": price,
                "total": total,
            }
            self.bill_items.append(item)
            self.bill_tree.insert("", "end", values=(item["sno"], name, qty, f"{price:.2f}", f"{total:.2f}"),
                                  tags=(stripe_tag(len(self.bill_items) - 1),))

        self._recalc_totals()
        self._clear_product_row()
        self._mark_dirty()
        self._editing_pending = False
        self.e_pid.focus_set()

    def _open_new_product_dialog(self, pid, name, price):
        """Product ID typed on the billing row doesn't exist yet. Open the
        full Add Product window, prefilled with the ID/Name/Price already
        typed here, so stock count and cost price can be set properly -
        same as adding a product any other way. If it gets saved there,
        this pending line is added to the bill automatically so nothing
        has to be re-typed."""
        messagebox.showinfo(
            "New Product",
            f"Product ID '{pid}' doesn't exist yet.\n\n"
            "The Add Product window will open so you can set its stock "
            "count, cost price, and other details first.",
        )
        ProductManagerWindow(
            self,
            on_change=self._on_new_product_saved,
            initial_pid=pid,
            initial_name=name,
            initial_price=price,
        )

    def _on_new_product_saved(self):
        # Refresh cached prices etc. the same way Stock Entry does.
        self._refresh_after_stock_entry()
        # If the product now exists, finish adding the pending line to
        # this bill automatically.
        pid = self.e_pid.get().strip()
        if pid and db.get_product(pid):
            self._add_item_to_bill()

    def _clear_product_row(self):
        self.e_pid.delete(0, "end")
        self.e_pname.delete(0, "end")
        self.e_total.configure(state="normal")
        self.e_total.delete(0, "end")
        self.e_total.configure(state="readonly")
        self.e_qty.delete(0, "end")
        self.e_qty.insert(0, "1")  # Qty defaults back to 1 for the next item
        self.e_price.delete(0, "end")

    # ---------------- EDIT AN ITEM ALREADY IN THE BILL ----------------
    def _restripe_bill_tree(self):
        for i, iid in enumerate(self.bill_tree.get_children()):
            self.bill_tree.item(iid, tags=(stripe_tag(i),))

    def _commit_pending_edit_if_any(self):
        """If an item is currently sitting in the Product Entry boxes
        because it was pulled out of the bill list for editing, and it was
        never re-added with Enter, put it back into the bill automatically
        now. Without this, opening a different item to edit before
        finishing the first one would overwrite the entry boxes and the
        first item would simply vanish from the bill."""
        if not self._editing_pending:
            return
        pid = self.e_pid.get().strip()
        name = self.e_pname.get().strip()
        if not pid or not name:
            self._editing_pending = False
            return
        try:
            qty = float(self.e_qty.get().strip())
            price = float(self.e_price.get().strip())
        except ValueError:
            self._editing_pending = False
            return
        if qty <= 0:
            self._editing_pending = False
            return
        self._add_item_to_bill()  # re-adds it and clears _editing_pending

    def _edit_selected_bill_item(self, event=None):
        """Selecting a row in the Current Bill list and pressing Enter (or
        double-clicking it) pulls that item's details back into the Product
        Entry boxes so it can be corrected, then re-added with Enter."""
        sel = self.bill_tree.selection()
        if not sel:
            return
        self._commit_pending_edit_if_any()
        iid = sel[0]
        idx = self.bill_tree.index(iid)
        if idx >= len(self.bill_items):
            return
        item = self.bill_items[idx]

        # remove it from the bill for now - it comes right back in (updated)
        # the moment the entry row is submitted again
        self.bill_tree.delete(iid)
        del self.bill_items[idx]
        self._restripe_bill_tree()

        self.e_pid.delete(0, "end")
        self.e_pid.insert(0, item["product_id"])
        self.e_pname.delete(0, "end")
        self.e_pname.insert(0, item["product_name"])
        self.e_qty.delete(0, "end")
        self.e_qty.insert(0, f"{item['qty']:g}")
        self.e_price.delete(0, "end")
        self.e_price.insert(0, f"{item['price']:.2f}")
        self._update_live_total()
        self._recalc_totals()
        self._mark_dirty()
        self._editing_pending = True

        self.e_qty.focus_set()
        self.e_qty.selection_range(0, "end")
        return "break"

    def _delete_selected_bill_item(self, event=None):
        """Selecting a row in the Current Bill list and pressing Delete
        removes it from the bill entirely - no need to pull it into the
        entry row first."""
        sel = self.bill_tree.selection()
        if not sel:
            return
        iid = sel[0]
        idx = self.bill_tree.index(iid)
        if idx >= len(self.bill_items):
            return
        if not messagebox.askyesno("Remove item", "Remove this item from the current bill?"):
            return "break"
        self.bill_tree.delete(iid)
        del self.bill_items[idx]
        self._restripe_bill_tree()
        self._recalc_totals()
        self._mark_dirty()
        return "break"

    def _toggle_gst(self):
        """Shows/hides GST Details (GSTIN, HSN/SAC Code, GST %) based on the
        Apply GST checkbox. When unticked, GST is left out of the total,
        but whatever was typed in those boxes is not cleared (don't
        disturb any other field)."""
        if self.gst_enabled.get():
            self.gst_frame.grid()
        else:
            self.gst_frame.grid_remove()
        self._recalc_totals()

    def _current_subtotal(self):
        return sum(i["total"] for i in self.bill_items)

    def _current_gst_amount(self):
        if not self.gst_enabled.get():
            return 0.0
        try:
            pct = float(self.e_gst_pct.get().strip() or "0")
        except ValueError:
            pct = 0.0
        return self._current_subtotal() * pct / 100.0

    def _current_gstin(self):
        return self.e_gstin.get().strip() if self.gst_enabled.get() else ""

    def _current_hsn(self):
        return self.e_hsn.get().strip() if self.gst_enabled.get() else ""

    def _recalc_totals(self):
        subtotal = self._current_subtotal()
        gst_amount = self._current_gst_amount()
        grand = subtotal + gst_amount
        if gst_amount:
            self.lbl_grandtotal.configure(text=f"Total:{grand:.2f}(incl.GST")
        else:
            self.lbl_grandtotal.configure(text=f"Grand Total: {grand:.2f}")
        self._recalc_balance()
        self._mark_dirty()

    def _current_amount_received(self):
        try:
            return float(self.e_received.get().strip() or "0")
        except ValueError:
            return 0.0

    def _current_balance(self):
        """balance = amount received - grand total.
        >= 0  -> change to give the customer back.
        < 0   -> customer still owes this much (shown as a minus)."""
        grand = self._current_subtotal() + self._current_gst_amount()
        return self._current_amount_received() - grand

    def _recalc_balance(self, event=None):
        received = self._current_amount_received()
        balance = self._current_balance()
        if not received:
            self.lbl_balance.configure(text="Balance: 0.00", foreground="")
        elif balance < 0:
            self.lbl_balance.configure(text=f"Balance Due: -{abs(balance):.2f}", foreground="#dc2626")
        else:
            self.lbl_balance.configure(text=f"Balance (to give): {balance:.2f}", foreground="#16a34a")
        # Amount Received covering (or exceeding) the bill automatically
        # ticks "Paid"; falling short automatically switches it back to
        # "Not Paid" - the cashier can still flip it by hand afterwards
        # if needed, this is just a sensible default as they type.
        grand_total = self._current_subtotal() + self._current_gst_amount()
        if received > 0 and grand_total > 0:
            self.paid_var.set("Paid" if received >= grand_total else "Not Paid")
        self._mark_dirty()

    def _apply_due_adjustment_if_enabled(self):
        """Called automatically as part of saving/printing a bill - if
        the 'Add/Reduce Due' checkbox is ticked, silently pushes any gap
        between Amount Received and the bill total into this customer's
        due ledger, no separate click needed (same idea as the GST
        checkbox: tick it once, it just applies itself from then on).

        - Customer paid LESS (Balance Due) -> shortfall is ADDED to
          their due (opens a new due entry if they don't already have
          one open).
        - Customer paid MORE (Balance to give) -> the excess REDUCES an
          existing open due, if they have one. If they have no open due
          there's nothing to reduce, so it's silently skipped rather
          than creating one out of thin air.

        Goes through the same add_customer_due / record_due_payment
        functions the Dues screen itself uses, so the due_payments log
        table is updated automatically too.

        IMPORTANT - re-saving the SAME bill again: if this bill was
        already saved once with the checkbox ticked, its balance was
        already pushed into the ledger. Simply re-applying the full
        balance every time the bill is re-opened/re-saved would silently
        double (or triple...) count the same due - a real money-losing
        bug. So instead this remembers exactly how much of THIS bill's
        balance was applied last time (db.due_adjustment_amount) and only
        tops up the DIFFERENCE:
        - Nothing changed since last time -> tells the user it's already
          added and does nothing further.
        - Bill was edited afterwards (items/received amount changed) ->
          only the extra difference is pushed/pulled from the ledger.

        Returns the balance value that should be persisted against a
        brand-new bill's row once its bill_no exists (None if nothing
        needs persisting, e.g. it was a no-op or already an existing
        bill whose row was updated directly)."""
        if not self.auto_due_adjust.get():
            return None
        balance = self._current_balance()
        if balance == 0:
            return None

        customer_name = self.e_customer.get().strip() or "Walk-in Customer"
        contact = self.e_contact.get().strip()
        customer_id = self.current_customer_id

        bill_no = self.editing_bill_no
        prev_applied = db.get_due_adjustment_amount(bill_no) if bill_no else 0.0

        if bill_no and abs(prev_applied - balance) < 0.005:
            messagebox.showinfo(
                "Due Already Added",
                f"This bill's due adjustment (₹{abs(balance):,.2f}) was already added to the "
                f"customer's Dues Ledger earlier. It will NOT be added again.",
                parent=self
            )
            return None

        delta = balance - prev_applied
        if delta == 0:
            return None

        if delta < 0:
            db.add_customer_due(customer_id, customer_name, contact, abs(delta))
        else:
            existing = db.get_open_due_for_customer(customer_id, customer_name)
            if existing:
                due_id, total_due, balance_due = existing
                reduce_by = min(delta, balance_due)
                db.record_due_payment(due_id, reduce_by, remarks="Adjusted from bill overpayment")

        if bill_no:
            db.set_due_adjustment_amount(bill_no, balance)
            return None
        # New bill - bill_no doesn't exist yet, so the caller must persist
        # this once db.create_bill() returns the new bill_no.
        return balance

    def _refresh_bill_no_preview(self):
        bills = db.get_all_bills()
        next_no = (bills[0][0] + 1) if bills else 1
        self.lbl_billno.configure(text=f"Bill No: {next_no} (unsaved)")

    def _mark_dirty(self):
        self.is_saved = False

    # ---------------- AUTO-SAVE ON EXIT / ERROR ----------------
    def _auto_save_current_bill(self):
        """Silently saves whatever bill is currently open, if it has at
        least one item and isn't already saved. Never shows a popup and
        never raises - safe to call from a close handler or a crash
        handler where the app is already on its way down."""
        try:
            self._commit_pending_edit_if_any()
        except Exception:
            pass
        try:
            if self.bill_items and not self.is_saved:
                self._ensure_saved()
        except Exception:
            pass

    def _on_close(self, event=None):
        """Used by the Exit button, F9/Ctrl+Q, and the window's own [X]
        button - the current bill is auto-saved first so nothing typed in
        is lost, then the app actually closes."""
        self._auto_save_current_bill()
        self.destroy()

    def _on_unexpected_error(self, exc, val, tb):
        """Tkinter routes any exception raised inside a button click/key
        event here instead of crashing outright. Auto-save the current
        bill first, then show the error so it's not silently swallowed."""
        import traceback
        traceback.print_exception(exc, val, tb)
        self._auto_save_current_bill()
        try:
            messagebox.showerror(
                "Unexpected error",
                f"Something went wrong:\n{val}\n\n"
                "Your current bill has been auto-saved where possible."
            )
        except Exception:
            pass

    # ---------------- TOP BAR ACTIONS ----------------
    def open_products(self):
        ProductManagerWindow(self)

    def open_stock_entry(self):
        # Refresh the billing screen's product cache (e.g. autocomplete
        # price lookups) after stock/prices are edited here.
        StockEntryWindow(self, on_change=self._refresh_after_stock_entry)

    def _refresh_after_stock_entry(self):
        # If Product ID / Product Name currently typed on the billing row
        # matches a product whose price just changed, refresh its shown
        # price so it isn't stale.
        pid = self.e_pid.get().strip()
        if pid:
            row = db.get_product(pid)
            if row:
                _, name, price, gst = row
                self.e_price.delete(0, "end")
                self.e_price.insert(0, f"{price:g}")

    def open_customers(self):
        CustomerManagerWindow(self)

    def open_invoices(self):
        InvoiceViewerWindow(self)

    def new_bill(self, event=None, confirm=True):
        # Whatever's currently open gets auto-saved first (if it has any
        # items) instead of asking whether to discard it - New Bill and
        # Save Bill both always end up on a fresh, empty bill screen with
        # nothing lost.
        if confirm and not self.is_saved and self.bill_items:
            self._auto_save_current_bill()
            messagebox.showinfo(
                "Previous Bill Auto-Saved",
                "Your previous bill had unsaved items, so it was "
                "auto-saved before opening this one.",
            )
        self.bill_items = []
        self.sno_counter = 0
        self._editing_pending = False
        for row in self.bill_tree.get_children():
            self.bill_tree.delete(row)
        self.editing_bill_no = None
        self.last_saved_bill = None
        self.lbl_edit_flag.configure(text="")
        self._recalc_totals()
        self._refresh_bill_no_preview()
        self.current_customer_id = None
        self.current_customer_name = None
        self.e_customer.delete(0, "end")
        for widget in (self.e_contact, self.e_address):
            widget.configure(state="normal")
            widget.delete(0, "end")
            widget.configure(state="readonly")
        self._clear_product_row()
        self.paid_var.set("Not Paid")
        self.gst_enabled.set(False)
        self.gst_frame.grid_remove()
        self.e_gst_pct.delete(0, "end")
        self.e_gst_pct.insert(0, "0")
        self.e_gstin.delete(0, "end")
        self.e_hsn.delete(0, "end")
        self.e_received.delete(0, "end")
        self.lbl_balance.configure(text="Balance: 0.00", foreground="")
        self.auto_due_adjust.set(False)
        self.lbl_due_already.configure(text="")
        self.is_saved = True

    # ---------------- LOAD AN EXISTING BILL FOR EDITING ----------------
    def load_bill_for_edit(self, bill_no):
        bill, items = db.get_bill(bill_no)
        if not bill:
            messagebox.showerror("Not found", f"Bill {bill_no} not found.")
            return
        (bill_no, date, cust_id, cust_name, contact, address, total, gst_amount, paid, amount_received,
         balance, gstin, hsn_code) = bill

        self.new_bill()  # start clean, then fill in below

        self.editing_bill_no = bill_no
        self.current_customer_id = cust_id
        self.current_customer_name = cust_name
        self.e_customer.delete(0, "end")
        self.e_customer.insert(0, cust_name or "")
        for widget, value in ((self.e_contact, contact), (self.e_address, address)):
            widget.configure(state="normal")
            widget.delete(0, "end")
            widget.insert(0, value or "")
            widget.configure(state="readonly")

        self.bill_items = []
        for i, it in enumerate(items):
            pid, pname, qty, price, tot = it
            self.sno_counter += 1
            item = {"sno": self.sno_counter, "product_id": pid, "product_name": pname,
                    "qty": qty, "price": price, "total": tot}
            self.bill_items.append(item)
            self.bill_tree.insert("", "end", values=(item["sno"], pname, qty, f"{price:.2f}", f"{tot:.2f}"),
                                   tags=(stripe_tag(i),))

        subtotal = self._current_subtotal()
        if gst_amount and subtotal:
            self.gst_enabled.set(True)
            self.gst_frame.grid()
            pct = round(gst_amount / subtotal * 100, 2)
            self.e_gst_pct.delete(0, "end")
            self.e_gst_pct.insert(0, f"{pct:g}")
        self.e_gstin.delete(0, "end")
        self.e_gstin.insert(0, gstin or "")
        self.e_hsn.delete(0, "end")
        self.e_hsn.insert(0, hsn_code or "")

        self.paid_var.set(paid or "Not Paid")
        self.e_received.delete(0, "end")
        if amount_received:
            self.e_received.insert(0, f"{amount_received:g}")
        self._recalc_totals()
        self.lbl_billno.configure(text=f"Bill No: {bill_no} (SAVED)")
        self.lbl_edit_flag.configure(text=f"✏️ Editing Bill No {bill_no}")
        self.last_saved_bill = self._build_bill_snapshot(bill_no, date)
        self.is_saved = True

        prev_applied = db.get_due_adjustment_amount(bill_no)
        if prev_applied:
            self.lbl_due_already.configure(
                text=f"ℹ️ ₹{abs(prev_applied):,.2f} already added to Dues Ledger for this bill"
            )
        else:
            self.lbl_due_already.configure(text="")

    # ---------------- SAVE / PRINT / PDF ----------------
    def _build_bill_snapshot(self, bill_no, bill_date):
        customer_name = self.e_customer.get().strip() or "Walk-in Customer"
        contact = self.e_contact.get().strip()
        grand_total = self._current_subtotal() + self._current_gst_amount()
        paid = self.paid_var.get()
        return (bill_no, bill_date, customer_name, contact, self.bill_items[:], grand_total, paid,
                self._current_gst_amount(), self._current_amount_received(), self._current_balance(),
                self._current_gstin(), self._current_hsn())

    def save_bill(self):
        self._commit_pending_edit_if_any()
        if not self.bill_items:
            messagebox.showerror("Empty bill", "Add at least one product before saving.")
            return False
        customer_name = self.e_customer.get().strip() or "Walk-in Customer"
        contact = self.e_contact.get().strip()
        address = self.e_address.get().strip()
        subtotal = self._current_subtotal()
        gst_amount = self._current_gst_amount()
        grand_total = subtotal + gst_amount
        paid = self.paid_var.get()
        amount_received = self._current_amount_received()
        balance = self._current_balance()
        gstin = self._current_gstin()
        hsn_code = self._current_hsn()
        pending_due_adjustment = self._apply_due_adjustment_if_enabled()

        if self.editing_bill_no:
            db.update_bill(self.editing_bill_no, self.current_customer_id, customer_name, contact,
                            address, grand_total, gst_amount, paid, self.bill_items,
                            amount_received, balance, gstin, hsn_code)
            bill_no = self.editing_bill_no
            bill_date = db.get_bill(bill_no)[0][1]  # real bill_date from DB, unchanged by edit
            self.lbl_edit_flag.configure(text=f"✏️ Editing Bill No {bill_no}")
        else:
            bill_no, bill_date = db.create_bill(
                self.current_customer_id, customer_name, contact, address, grand_total, gst_amount, paid,
                self.bill_items, amount_received, balance, gstin, hsn_code
            )
            self.editing_bill_no = bill_no
            if pending_due_adjustment is not None:
                db.set_due_adjustment_amount(bill_no, pending_due_adjustment)
            self.lbl_edit_flag.configure(text=f"✏️ Editing Bill No {bill_no}")

        self.last_saved_bill = (bill_no, bill_date, customer_name, contact, self.bill_items[:], grand_total,
                                 paid, gst_amount, amount_received, balance, gstin, hsn_code)
        self.lbl_billno.configure(text=f"Bill No: {bill_no} (SAVED)")
        self.is_saved = True
        messagebox.showinfo("Saved", f"Bill No {bill_no} saved successfully.")
        # Saved bill is done - straight on to a fresh bill for the next
        # customer, same as what already happens after Print Bill.
        self.new_bill(confirm=False)
        return True

    def _ensure_saved(self):
        """Auto-saves silently (no prompt) if there are unsaved changes."""
        self._commit_pending_edit_if_any()
        if self.is_saved and self.last_saved_bill:
            return True
        if not self.bill_items:
            messagebox.showerror("Empty bill", "Add at least one product before printing/saving as PDF.")
            return False
        customer_name = self.e_customer.get().strip() or "Walk-in Customer"
        contact = self.e_contact.get().strip()
        address = self.e_address.get().strip()
        subtotal = self._current_subtotal()
        gst_amount = self._current_gst_amount()
        grand_total = subtotal + gst_amount
        paid = self.paid_var.get()
        amount_received = self._current_amount_received()
        balance = self._current_balance()
        gstin = self._current_gstin()
        hsn_code = self._current_hsn()
        pending_due_adjustment = self._apply_due_adjustment_if_enabled()

        if self.editing_bill_no:
            db.update_bill(self.editing_bill_no, self.current_customer_id, customer_name, contact,
                            address, grand_total, gst_amount, paid, self.bill_items,
                            amount_received, balance, gstin, hsn_code)
            bill_no = self.editing_bill_no
            bill_date = db.get_bill(bill_no)[0][1]
        else:
            bill_no, bill_date = db.create_bill(
                self.current_customer_id, customer_name, contact, address, grand_total, gst_amount, paid,
                self.bill_items, amount_received, balance, gstin, hsn_code
            )
            self.editing_bill_no = bill_no
            if pending_due_adjustment is not None:
                db.set_due_adjustment_amount(bill_no, pending_due_adjustment)

        self.last_saved_bill = (bill_no, bill_date, customer_name, contact, self.bill_items[:], grand_total,
                                 paid, gst_amount, amount_received, balance, gstin, hsn_code)
        self.lbl_billno.configure(text=f"Bill No: {bill_no} (SAVED)")
        self.lbl_edit_flag.configure(text=f"✏️ Editing Bill No {bill_no}")
        self.is_saved = True
        return True

    def _on_received_enter(self, event=None):
        """Enter in the Amount Received box - ask whether to Print or Save
        the bill, then do that action straight away."""
        self._commit_pending_edit_if_any()
        if not self.bill_items:
            messagebox.showerror("Empty bill", "Add at least one product before printing/saving.")
            return "break"
        choice = messagebox.askyesnocancel(
            "Print or Save",
            "Print this bill now?\n\nYes = Print\nNo = Save only\nCancel = keep editing"
        )
        if choice is True:
            self.print_bill()
        elif choice is False:
            self.save_bill()
        return "break"

    def print_bill(self, event=None):
        # Printing always saves first automatically (no prompt), as requested.
        if not self._ensure_saved():
            return
        (bill_no, bill_date, customer_name, contact, items, grand_total, paid, gst_amount,
         amount_received, balance, gstin, hsn_code) = self.last_saved_bill
        text = printer.build_receipt_text(bill_no, bill_date, customer_name, contact, items, grand_total, paid,
                                           gst_amount, amount_received, balance, gstin=gstin, hsn_code=hsn_code)
        image = printer.build_receipt_image(bill_no, bill_date, customer_name, contact, items, grand_total, paid,
                                             gst_amount, amount_received, balance, gstin=gstin, hsn_code=hsn_code)
        ok, msg = printer.print_receipt(text, receipt_image=image)
        messagebox.showinfo("Print", msg)
        # After printing, the screen automatically clears and is ready for
        # the next customer's bill - no extra clicks needed.
        self.new_bill(confirm=False)

    def save_bill_pdf(self, event=None):
        if not self._ensure_saved():
            return
        (bill_no, bill_date, customer_name, contact, items, grand_total, paid, gst_amount,
         amount_received, balance, gstin, hsn_code) = self.last_saved_bill
        text = printer.build_receipt_text(bill_no, bill_date, customer_name, contact, items, grand_total, paid,
                                           gst_amount, amount_received, balance, gstin=gstin, hsn_code=hsn_code)
        image = printer.build_receipt_image(bill_no, bill_date, customer_name, contact, items, grand_total, paid,
                                             gst_amount, amount_received, balance, gstin=gstin, hsn_code=hsn_code)
        default_name = f"Bill_{bill_no}.pdf"
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", initialfile=default_name,
            filetypes=[("PDF file", "*.pdf")], title="Save Bill as PDF"
        )
        if not path:
            return
        ok, msg = printer.save_pdf_receipt(text, path, receipt_image=image)
        if ok:
            messagebox.showinfo("Saved", msg)
        else:
            messagebox.showerror("Error", msg)

    # ---------------- SETTINGS & ADMIN AREA ----------------
    def open_settings(self):
        pwd = CustomPasswordDialog(self, title="Settings Access", prompt="Enter settings password:").result
        if pwd is None:
            return
        if not db.check_password(pwd, "pwd_settings", "12345"):
            messagebox.showerror("Error", "Incorrect password!", parent=self)
            return

        # Settings window (Modal)
        win = tk.Toplevel(self)
        win.title("⚙️ Edit Shop Details & Passwords")
        win.geometry("560x600")
        win.resizable(False, False)
        apply_theme(win)
        win.grab_set()

        # Load details & passwords
        details = db.get_shop_details()
        app_pwd = db.get_setting("pwd_app", "12345")
        dues_pwd = db.get_setting("pwd_dues", "12345")
        settings_pwd = db.get_setting("pwd_settings", "12345")
        profit_pwd = db.get_setting("pwd_profit", "12345")

        # ---- Scrollable container ----
        # The form has grown (License section etc.) taller than a fixed
        # window can always show, which was pushing the Save/Cancel
        # buttons off the bottom, out of view. Wrapping everything in a
        # scrollable canvas means the window stays a fixed, predictable
        # size and nothing - including Save - is ever cut off.
        canvas = tk.Canvas(win, borderwidth=0, highlightthickness=0, bg=win.cget("bg"))
        vscroll = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas, padding=20)

        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))
        canvas.configure(yscrollcommand=vscroll.set)

        canvas.pack(side="left", fill="both", expand=True)
        vscroll.pack(side="right", fill="y")

        def _on_mousewheel(event):
            try:
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            except Exception:
                pass

        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        win.bind("<Destroy>", lambda e: canvas.unbind_all("<MouseWheel>"))

        ttk.Label(frame, text="Shop Name:", font=FONT_BOLD).grid(row=0, column=0, sticky="w", pady=6)
        e_name = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_name.grid(row=0, column=1, sticky="w", pady=6, padx=10)
        e_name.insert(0, details["shop_name"])

        ttk.Label(frame, text="Address (Place):", font=FONT_BOLD).grid(row=1, column=0, sticky="w", pady=6)
        e_address = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_address.grid(row=1, column=1, sticky="w", pady=6, padx=10)
        e_address.insert(0, details["shop_address"])

        ttk.Label(frame, text="Contact No:", font=FONT_BOLD).grid(row=2, column=0, sticky="w", pady=6)
        e_phone = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_phone.grid(row=2, column=1, sticky="w", pady=6, padx=10)
        e_phone.insert(0, details["shop_phone"])

        # Change Passwords section
        ttk.Separator(frame, orient="horizontal").grid(row=3, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(frame, text="Change Configuration Passwords", font=FONT_BOLD, foreground=HEADER_BG).grid(row=4, column=0, columnspan=2, sticky="w", pady=4)

        ttk.Label(frame, text="App Activation:", font=FONT_BOLD).grid(row=5, column=0, sticky="w", pady=6)
        e_app_pwd = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_app_pwd.grid(row=5, column=1, sticky="w", pady=6, padx=10)
        e_app_pwd.insert(0, app_pwd)

        ttk.Label(frame, text="Dues/Sales Pwd:", font=FONT_BOLD).grid(row=6, column=0, sticky="w", pady=6)
        e_dues_pwd = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_dues_pwd.grid(row=6, column=1, sticky="w", pady=6, padx=10)
        e_dues_pwd.insert(0, dues_pwd)

        ttk.Label(frame, text="Settings Pwd:", font=FONT_BOLD).grid(row=7, column=0, sticky="w", pady=6)
        e_settings_pwd = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_settings_pwd.grid(row=7, column=1, sticky="w", pady=6, padx=10)
        e_settings_pwd.insert(0, settings_pwd)

        ttk.Label(frame, text="Profit Report Pwd:", font=FONT_BOLD).grid(row=8, column=0, sticky="w", pady=6)
        e_profit_pwd = ttk.Entry(frame, width=28, font=FONT_ENTRY)
        e_profit_pwd.grid(row=8, column=1, sticky="w", pady=6, padx=10)
        e_profit_pwd.insert(0, profit_pwd)

        # ---- GST Auto-Save ----
        # Bills are only kept in this app for ~3 months before being
        # auto-deleted (see database.py). If this is switched ON, a GST
        # Excel (same layout the manual Export to Excel button makes) is
        # written out automatically every day - well before that cleanup
        # ever happens - into a "GST_AutoSaved_Reports" folder next to
        # the app, so nothing needed for GST filing is ever lost.
        ttk.Separator(frame, orient="horizontal").grid(row=9, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(frame, text="GST Filing", font=FONT_BOLD, foreground=HEADER_BG).grid(row=10, column=0, columnspan=2, sticky="w", pady=4)

        gst_autosave_var = tk.BooleanVar(value=db.get_setting("gst_autosave_enabled", "0") == "1")
        ttk.Checkbutton(
            frame, text="Auto-Save GST Excel daily (before old bills are cleared)",
            variable=gst_autosave_var
        ).grid(row=11, column=0, columnspan=2, sticky="w", pady=4)

        last_autosave = db.get_setting("gst_last_autosave", "")
        last_text = f"Last auto-saved: {last_autosave}" if last_autosave else "Last auto-saved: never yet"
        ttk.Label(frame, text=last_text, font=("Segoe UI", 9, "italic"), foreground="#64748b").grid(
            row=12, column=0, columnspan=2, sticky="w")

        # ---- Low Stock Alert ----
        # When ON, adding an item to a bill whose stock is already below
        # the threshold (or whose stock would go to 0 or below after this
        # bill) pops up a warning. It's just a warning though - Yes/No -
        # the shopkeeper can still say "add it anyway" and the bill goes
        # through as usual, stock can still go negative same as before.
        ttk.Separator(frame, orient="horizontal").grid(row=13, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(frame, text="Low Stock Alert", font=FONT_BOLD, foreground=HEADER_BG).grid(
            row=14, column=0, columnspan=2, sticky="w", pady=4)

        stock_alert_var = tk.BooleanVar(value=db.get_setting("stock_alert_enabled", "0") == "1")
        ttk.Checkbutton(
            frame, text="Warn when billing a low-stock / out-of-stock product",
            variable=stock_alert_var
        ).grid(row=15, column=0, columnspan=2, sticky="w", pady=4)

        ttk.Label(frame, text="Low stock threshold (qty):", font=FONT_BOLD).grid(row=16, column=0, sticky="w", pady=6)
        e_stock_threshold = ttk.Entry(frame, width=10, font=FONT_ENTRY)
        e_stock_threshold.grid(row=16, column=1, sticky="w", pady=6, padx=10)
        e_stock_threshold.insert(0, db.get_setting("stock_alert_threshold", "10"))

        # ---- License / Subscription ----
        ttk.Separator(frame, orient="horizontal").grid(row=17, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(frame, text="License / Subscription", font=FONT_BOLD, foreground=HEADER_BG).grid(
            row=18, column=0, columnspan=2, sticky="w", pady=4)

        lic_status = license_lock.get_saved_license_status()
        lbl_license = ttk.Label(frame, font=("Segoe UI", 9))
        lbl_license.grid(row=19, column=0, columnspan=2, sticky="w", pady=2)

        def _describe_license():
            if not lic_status or lic_status["kind"] == "permanent":
                return "Type: Permanent (never expires)", "#16a34a"
            expiry_text = lic_status["expiry"].strftime("%d-%m-%Y")
            if lic_status["expired"]:
                return f"Type: Subscription - EXPIRED on {expiry_text}", "#dc2626"
            days = lic_status["days_left"]
            return f"Type: Subscription - expires on {expiry_text} ({days} day(s) left)", (
                "#d97706" if days <= license_lock.WARN_DAYS_BEFORE_EXPIRY else "#334155"
            )

        text, color = _describe_license()
        lbl_license.configure(text=text, foreground=color)

        def renew_early():
            """Lets the shopkeeper type in a NEW subscription key ahead of
            time (before the current one actually runs out), so renewal
            doesn't have to wait for a lockout."""
            new_key = simpledialog.askstring(
                "Renew License",
                f"Enter the new License Key you received "
                f"(contact {license_lock.SUPPORT_CONTACT} if you don't have one yet):",
                parent=win,
            )
            if not new_key:
                return
            if license_lock.try_activate(new_key):
                messagebox.showinfo("Renewed", "License updated successfully.", parent=win)
                nonlocal lic_status
                lic_status = license_lock.get_saved_license_status()
                new_text, new_color = _describe_license()
                lbl_license.configure(text=new_text, foreground=new_color)
            else:
                messagebox.showerror(
                    "Invalid Key",
                    "This key doesn't match this PC, or is not a valid key.",
                    parent=win,
                )

        ttk.Button(frame, text="🔑 Renew / Enter New License Key", style="Primary.TButton",
                   command=renew_early).grid(row=20, column=0, columnspan=2, sticky="w", pady=(6, 0))

        # ---- Data Backup / Restore ----
        # Same 4 actions as the Admin Panel's Backup/Restore buttons
        # (Backup/Restore Products, Backup/Restore full Database), added
        # here too so a shopkeeper can back up or restore data straight
        # from Settings without needing the secret admin-panel trick.
        ttk.Separator(frame, orient="horizontal").grid(row=21, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(frame, text="Data Backup / Restore", font=FONT_BOLD, foreground=HEADER_BG).grid(
            row=22, column=0, columnspan=2, sticky="w", pady=4)

        backup_btns = ttk.Frame(frame)
        backup_btns.grid(row=23, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        backup_btns.columnconfigure(0, weight=1)
        backup_btns.columnconfigure(1, weight=1)

        def backup_products():
            """Saves ONLY the products table (ID, name, stock, price, GST
            %, cost price) to a JSON file - no customers, bills, or dues
            data included at all."""
            path = filedialog.asksaveasfilename(
                parent=win, title="Backup Products", defaultextension=".json",
                filetypes=[("Products Backup", "*.json")], initialfile="products_backup.json")
            if not path:
                return
            try:
                count = db.export_products_to_file(path)
                messagebox.showinfo("Success", f"{count} product(s) backed up successfully to:\n{path}", parent=win)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to backup products:\n{str(e)}", parent=win)

        def restore_products():
            """Restores products from a Backup Products JSON file.
            Replaces the current product list entirely - customers,
            bills, and dues are completely untouched."""
            path = filedialog.askopenfilename(
                parent=win, title="Restore Products", filetypes=[("Products Backup", "*.json")])
            if not path:
                return
            if not messagebox.askyesno(
                "Warning",
                "Restoring products will REPLACE the current product list with "
                "what's in this file. Customers, bills, and dues are not "
                "affected. Are you sure you want to proceed?",
                parent=win,
            ):
                return
            try:
                count = db.import_products_from_file(path)
                messagebox.showinfo("Success", f"{count} product(s) restored successfully!", parent=win)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to restore products:\n{str(e)}", parent=win)

        def backup_db():
            path = filedialog.asksaveasfilename(
                parent=win, title="Backup Database", defaultextension=".db",
                filetypes=[("Database Files", "*.db")], initialfile="shop_data_backup.db")
            if not path:
                return
            try:
                shutil.copy2(db.DB_FILE, path)
                messagebox.showinfo("Success", f"Database backed up successfully to:\n{path}", parent=win)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to backup database:\n{str(e)}", parent=win)

        def restore_db():
            path = filedialog.askopenfilename(
                parent=win, title="Restore Database", filetypes=[("Database Files", "*.db")])
            if not path:
                return
            if not messagebox.askyesno(
                "Warning", "Restoring a database will OVERWRITE all current data. Are you sure you want to proceed?",
                parent=win,
            ):
                return
            try:
                shutil.copy2(path, db.DB_FILE)
                messagebox.showinfo(
                    "Success", "Database restored successfully! Please restart the application to reload the restored data.",
                    parent=win)
                win.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to restore database:\n{str(e)}", parent=win)

        ttk.Button(backup_btns, text=f"{ICON['product']} Backup Products", style="Success.TButton",
                   command=backup_products).grid(row=0, column=0, sticky="ew", pady=6, padx=5)
        ttk.Button(backup_btns, text=f"{ICON['back']} Restore Products", style="Primary.TButton",
                   command=restore_products).grid(row=0, column=1, sticky="ew", pady=6, padx=5)
        ttk.Button(backup_btns, text=f"{ICON['save']} Backup Database", style="Success.TButton",
                   command=backup_db).grid(row=1, column=0, sticky="ew", pady=6, padx=5)
        ttk.Button(backup_btns, text=f"{ICON['back']} Restore Database", style="Primary.TButton",
                   command=restore_db).grid(row=1, column=1, sticky="ew", pady=6, padx=5)

        def save():
            name = e_name.get().strip()
            addr = e_address.get().strip()
            phone = e_phone.get().strip()
            new_app = e_app_pwd.get().strip()
            new_dues = e_dues_pwd.get().strip()
            new_set = e_settings_pwd.get().strip()
            new_profit = e_profit_pwd.get().strip()

            if not name:
                messagebox.showerror("Error", "Shop Name cannot be empty!", parent=win)
                return
            if not new_app or not new_dues or not new_set or not new_profit:
                messagebox.showerror("Error", "Passwords cannot be empty!", parent=win)
                return

            threshold_text = e_stock_threshold.get().strip()
            try:
                threshold_val = float(threshold_text)
                if threshold_val < 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Error", "Low stock threshold must be a valid number (0 or more)!", parent=win)
                return

            db.save_shop_details(name, addr, phone)
            db.save_setting("pwd_app", new_app)
            db.save_setting("pwd_dues", new_dues)
            db.save_setting("pwd_settings", new_set)
            db.save_setting("pwd_profit", new_profit)
            db.save_setting("gst_autosave_enabled", "1" if gst_autosave_var.get() else "0")
            db.save_setting("stock_alert_enabled", "1" if stock_alert_var.get() else "0")
            db.save_setting("stock_alert_threshold", str(threshold_val))

            # Update printer variables
            printer.SHOP_NAME = name
            printer.SHOP_ADDRESS = addr
            printer.SHOP_PHONE = phone

            messagebox.showinfo("Success", "Details and passwords updated successfully!", parent=win)
            win.destroy()

        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=24, column=0, columnspan=2, pady=15)
        ttk.Button(btn_frame, text=f"{ICON['save']} Save", style="Success.TButton", command=save).pack(side="left", padx=10)
        ttk.Button(btn_frame, text=f"{ICON['exit']} Cancel", style="Secondary.TButton", command=win.destroy).pack(side="left", padx=10)

    def _check_admin_trigger(self, event=None):
        val = self.e_gst_pct.get().strip()
        if val == "DHINESH":
            # clear the field to not affect totals
            self.e_gst_pct.delete(0, "end")
            self.e_gst_pct.insert(0, "0")
            self._recalc_totals()
            self._open_admin_panel()
            return "break"

    def _open_admin_panel(self):
        # Refresh current screen after administrative changes
        AdminPanelWindow(self, on_change=self.new_bill)

    def open_stats(self):
        StatsWindow(self)

    def open_dues_ledger(self):
        pwd = CustomPasswordDialog(self, title="Dues Access", prompt="Enter password to open Dues Ledger:").result
        if pwd is None:
            return
        if db.check_password(pwd, "pwd_dues", "12345"):
            DuesLedgerWindow(self)
        else:
            messagebox.showerror("Error", "Incorrect password!", parent=self)


if __name__ == "__main__":
    db.init_db()
    app = BillingApp()
    app.mainloop()
