"""
invoice_viewer.py
------------------
Shows all bills (auto-cleared after 3 months by database.py - products
and customers are never auto-deleted, only old bills).
Columns: Bill No, Date, Customer, Contact, Amount, Paid/Not Paid,
Received, Balance

Select a bill to preview it below, then press "Open in Billing" (or
just double-click the row) to load that exact bill back into the main
Billing screen, where you can add more products, change anything, and
Save again - it updates the same bill instead of creating a new one.
"""

import tkinter as tk
from tkinter import ttk
import database as db
from ui_theme import apply_theme, ICON, FONT_BOLD, stripe_treeview, stripe_tag, bordered_table_frame, maximize_window


class InvoiceViewerWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.master_app = master
        self.title(f"{ICON['invoice']} All Invoices (last 3 months)")
        self.geometry("940x640")
        self.minsize(820, 520)
        apply_theme(self)
        # Opens at a comfortable medium size by default; the user can
        # still maximize it themselves (OS maximize button) if needed.
        # maximize_window(self)

        top = ttk.Frame(self, padding=(12, 12, 12, 0))
        top.pack(side="top", fill="x")
        ttk.Label(top, text="Click a bill, then Open in Billing to edit/add products and save again.",
                  font=FONT_BOLD).pack(side="left")

        # --- Search bar ---
        # Filters the bill list live as you type, matching against Bill
        # No, Customer name, Contact number, or Date (any of these -
        # whichever field the text is found in).
        search_frame = ttk.Frame(self, padding=(12, 8, 12, 0))
        search_frame.pack(side="top", fill="x")
        ttk.Label(search_frame, text=f"{ICON['search']} Search:", font=FONT_BOLD).pack(side="left", padx=(0, 6))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self.refresh())
        e_search = ttk.Entry(search_frame, textvariable=self.search_var, width=40)
        e_search.pack(side="left", fill="x", expand=True)
        ttk.Button(search_frame, text=f"{ICON['clear']} Clear", style="Secondary.TButton",
                   command=lambda: self.search_var.set("")).pack(side="left", padx=(6, 0))

        # Buttons + detail box are packed to the BOTTOM first, so they
        # always keep their space reserved and stay fully visible - the
        # bill table below simply shrinks to fit whatever room is left,
        # instead of ever being able to push these off the bottom of the
        # window (same fix already used on the main Billing screen).
        btn_frame = ttk.Frame(self, padding=(12, 0, 12, 12))
        btn_frame.pack(side="bottom", fill="x")
        ttk.Button(btn_frame, text=f"{ICON['edit']} Open in Billing (Edit)", style="Primary.TButton",
                   command=self._open_selected).pack(side="left", padx=4)
        ttk.Button(btn_frame, text=f"{ICON['clear']} Close", style="Secondary.TButton",
                   command=self.destroy).pack(side="left", padx=4)

        self.detail_box = tk.Text(self, height=9, font=("Consolas", 10))
        self.detail_box.pack(side="bottom", fill="x", padx=12, pady=(0, 12))

        table_frame = ttk.Frame(self, padding=12)
        table_frame.pack(side="top", fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("bill_no", "date", "customer", "contact", "amount", "paid", "received", "balance")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=14)
        headings = {
            "bill_no": "Bill No", "date": "Date", "customer": "Customer",
            "contact": "Contact", "amount": "Amount", "paid": "Status",
            "received": "Received", "balance": "Balance",
        }
        widths = {"bill_no": 60, "date": 120, "customer": 150, "contact": 100, "amount": 90, "paid": 90,
                  "received": 90, "balance": 90}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c])
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.show_detail)
        self.tree.bind("<Double-1>", self._open_selected)
        self.tree.bind("<Return>", self._open_selected)
        stripe_treeview(self.tree)

        self.refresh()

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        query = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        i = 0
        for b in db.get_all_bills():
            bill_no, date, cust, contact, amount, paid, received, balance = b
            if query:
                haystack = f"{bill_no} {date} {cust or ''} {contact or ''} {paid or ''}".lower()
                if query not in haystack:
                    continue
            bal_text = f"{balance:.2f}" if received else "-"
            self.tree.insert("", "end", values=(bill_no, date, cust, contact, f"{amount:.2f}", paid,
                                                  f"{received:.2f}" if received else "-", bal_text),
                              tags=(stripe_tag(i),))
            i += 1

    def _selected_bill_no(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.item(sel[0], "values")[0]

    def show_detail(self, event):
        bill_no = self._selected_bill_no()
        self.detail_box.delete("1.0", "end")
        if not bill_no:
            return
        bill, items = db.get_bill(bill_no)
        if not bill:
            return
        (bill_no, date, cust_id, cust, contact, address, total, gst_amount, paid, amount_received,
         balance, gstin, hsn_code) = bill
        self.detail_box.insert("end", f"Bill No: {bill_no}   Date: {date}   Status: {paid}\n")
        self.detail_box.insert("end", f"Customer: {cust}   Contact: {contact}   Address: {address}\n")
        self.detail_box.insert("end", "-" * 76 + "\n")
        self.detail_box.insert("end", f"{'Product':<30}{'Qty':>6}{'Price':>10}{'Total':>12}\n")
        for it in items:
            pid, pname, qty, price, tot = it
            self.detail_box.insert("end", f"{pname:<30}{qty:>6}{price:>10.2f}{tot:>12.2f}\n")
        self.detail_box.insert("end", "-" * 76 + "\n")
        if gst_amount:
            self.detail_box.insert("end", f"GST: {gst_amount:.2f}\n")
        self.detail_box.insert("end", f"GRAND TOTAL: {total:.2f}\n")
        if amount_received:
            self.detail_box.insert("end", f"Amount Received: {amount_received:.2f}\n")
            if balance >= 0:
                self.detail_box.insert("end", f"Balance (to give): {balance:.2f}\n")
            else:
                self.detail_box.insert("end", f"Balance Due: -{abs(balance):.2f}\n")

    def _open_selected(self, event=None):
        bill_no = self._selected_bill_no()
        if not bill_no:
            return
        if hasattr(self.master_app, "load_bill_for_edit"):
            self.master_app.load_bill_for_edit(bill_no)
        self.destroy()
