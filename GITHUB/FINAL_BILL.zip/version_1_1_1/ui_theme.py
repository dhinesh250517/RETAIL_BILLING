"""
ui_theme.py
------------
One shared place for colors, fonts and button styles so every window
(main billing screen, product/customer manager, invoices) looks
consistent and colorful, with icons on every button.
"""

import tkinter as tk
from tkinter import ttk
import os
import sys


def _icon_path(filename="logo.ico"):
    """Absolute path to an assets/ file, working both when running from
    source and when running as a PyInstaller-built .exe (onefile or
    onedir, where bundled files are extracted to sys._MEIPASS)."""
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, "assets", filename)


# Keep a reference to the PhotoImage used as the iconphoto fallback so it
# isn't garbage-collected (Tk only keeps a weak reference internally,
# and a GC'd PhotoImage silently reverts the window to the feather icon).
_ICON_PHOTO_CACHE = {}


def _apply_window_icon(root):
    """Set logo.ico as the window/taskbar icon, with a PNG fallback.

    root.iconbitmap() is the primary path, but some Tcl/Tk builds can't
    decode certain .ico frame encodings and raise silently-swallowed
    exceptions, which makes Tk fall back to its default feather icon.
    iconphoto() with the PNG is a second, independent code path (Tk's
    native PNG support, no .ico parsing involved) so if iconbitmap ever
    fails again the window still gets the correct icon instead of the
    feather.
    """
    ok = False
    try:
        root.iconbitmap(_icon_path("logo.ico"))
        ok = True
    except Exception:
        pass

    try:
        photo = _ICON_PHOTO_CACHE.get("logo")
        if photo is None:
            photo = tk.PhotoImage(file=_icon_path("logo.png"))
            _ICON_PHOTO_CACHE["logo"] = photo
        root.iconphoto(False, photo)
        ok = True
    except Exception:
        pass

    return ok

# ---- palette ----
BG = "#eef2f7"
PANEL_BG = "#ffffff"
HEADER_BG = "#1f3b57"
HEADER_FG = "#ffffff"
PRIMARY = "#2563eb"     # blue
PRIMARY_DARK = "#1d4ed8"
SUCCESS = "#16a34a"     # green
SUCCESS_DARK = "#15803d"
DANGER = "#dc2626"      # red
DANGER_DARK = "#b91c1c"
WARN = "#d97706"        # orange
WARN_DARK = "#b45309"
SECONDARY = "#64748b"   # gray
SECONDARY_DARK = "#475569"
TEAL = "#0d9488"        # teal (used for "Add item" style actions)
TEAL_DARK = "#0f766e"
PURPLE = "#7c3aed"      # purple (used for Customers)
PURPLE_DARK = "#6d28d9"
INDIGO = "#4f46e5"      # indigo (used for Invoices)
INDIGO_DARK = "#4338ca"
ROW_ALT = "#f4f7fb"
ROW_MAIN = "#ffffff"
TOTAL_FG = "#b91c1c"

# Slightly larger fonts everywhere + bigger entry boxes so the screen
# feels less empty and is easier to read/tap.
FONT_NORMAL = ("Segoe UI", 11)
FONT_BOLD = ("Segoe UI", 11, "bold")
FONT_HEADER = ("Segoe UI", 14, "bold")
FONT_BIG = ("Segoe UI", 18, "bold")
FONT_HUGE = ("Segoe UI", 24, "bold")
FONT_ENTRY = ("Segoe UI", 12)
# Bigger font just for the Product ID / Name / Qty / Price / Total entry
# row, since those boxes looked noticeably smaller than everything else
# around them.
FONT_ENTRY_LG = ("Segoe UI", 14)

# icons (plain unicode - no image files needed, work everywhere)
ICON = {
    "product": "📦", "customer": "👥", "invoice": "🧾", "new": "🆕",
    "save": "💾", "print": "🖨️", "pdf": "📄", "exit": "🚪",
    "add": "➕", "update": "✏️", "delete": "🗑️", "clear": "🧹",
    "search": "🔍", "back": "↩️", "edit": "📝", "gst": "％",
    "customeradd": "👤", "paid": "✅", "notpaid": "⏳", "editrow": "↪️",
    "cash": "💵",
}


def apply_theme(root):
    # Every window (main billing screen, Products, Customers, Stock
    # Entry, Stats, Dues Ledger, Admin Panel, Invoices, password
    # prompts...) calls apply_theme(), so setting the icon here means
    # logo.ico shows up as the tab/title-bar icon everywhere instead of
    # Tk's default feather icon - no need to repeat this in every file.
    _apply_window_icon(root)
    root.configure(bg=BG)
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure("TFrame", background=BG)
    style.configure("Panel.TFrame", background=PANEL_BG)
    style.configure("TLabelframe", background=BG, font=FONT_BOLD)
    style.configure("TLabelframe.Label", background=BG, font=FONT_BOLD, foreground=HEADER_BG)
    style.configure("TLabel", background=BG, font=FONT_NORMAL)
    style.configure("Header.TLabel", background=HEADER_BG, foreground=HEADER_FG, font=FONT_HEADER)
    style.configure("Big.TLabel", background=BG, font=FONT_BIG)
    style.configure("Huge.TLabel", background=BG, font=FONT_HUGE, foreground=TOTAL_FG)

    style.configure("TEntry", padding=6, font=FONT_ENTRY)

    # ---- table (Treeview) look: bordered "grid" cells, boxed headings,
    # comfortable row height/padding so every table in the app (Products,
    # Customers, Invoices, Stats, Dues) looks like a clean, readable grid
    # instead of a bare borderless list ----
    GRID_LINE = "#c7d2e0"
    style.configure(
        "Treeview",
        rowheight=32,
        font=FONT_NORMAL,
        background="white",
        fieldbackground="white",
        bordercolor=GRID_LINE,
        borderwidth=1,
        relief="solid",
    )
    style.configure(
        "Treeview.Heading",
        font=FONT_BOLD,
        background=HEADER_BG,
        foreground=HEADER_FG,
        padding=(8, 8),
        relief="raised",
        borderwidth=1,
    )
    style.map(
        "Treeview.Heading",
        background=[("active", PRIMARY_DARK)],
    )
    style.map("Treeview", background=[("selected", PRIMARY)], foreground=[("selected", "white")])

    def _btn_style(name, base, dark):
        style.configure(
            name, font=FONT_BOLD, padding=10, background=base, foreground="white", borderwidth=0
        )
        style.map(name, background=[("active", dark), ("disabled", "#cbd5e1")])

    _btn_style("Primary.TButton", PRIMARY, PRIMARY_DARK)
    _btn_style("Success.TButton", SUCCESS, SUCCESS_DARK)
    _btn_style("Danger.TButton", DANGER, DANGER_DARK)
    _btn_style("Warn.TButton", WARN, WARN_DARK)
    _btn_style("Secondary.TButton", SECONDARY, SECONDARY_DARK)
    _btn_style("Teal.TButton", TEAL, TEAL_DARK)
    _btn_style("Purple.TButton", PURPLE, PURPLE_DARK)
    _btn_style("Indigo.TButton", INDIGO, INDIGO_DARK)

    return style


def stripe_treeview(tree):
    """Call once after inserting rows to alternate row colors."""
    tree.tag_configure("odd", background=ROW_ALT)
    tree.tag_configure("even", background=ROW_MAIN)


def maximize_window(win):
    """Opens a Toplevel window filling the whole screen, same as the main
    billing window does - so Products, Customers, Invoices, Dues Ledger,
    Stats, etc. always open full-screen instead of a smaller fixed size.
    Falls back quietly to whatever geometry() was already set if the
    window manager doesn't support either maximize call."""
    try:
        win.state("zoomed")  # Windows/most Linux window managers
    except Exception:
        try:
            win.attributes("-zoomed", True)  # some Linux/X11 setups
        except Exception:
            pass


def open_half_screen(win):
    """Opens a Toplevel at a smaller, roughly-square size (about half the
    screen's shorter side) and centers it on screen, instead of auto
    full-screening it. The window stays resizable, so the shop can still
    hit the window's own maximize button (or double-click its title bar)
    any time they want it full-screen - it's just not forced on open."""
    win.update_idletasks()
    screen_w = win.winfo_screenwidth()
    screen_h = win.winfo_screenheight()
    side = int(min(screen_w, screen_h) * 0.65)
    x = (screen_w - side) // 2
    y = (screen_h - side) // 2
    win.geometry(f"{side}x{side}+{x}+{y}")


def open_like_invoice(win):
    """Opens a Toplevel at the same size as the Invoices window
    (940x640, min 820x520) instead of the smaller half-screen square,
    so Products / Stock Entry / Customers open just as big as
    Invoices. Still resizable/maximizable by the user afterwards."""
    win.geometry("940x640")
    win.minsize(820, 520)


def stripe_tag(index):
    return "odd" if index % 2 else "even"


def bordered_table_frame(parent, **pack_kwargs):
    """Create and pack a slim bordered "card" frame to hold a Treeview +
    its scrollbar, giving every table in the app (Products, Customers,
    Invoices, Stats, Dues) a clean boxed/grid look instead of floating
    with no outline. Returns the inner frame - build the Treeview and its
    scrollbar inside it exactly as you would inside table_frame."""
    outer = tk.Frame(parent, bg="#94a3b8", bd=0)
    outer.pack(fill="both", expand=True, **pack_kwargs)
    inner = tk.Frame(outer, bg="white")
    inner.pack(fill="both", expand=True, padx=1, pady=1)
    return inner


class CustomPasswordDialog(tk.Toplevel):
    def __init__(self, parent, title="Password Required", prompt="Enter Password:"):
        super().__init__(parent)
        self.title(title)
        self.geometry("380x190")
        self.resizable(False, False)
        apply_theme(self)
        self.transient(parent)
        self.grab_set()

        # Center window (on screen if parent is hidden/withdrawn, or relative to parent)
        self.update_idletasks()
        if parent and parent.winfo_viewable() and parent.winfo_width() > 50 and parent.winfo_height() > 50:
            px = parent.winfo_rootx() + (parent.winfo_width() - 380) // 2
            py = parent.winfo_rooty() + (parent.winfo_height() - 190) // 2
        else:
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            px = (sw - 380) // 2
            py = (sh - 190) // 2
        self.geometry(f"380x190+{max(0, px)}+{max(0, py)}")

        self.result = None

        # Container frame
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)

        # Prompt text
        lbl_title = ttk.Label(frame, text=prompt, font=("Segoe UI", 11, "bold"))
        lbl_title.pack(anchor="w", pady=(0, 10))

        # Entry box
        self.entry = ttk.Entry(frame, show="*", font=("Segoe UI", 12), width=30)
        self.entry.pack(fill="x", pady=5)
        self.entry.focus_set()

        # Key bindings
        self.entry.bind("<Return>", self._on_submit)
        self.bind("<Escape>", self._on_cancel)

        # Buttons frame
        btn_frame = ttk.Frame(frame, padding=(0, 15, 0, 0))
        btn_frame.pack(fill="x")

        btn_sub = ttk.Button(btn_frame, text="Unlock", style="Success.TButton", command=self._on_submit)
        btn_sub.pack(side="left", padx=5, expand=True, fill="x")

        btn_can = ttk.Button(btn_frame, text="Cancel", style="Secondary.TButton", command=self._on_cancel)
        btn_can.pack(side="right", padx=5, expand=True, fill="x")

        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

        # Force the popup to actually come to the front and grab focus.
        # (On some Windows setups a Toplevel created with a withdrawn/hidden
        # parent can stay behind other windows or never get keyboard focus,
        # which looks exactly like "the popup never opens".)
        self.deiconify()
        self.lift()
        self.attributes("-topmost", True)
        self.after(150, lambda: self.attributes("-topmost", False))
        self.focus_force()
        self.entry.focus_set()

        self.wait_window()

    def _on_submit(self, event=None):
        self.result = self.entry.get()
        self.destroy()

    def _on_cancel(self, event=None):
        self.result = None
        self.destroy()
