"""
invoice_viewer.py
------------------
Shows all bills. Bills are kept forever unless the shopkeeper manually
deletes old ones from Settings > Delete Bills - nothing here is
auto-cleared.
Columns: Bill No, Date, Customer, Contact, Amount, Paid/Not Paid,
Received, Balance

To keep this screen fast no matter how many bills a shop has piled up
over the years, it doesn't load everything at once:
  - It opens showing only the LAST 3 MONTHS of bills by default.
  - A "From" / "To" date range can be typed in and applied to look at
    any specific period instead.
  - A "Load More" button at the bottom fetches the next page of older
    bills on demand - and once the currently visible date range runs
    out, pressing it again automatically pushes the "From" date further
    back so older history keeps coming without the shopkeeper having to
    retype dates.

Select a bill to preview it below, then press "Open in Billing" (or
just double-click the row) to load that exact bill back into the main
Billing screen, where you can add more products, change anything, and
Save again - it updates the same bill instead of creating a new one.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timedelta

import database as db
from ui_theme import apply_theme, ICON, FONT_BOLD, stripe_treeview, stripe_tag, bordered_table_frame, maximize_window

PAGE_SIZE = 150       # bills fetched per page / per "Load More" click
EXTEND_DAYS = 90      # ~3 months - how far back "Load More" reaches once
                       # the currently visible date range has nothing left


class InvoiceViewerWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.master_app = master
        self.title(f"{ICON['invoice']} All Invoices")
        self.geometry("940x640")
        self.minsize(820, 520)
        apply_theme(self)
        # Opens at a comfortable medium size by default; the user can
        # still maximize it themselves (OS maximize button) if needed.
        # maximize_window(self)

        # --- Pagination / date-range state ---
        today = datetime.now().date()
        self.date_from = today - timedelta(days=EXTEND_DAYS)
        self.date_to = today
        self._min_bill_date = db.get_earliest_bill_date()  # None if no bills yet
        self.loaded_rows = []             # all rows currently shown, newest-first
        self._min_loaded_bill_no = None   # cursor for "Load More"
        self._range_exhausted = False     # no more rows within [date_from, date_to]

        top = ttk.Frame(self, padding=(12, 12, 12, 0))
        top.pack(side="top", fill="x")
        ttk.Label(top, text="Click a bill, then Open in Billing to edit/add products and save again.",
                  font=FONT_BOLD).pack(side="left")

        # --- Date range filter ---
        date_frame = ttk.Frame(self, padding=(12, 8, 12, 0))
        date_frame.pack(side="top", fill="x")
        ttk.Label(date_frame, text="\U0001F4C5 From:", font=FONT_BOLD).pack(side="left", padx=(0, 4))
        self.e_from = ttk.Entry(date_frame, width=12)
        self.e_from.insert(0, self.date_from.strftime("%d-%m-%Y"))
        self.e_from.pack(side="left")
        ttk.Label(date_frame, text="To:", font=FONT_BOLD).pack(side="left", padx=(10, 4))
        self.e_to = ttk.Entry(date_frame, width=12)
        self.e_to.insert(0, self.date_to.strftime("%d-%m-%Y"))
        self.e_to.pack(side="left")
        ttk.Button(date_frame, text="Apply", style="Secondary.TButton",
                   command=self._apply_date_range).pack(side="left", padx=(8, 0))
        ttk.Button(date_frame, text="Last 3 Months", style="Secondary.TButton",
                   command=self._reset_date_range).pack(side="left", padx=(6, 0))
        self.e_from.bind("<Return>", lambda e: self._apply_date_range())
        self.e_to.bind("<Return>", lambda e: self._apply_date_range())
        self.range_label = ttk.Label(date_frame, text="", foreground="#666666")
        self.range_label.pack(side="left", padx=(14, 0))

        # --- Search bar ---
        # Filters the bill list live as you type, matching against Bill
        # No, Customer name, Contact number, Date, or Status - whichever
        # field the text is found in. Search runs against the database
        # (not just what's currently loaded), so it also pages through
        # older bills the same way the plain list does.
        search_frame = ttk.Frame(self, padding=(12, 8, 12, 0))
        search_frame.pack(side="top", fill="x")
        ttk.Label(search_frame, text=f"{ICON['search']} Search:", font=FONT_BOLD).pack(side="left", padx=(0, 6))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._reload(reset=True))
        e_search = ttk.Entry(search_frame, textvariable=self.search_var, width=40)
        e_search.pack(side="left", fill="x", expand=True)
        ttk.Button(search_frame, text=f"{ICON['clear']} Clear", style="Secondary.TButton",
                   command=lambda: self.search_var.set("")).pack(side="left", padx=(6, 0))

        # Buttons + detail box are packed to the BOTTOM first, so they
        # always keep their space reserved and stay fully visible - the
        # bill table below simply shrinks to fit whatever room is left,
        # instead of ever being able to push these off the bottom of the
        # window (same fix already used on the main Billing screen).
        btn_frame = ttk.Frame(self, padding=(12, 0, 12, 12))
        btn_frame.pack(side="bottom", fill="x")
        ttk.Button(btn_frame, text=f"{ICON['edit']} Open in Billing (Edit)", style="Primary.TButton",
                   command=self._open_selected).pack(side="left", padx=4)
        ttk.Button(btn_frame, text=f"{ICON['clear']} Close", style="Secondary.TButton",
                   command=self.destroy).pack(side="left", padx=4)
        self.btn_load_more = ttk.Button(btn_frame, text="\u2b07 Load More", style="Secondary.TButton",
                                         command=self._load_more)
        self.btn_load_more.pack(side="right", padx=4)

        self.detail_box = tk.Text(self, height=9, font=("Consolas", 10))
        self.detail_box.pack(side="bottom", fill="x", padx=12, pady=(0, 12))

        table_frame = ttk.Frame(self, padding=12)
        table_frame.pack(side="top", fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("bill_no", "date", "customer", "contact", "amount", "paid", "received", "balance")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=14)
        headings = {
            "bill_no": "Bill No", "date": "Date", "customer": "Customer",
            "contact": "Contact", "amount": "Amount", "paid": "Status",
            "received": "Received", "balance": "Balance",
        }
        widths = {"bill_no": 60, "date": 120, "customer": 150, "contact": 100, "amount": 90, "paid": 90,
                  "received": 90, "balance": 90}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c])
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.show_detail)
        self.tree.bind("<Double-1>", self._open_selected)
        self.tree.bind("<Return>", self._open_selected)
        stripe_treeview(self.tree)

        self._reload(reset=True)

    # ------------------------------------------------------------------
    # Loading / pagination
    # ------------------------------------------------------------------
    def _reload(self, reset=True):
        """(Re)query bills for the current search text + date range.
        With reset=True this starts over from the newest bill (used
        whenever the search text or date range changes); called again
        internally as a continuation for "Load More"."""
        if reset:
            self.loaded_rows = []
            self._min_loaded_bill_no = None
            self._range_exhausted = False
            for row in self.tree.get_children():
                self.tree.delete(row)
        self._fetch_page()

    def _fetch_page(self):
        query = self.search_var.get().strip()
        rows = db.get_bills_page(
            from_date=self.date_from.strftime("%Y-%m-%d"),
            to_date=self.date_to.strftime("%Y-%m-%d"),
            search=query or None,
            before_bill_no=self._min_loaded_bill_no,
            limit=PAGE_SIZE,
        )
        if rows:
            self._min_loaded_bill_no = min(r[0] for r in rows)
            self.loaded_rows.extend(rows)
            self._render_rows(rows)
        self._range_exhausted = len(rows) < PAGE_SIZE
        self._update_load_more_state()

    def _render_rows(self, rows):
        i = len(self.tree.get_children())
        for b in rows:
            bill_no, date, cust, contact, amount, paid, received, balance = b
            bal_text = f"{balance:.2f}" if received else "-"
            self.tree.insert("", "end", values=(bill_no, date, cust, contact, f"{amount:.2f}", paid,
                                                  f"{received:.2f}" if received else "-", bal_text),
                              tags=(stripe_tag(i),))
            i += 1

    def _at_absolute_start(self):
        if not self._min_bill_date:
            return True
        return self.date_from.strftime("%Y-%m-%d") <= self._min_bill_date[:10]

    def _update_load_more_state(self):
        count = len(self.loaded_rows)
        if self._range_exhausted and self._at_absolute_start():
            self.btn_load_more.config(state="disabled", text="No Older Bills")
        else:
            self.btn_load_more.config(state="normal", text="\u2b07 Load More")
        self.range_label.config(
            text=f"Showing {count} bill(s) from {self.date_from.strftime('%d-%m-%Y')} to "
                 f"{self.date_to.strftime('%d-%m-%Y')}"
        )

    def _load_more(self):
        if self._range_exhausted:
            if self._at_absolute_start():
                return  # nothing older exists - button is disabled anyway
            # Currently visible date range has no more bills in it - push
            # "From" further back so older bills come into view.
            self.date_from = self.date_from - timedelta(days=EXTEND_DAYS)
            if self._min_bill_date:
                floor_date = datetime.strptime(self._min_bill_date[:10], "%Y-%m-%d").date()
                if self.date_from < floor_date:
                    self.date_from = floor_date
            self.e_from.delete(0, "end")
            self.e_from.insert(0, self.date_from.strftime("%d-%m-%Y"))
            self._range_exhausted = False
        self._fetch_page()

    def _apply_date_range(self):
        from_text = self.e_from.get().strip()
        to_text = self.e_to.get().strip()
        try:
            new_from = datetime.strptime(from_text, "%d-%m-%Y").date()
            new_to = datetime.strptime(to_text, "%d-%m-%Y").date()
        except ValueError:
            messagebox.showerror("Invalid Date", "Please enter dates as DD-MM-YYYY.", parent=self)
            return
        if new_from > new_to:
            messagebox.showerror("Invalid Range", "'From' date must be on or before 'To' date.", parent=self)
            return
        self.date_from = new_from
        self.date_to = new_to
        self._reload(reset=True)

    def _reset_date_range(self):
        today = datetime.now().date()
        self.date_from = today - timedelta(days=EXTEND_DAYS)
        self.date_to = today
        self.e_from.delete(0, "end")
        self.e_from.insert(0, self.date_from.strftime("%d-%m-%Y"))
        self.e_to.delete(0, "end")
        self.e_to.insert(0, self.date_to.strftime("%d-%m-%Y"))
        self._reload(reset=True)

    # ------------------------------------------------------------------
    # Selection / detail / open
    # ------------------------------------------------------------------
    def _selected_bill_no(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.item(sel[0], "values")[0]

    def show_detail(self, event):
        bill_no = self._selected_bill_no()
        self.detail_box.delete("1.0", "end")
        if not bill_no:
            return
        bill, items = db.get_bill(bill_no)
        if not bill:
            return
        (bill_no, date, cust_id, cust, contact, address, total, gst_amount, paid, amount_received,
         balance, gstin, hsn_code) = bill
        self.detail_box.insert("end", f"Bill No: {bill_no}   Date: {date}   Status: {paid}\n")
        self.detail_box.insert("end", f"Customer: {cust}   Contact: {contact}   Address: {address}\n")
        self.detail_box.insert("end", "-" * 76 + "\n")
        self.detail_box.insert("end", f"{'Product':<30}{'Qty':>6}{'Price':>10}{'Total':>12}\n")
        for it in items:
            pid, pname, qty, price, tot = it
            self.detail_box.insert("end", f"{pname:<30}{qty:>6}{price:>10.2f}{tot:>12.2f}\n")
        self.detail_box.insert("end", "-" * 76 + "\n")
        if gst_amount:
            self.detail_box.insert("end", f"GST: {gst_amount:.2f}\n")
        self.detail_box.insert("end", f"GRAND TOTAL: {total:.2f}\n")
        if amount_received:
            self.detail_box.insert("end", f"Amount Received: {amount_received:.2f}\n")
            if balance >= 0:
                self.detail_box.insert("end", f"Balance (to give): {balance:.2f}\n")
            else:
                self.detail_box.insert("end", f"Balance Due: -{abs(balance):.2f}\n")

    def _open_selected(self, event=None):
        bill_no = self._selected_bill_no()
        if not bill_no:
            return
        if hasattr(self.master_app, "load_bill_for_edit"):
            self.master_app.load_bill_for_edit(bill_no)
        self.destroy()
