"""
stock_entry.py
---------------
Product Stock Entry popup: search for an existing product, select it,
then update its Stock Count, Cost Price, and Selling Price in one place.

- Selling Price here is the exact same "price" the rest of the app uses
  (billing screen, Products list, receipts) - changing it here updates
  the product everywhere immediately.
- Cost Price is used only to work out profit in Stats - it is never
  shown or printed on a bill.
- Stock Count is set directly to whatever number is typed - including a
  negative number. Nothing here blocks that: if a shop keeps selling
  after stock ran out, the count is simply allowed to go negative
  instead of throwing an error.
- This screen only ever UPDATES an existing product - it doesn't create
  new ones (use the Products popup for that).
"""

import tkinter as tk
from tkinter import ttk, messagebox
import database as db
from ui_theme import apply_theme, ICON, FONT_BOLD, FONT_ENTRY, stripe_treeview, stripe_tag, bordered_table_frame, open_like_invoice


class StockEntryWindow(tk.Toplevel):
    def __init__(self, master, on_change=None):
        super().__init__(master)
        self.title("📦 Product Stock Entry")
        self.configure(bg="#eef2f7")
        apply_theme(self)
        # Opens at a smaller, roughly-square size (not full-screen) - use
        # the window's own maximize button any time you want it bigger.
        open_like_invoice(self)
        # Keep this window tied to the main billing window in the stacking
        # order (transient) and bring it to front + give it focus, so that
        # the confirmation popups below (which are parented to this window)
        # don't leave the main billing window sitting on top of it once
        # they're dismissed - that was making this window look like it had
        # closed on save, when it was actually just stuck behind the main
        # window. It stays open until the user closes it manually.
        self.transient(master)
        self.lift()
        self.focus_force()
        self.on_change = on_change  # callback to refresh main billing screen
        self.selected_pid = None

        # ---- selected-product form ----
        form = ttk.LabelFrame(self, text=" Selected Product ", padding=12)
        form.pack(fill="x", padx=12, pady=(12, 6))

        ttk.Label(form, text="Product ID").grid(row=0, column=0, sticky="w", pady=4)
        self.e_id = ttk.Entry(form, width=18, font=FONT_ENTRY, state="readonly")
        self.e_id.grid(row=0, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Product Name").grid(row=0, column=2, sticky="w", pady=4, padx=(20, 0))
        self.e_name = ttk.Entry(form, width=32, font=FONT_ENTRY, state="readonly")
        self.e_name.grid(row=0, column=3, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Stock Count").grid(row=1, column=0, sticky="w", pady=4)
        self.e_stock = ttk.Entry(form, width=18, font=FONT_ENTRY)
        self.e_stock.grid(row=1, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Cost Price ₹ (for profit calc only)").grid(row=1, column=2, sticky="w", pady=4, padx=(20, 0))
        self.e_cost = ttk.Entry(form, width=18, font=FONT_ENTRY)
        self.e_cost.grid(row=1, column=3, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Selling Price ₹").grid(row=2, column=0, sticky="w", pady=4)
        self.e_price = ttk.Entry(form, width=18, font=FONT_ENTRY)
        self.e_price.grid(row=2, column=1, sticky="w", pady=4, padx=4)

        # Enter moves Stock -> Cost -> Selling Price -> saves
        self.e_stock.bind("<Return>", self._goto(lambda: self.e_cost))
        self.e_cost.bind("<Return>", self._goto(lambda: self.e_price))
        self.e_price.bind("<Return>", lambda e: self.save_entry())

        btns = ttk.Frame(form)
        btns.grid(row=3, column=0, columnspan=4, pady=(10, 2), sticky="w")
        ttk.Button(btns, text=f"{ICON['save']} Update Stock / Price", style="Success.TButton",
                   command=self.save_entry).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['clear']} Clear", style="Secondary.TButton",
                   command=self.clear_form).pack(side="left", padx=4)

        note = ttk.Label(
            self,
            text="Note: Stock can be a negative number (e.g. if it ran out) - that's allowed, no error.",
            font=("Segoe UI", 9, "italic"), foreground="#64748b"
        )
        note.pack(fill="x", padx=16)

        # ---- search bar ----
        search_frame = ttk.Frame(self, padding=(12, 8, 12, 0))
        search_frame.pack(fill="x")
        ttk.Label(search_frame, text=f"{ICON['search']} Search Product:", font=FONT_BOLD).pack(side="left")
        self.e_search = ttk.Entry(search_frame, width=40, font=("Segoe UI", 10))
        self.e_search.pack(side="left", padx=8)
        self.e_search.bind("<KeyRelease>", lambda e: self.refresh_table())
        ttk.Button(search_frame, text="Clear Search", style="Secondary.TButton",
                   command=self._clear_search).pack(side="left")

        # ---- table of products ----
        table_frame = ttk.Frame(self, padding=12)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("id", "name", "stock", "cost", "price")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=14)
        headings = {"id": "Product ID", "name": "Product Name", "stock": "Stock",
                    "cost": "Cost Price", "price": "Selling Price"}
        widths = {"id": 110, "name": 260, "stock": 90, "cost": 110, "price": 110}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c], anchor=("w" if c == "name" else "center"))
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Return>", self.on_select)
        self.tree.bind("<Double-1>", self.on_select)
        stripe_treeview(self.tree)

        self.refresh_table()

    # ---- helper: Enter key moves focus to the next box and selects its text ----
    def _goto(self, widget_getter):
        def handler(event=None):
            widget = widget_getter()
            widget.focus_set()
            try:
                widget.selection_range(0, "end")
            except Exception:
                pass
            return "break"
        return handler

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self.refresh_table()

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        text = self.e_search.get().strip()
        rows = db.search_products_full(text) if text else db.get_all_products_full()
        for i, p in enumerate(rows):
            pid, name, stock, price, cost = p
            self.tree.insert(
                "", "end",
                values=(pid, name, f"{stock:g}", f"{cost:.2f}", f"{price:.2f}"),
                tags=(stripe_tag(i),),
            )

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        pid, name, stock, cost, price = vals
        self.selected_pid = pid

        self.e_id.configure(state="normal")
        self.e_id.delete(0, "end")
        self.e_id.insert(0, pid)
        self.e_id.configure(state="readonly")

        self.e_name.configure(state="normal")
        self.e_name.delete(0, "end")
        self.e_name.insert(0, name)
        self.e_name.configure(state="readonly")

        # Prefill with the previously saved Stock / Cost Price / Selling
        # Price so the shopkeeper only has to change what actually changed.
        self.e_stock.delete(0, "end")
        self.e_stock.insert(0, stock)
        self.e_cost.delete(0, "end")
        self.e_cost.insert(0, cost)
        self.e_price.delete(0, "end")
        self.e_price.insert(0, price)
        self.e_stock.focus_set()
        self.e_stock.selection_range(0, "end")

    def clear_form(self):
        self.selected_pid = None
        for e in (self.e_id, self.e_name):
            e.configure(state="normal")
            e.delete(0, "end")
            e.configure(state="readonly")
        for e in (self.e_stock, self.e_cost, self.e_price):
            e.delete(0, "end")

    def save_entry(self):
        if not self.selected_pid:
            messagebox.showerror("No product selected", "Search and select a product from the list below first.", parent=self)
            return

        stock_text = self.e_stock.get().strip()
        cost_text = self.e_cost.get().strip() or "0"
        price_text = self.e_price.get().strip()

        try:
            # Stock is allowed to be negative on purpose (see note above) -
            # float() already accepts a leading "-" with no extra checks.
            stock = float(stock_text)
            cost_price = float(cost_text)
            price = float(price_text)
        except ValueError:
            messagebox.showerror("Invalid number", "Stock, Cost Price, and Selling Price must all be numbers.", parent=self)
            return

        db.update_stock_entry(self.selected_pid, stock, cost_price, price)
        messagebox.showinfo("Updated", f"Stock/Price updated for '{self.selected_pid}'.", parent=self)
        self.refresh_table()
        if self.on_change:
            self.on_change()
        # Bring this window back to the front after the popup closes and
        # keep it open - it only closes when the user closes it themselves.
        self.lift()
        self.focus_force()
