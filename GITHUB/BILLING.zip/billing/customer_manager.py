"""
customer_manager.py
--------------------
Popup window to Add / Edit / Delete customers.
Fields: Name, Contact, Address.
A search box filters the table, and the table itself is fully
keyboard-navigable (Up/Down arrows + Enter) - no mouse required.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import database as db
from ui_theme import apply_theme, ICON, FONT_BOLD, stripe_treeview, stripe_tag, bordered_table_frame, open_like_invoice


class CustomerManagerWindow(tk.Toplevel):
    def __init__(self, master, on_change=None):
        super().__init__(master)
        self.title(f"{ICON['customer']} Manage Customers")
        apply_theme(self)
        # Opens at a smaller, roughly-square size (not full-screen) - use
        # the window's own maximize button any time you want it bigger.
        open_like_invoice(self)
        # Keep this window tied to the main billing window in the stacking
        # order (transient), so when a Yes/No confirm popup (e.g. on
        # Delete) opens and closes, this window comes back on TOP of the
        # main window instead of slipping behind it.
        self.transient(master)
        self.lift()
        self.focus_force()
        self.on_change = on_change
        self.selected_id = None

        form = ttk.Frame(self, padding=12)
        form.pack(fill="x")

        ttk.Label(form, text="Name").grid(row=0, column=0, sticky="w", pady=4)
        self.e_name = ttk.Entry(form, width=30, font=("Segoe UI", 10))
        self.e_name.grid(row=0, column=1, pady=4, padx=4, sticky="w")

        ttk.Label(form, text="Contact").grid(row=1, column=0, sticky="w", pady=4)
        self.e_contact = ttk.Entry(form, width=20, font=("Segoe UI", 10))
        self.e_contact.grid(row=1, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Address").grid(row=2, column=0, sticky="w", pady=4)
        self.e_address = ttk.Entry(form, width=40, font=("Segoe UI", 10))
        self.e_address.grid(row=2, column=1, pady=4, padx=4, sticky="w")

        # ---- Enter moves through the fields in order; Enter on the last
        # field (Address) saves the record - Add New for a fresh customer,
        # or Update Selected if a row is currently selected in the table
        # below. No mouse needed to add/edit a customer. ----
        self.e_name.bind("<Return>", self._goto(lambda: self.e_contact))
        self.e_contact.bind("<Return>", self._goto(lambda: self.e_address))
        self.e_address.bind("<Return>", self._submit_on_enter)

        btns = ttk.Frame(form)
        btns.grid(row=3, column=0, columnspan=2, pady=12, sticky="w")
        ttk.Button(btns, text=f"{ICON['add']} Add New", style="Success.TButton",
                   command=self.add_customer).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['update']} Update Selected", style="Primary.TButton",
                   command=self.update_customer).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['delete']} Delete Selected", style="Danger.TButton",
                   command=self.delete_customer).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['clear']} Clear", style="Secondary.TButton",
                   command=self.clear_form).pack(side="left", padx=4)

        # ---- search bar ----
        search_frame = ttk.Frame(self, padding=(12, 0))
        search_frame.pack(fill="x")
        ttk.Label(search_frame, text=f"{ICON['search']} Search:", font=FONT_BOLD).pack(side="left")
        self.e_search = ttk.Entry(search_frame, width=40, font=("Segoe UI", 10))
        self.e_search.pack(side="left", padx=8)
        self.e_search.bind("<KeyRelease>", lambda e: self.refresh_table())
        ttk.Button(search_frame, text="Clear Search", style="Secondary.TButton",
                   command=self._clear_search).pack(side="left")

        table_frame = ttk.Frame(self, padding=12)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("id", "name", "contact", "address")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=12)
        headings = {"id": "ID", "name": "Name", "contact": "Contact", "address": "Address"}
        widths = {"id": 40, "name": 160, "contact": 120, "address": 230}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c])
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Return>", self.on_select)
        stripe_treeview(self.tree)

        self.refresh_table()
        self.e_name.focus_set()

    # ---- helper: Enter key moves focus to the next box and selects its text ----
    def _goto(self, widget_getter):
        def handler(event=None):
            widget = widget_getter()
            widget.focus_set()
            try:
                widget.selection_range(0, "end")
            except Exception:
                pass
            return "break"
        return handler

    def _submit_on_enter(self, event=None):
        """Enter on the last field (Address): Update if a row is selected,
        otherwise Add New - then jump back to Name for the next one."""
        if self.selected_id:
            self.update_customer()
        else:
            self.add_customer()
        self.e_name.focus_set()
        return "break"

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self.refresh_table()

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        text = self.e_search.get().strip()
        rows = db.search_customers(text) if text else db.get_all_customers()
        for i, c in enumerate(rows):
            self.tree.insert("", "end", values=c, tags=(stripe_tag(i),))

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        self.selected_id = vals[0]
        self.clear_form(keep_id=True)
        self.e_name.insert(0, vals[1])
        self.e_contact.insert(0, vals[2])
        self.e_address.insert(0, vals[3])

    def clear_form(self, keep_id=False):
        if not keep_id:
            self.selected_id = None
        for e in (self.e_name, self.e_contact, self.e_address):
            e.delete(0, "end")

    def add_customer(self):
        name = self.e_name.get().strip()
        if not name:
            messagebox.showerror("Missing info", "Customer name is required.", parent=self)
            return
        db.add_customer(name, self.e_contact.get().strip(), self.e_address.get().strip())
        self.refresh_table()
        self.clear_form()
        if self.on_change:
            self.on_change()

    def update_customer(self):
        if not self.selected_id:
            messagebox.showerror("No selection", "Select a customer from the table first.", parent=self)
            return
        name = self.e_name.get().strip()
        if not name:
            messagebox.showerror("Missing info", "Customer name is required.", parent=self)
            return
        db.update_customer(self.selected_id, name, self.e_contact.get().strip(), self.e_address.get().strip())
        self.refresh_table()
        self.clear_form()
        if self.on_change:
            self.on_change()

    def delete_customer(self):
        if not self.selected_id:
            messagebox.showerror("No selection", "Select a customer from the table first.", parent=self)
            self.lift()
            self.focus_force()
            return

        # Don't allow deleting a customer who still has an open (unpaid /
        # partially-paid) due. Their dues history and balance would be
        # orphaned otherwise. Make them settle it in the Dues screen
        # first, then delete.
        name = self.e_name.get().strip()
        open_due = db.get_open_due_for_customer(self.selected_id, name)
        if open_due:
            due_id, total_due, balance_due = open_due
            if balance_due and balance_due > 0:
                messagebox.showwarning(
                    "Dues pending",
                    f"'{name}' still has a pending due of ₹{balance_due:.2f}.\n\n"
                    "Please finish/settle their dues first (Dues screen), "
                    "then delete this customer.",
                    parent=self,
                )
                self.lift()
                self.focus_force()
                return

        answer = messagebox.askyesno("Confirm", "Delete this customer?", parent=self)
        # Bring this window back to the front no matter what was chosen,
        # since the confirm popup can otherwise leave the main billing
        # window on top of this one.
        self.lift()
        self.focus_force()
        if answer:
            db.delete_customer(self.selected_id)
            self.refresh_table()
            self.clear_form()
            if self.on_change:
                self.on_change()
