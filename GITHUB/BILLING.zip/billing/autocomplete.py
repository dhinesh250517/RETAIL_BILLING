"""
autocomplete.py
-----------------
A small floating suggestion list that appears under an Entry box while
typing (Customer Name, Product ID, etc). Fully keyboard operable:

    - Type to search
    - Press Down / Up arrow to move the highlight
    - Press Enter to pick the highlighted suggestion
    - Press Escape to close it
    - Mouse click also still works

This is used everywhere a "type and pick from a list" box is needed.
"""

import tkinter as tk
import tkinter.font as tkfont


def _fit_popup_width(entry, listbox, texts, extra_padding=34):
    """Works out how wide the popup needs to be so every suggestion is
    fully visible - never cut off - even when the text is longer than the
    box it's attached to. Never shrinks below the entry's own width."""
    font = tkfont.Font(font=listbox.cget("font"))
    max_text_w = max((font.measure(t) for t in texts), default=0)
    return max(entry.winfo_width(), max_text_w + extra_padding)


def _place_popup(popup, entry, width):
    popup.update_idletasks()
    x = entry.winfo_rootx()
    y = entry.winfo_rooty() + entry.winfo_height()
    h_px = popup.winfo_reqheight()
    popup.wm_geometry(f"{width}x{h_px}+{x}+{y}")


class AutocompletePopup:
    def __init__(self, entry, search_func, on_pick, width=42, height=10, on_enter_no_match=None):
        self.entry = entry
        self.search_func = search_func
        self.on_pick = on_pick
        self.popup = None
        self.listbox = None
        self.rows = []
        self.width = width
        self.height = height
        # Called when Enter is pressed but no suggestion dropdown is open
        # (e.g. box left empty, or typed value has no match) - lets the
        # caller move focus on to the next box anyway.
        self.on_enter_no_match = on_enter_no_match

        entry.bind("<KeyRelease>", self._on_key)
        entry.bind("<Down>", self._move_down)
        entry.bind("<Up>", self._move_up)
        entry.bind("<Return>", self._on_enter)
        entry.bind("<Escape>", lambda e: self._close())
        entry.bind("<FocusOut>", lambda e: entry.after(200, self._close))

    # ---- typing ----
    def _on_key(self, event):
        if event.keysym in ("Up", "Down", "Return", "Escape"):
            return
        text = self.entry.get().strip()
        if not text:
            self._close()
            return
        self.rows = self.search_func(text)
        if not self.rows:
            self._close()
            return
        self._open()
        self.listbox.delete(0, "end")
        texts = [r[1] for r in self.rows]
        for t in texts:
            self.listbox.insert("end", t)
        # Widen the popup (never shrink it) so every suggestion - Product
        # ID included - is fully readable even if it's longer than the
        # box it's attached to, instead of being cut off at the entry's
        # own width.
        _place_popup(self.popup, self.entry, _fit_popup_width(self.entry, self.listbox, texts))
        if self.rows:
            self.listbox.selection_clear(0, "end")
            self.listbox.selection_set(0)
            self.listbox.activate(0)

    def _open(self):
        if self.popup:
            return
        self.popup = tk.Toplevel(self.entry)
        self.popup.wm_overrideredirect(True)
        
        self.listbox = tk.Listbox(
            self.popup, height=self.height,
            activestyle="dotbox", selectbackground="#2563eb", selectforeground="white",
            font=("Segoe UI", 12),
        )
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<ButtonRelease-1>", self._pick_mouse)
        self.listbox.bind("<Return>", self._pick_mouse)

        # Force layout update to get requested height, then match geometry to entry width
        self.popup.update_idletasks()
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        w_px = self.entry.winfo_width()
        h_px = self.popup.winfo_reqheight()
        self.popup.wm_geometry(f"{w_px}x{h_px}+{x}+{y}")

    # ---- keyboard navigation while focus stays in the Entry ----
    def _move_down(self, event):
        if not self.popup:
            return "break"
        size = self.listbox.size()
        if size == 0:
            return "break"
        cur = self.listbox.curselection()
        idx = (cur[0] + 1) if cur else 0
        idx = min(idx, size - 1)
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(idx)
        self.listbox.activate(idx)
        self.listbox.see(idx)
        return "break"

    def _move_up(self, event):
        if not self.popup:
            return "break"
        size = self.listbox.size()
        if size == 0:
            return "break"
        cur = self.listbox.curselection()
        idx = (cur[0] - 1) if cur else 0
        idx = max(idx, 0)
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(idx)
        self.listbox.activate(idx)
        self.listbox.see(idx)
        return "break"

    def _on_enter(self, event):
        if not self.popup:
            if self.on_enter_no_match:
                self.on_enter_no_match(event)
            return "break"
        sel = self.listbox.curselection()
        idx = sel[0] if sel else 0
        if idx < len(self.rows):
            row = self.rows[idx]
            self.on_pick(row)
        self._close()
        return "break"

    def _pick_mouse(self, event):
        if not self.listbox.curselection():
            return
        idx = self.listbox.curselection()[0]
        row = self.rows[idx]
        self.on_pick(row)
        self._close()

    def _close(self):
        if self.popup:
            self.popup.destroy()
            self.popup = None
            self.listbox = None


class PricePopup:
    """A floating suggestion list for product prices. Shows a history of
    recent prices this customer paid for this product when the price entry
    gets focus.
    
    If the user presses Return and the popup is open, it selects the value.
    If the popup is closed, it triggers the default action (e.g. adding item).
    """
    def __init__(self, entry, get_prices_func, on_pick, width=35, height=10, on_enter_no_match=None):
        self.entry = entry
        self.get_prices_func = get_prices_func
        self.on_pick = on_pick
        self.popup = None
        self.listbox = None
        self.rows = []
        self.width = width
        self.height = height
        self.on_enter_no_match = on_enter_no_match

        entry.bind("<FocusIn>", self._on_focus_in, add="+")
        entry.bind("<Down>", self._move_down)
        entry.bind("<Up>", self._move_up)
        entry.bind("<Return>", self._on_enter)
        entry.bind("<Escape>", lambda e: self._close())
        entry.bind("<FocusOut>", lambda e: entry.after(200, self._close))

    def _on_focus_in(self, event=None):
        self.rows = self.get_prices_func()
        if not self.rows:
            self._close()
            return
        
        self._open()
        self.listbox.delete(0, "end")
        # Just the price and the date it was billed on - nothing else -
        # so the last five prices are easy to scan at a glance.
        texts = []
        for price, qty, bdate in self.rows:
            date_str = bdate[:10] if bdate else ""
            display_text = f"₹{price:g} - {date_str}"
            texts.append(display_text)
            self.listbox.insert("end", display_text)

        # Widen the popup (never shrink it) so every price/date is fully
        # visible even if it runs longer than the Price box itself.
        _place_popup(self.popup, self.entry, _fit_popup_width(self.entry, self.listbox, texts))

        if self.rows:
            self.listbox.selection_clear(0, "end")
            self.listbox.selection_set(0)
            self.listbox.activate(0)

    def _open(self):
        if self.popup:
            return
        self.popup = tk.Toplevel(self.entry)
        self.popup.wm_overrideredirect(True)
        
        self.listbox = tk.Listbox(
            self.popup, height=self.height,
            activestyle="dotbox", selectbackground="#2563eb", selectforeground="white",
            font=("Segoe UI", 12),
        )
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<ButtonRelease-1>", self._pick_mouse)
        self.listbox.bind("<Return>", self._pick_mouse)

        # Force layout update to get requested height, then match geometry to entry width
        self.popup.update_idletasks()
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        w_px = self.entry.winfo_width()
        h_px = self.popup.winfo_reqheight()
        self.popup.wm_geometry(f"{w_px}x{h_px}+{x}+{y}")

    def _move_down(self, event):
        if not self.popup:
            return None  # let event propagate to entry
        size = self.listbox.size()
        if size == 0:
            return "break"
        cur = self.listbox.curselection()
        idx = (cur[0] + 1) if cur else 0
        idx = min(idx, size - 1)
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(idx)
        self.listbox.activate(idx)
        self.listbox.see(idx)
        return "break"

    def _move_up(self, event):
        if not self.popup:
            return None  # let event propagate to entry
        size = self.listbox.size()
        if size == 0:
            return "break"
        cur = self.listbox.curselection()
        idx = (cur[0] - 1) if cur else 0
        idx = max(idx, 0)
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(idx)
        self.listbox.activate(idx)
        self.listbox.see(idx)
        return "break"

    def _on_enter(self, event):
        if not self.popup:
            if self.on_enter_no_match:
                return self.on_enter_no_match(event)
            return None
        sel = self.listbox.curselection()
        idx = sel[0] if sel else 0
        if idx < len(self.rows):
            price = self.rows[idx][0]
            self.on_pick(price)
        self._close()
        return "break"

    def _pick_mouse(self, event):
        if not self.listbox.curselection():
            return
        idx = self.listbox.curselection()[0]
        price = self.rows[idx][0]
        self.on_pick(price)
        self._close()

    def _close(self):
        if self.popup:
            self.popup.destroy()
            self.popup = None
            self.listbox = None

