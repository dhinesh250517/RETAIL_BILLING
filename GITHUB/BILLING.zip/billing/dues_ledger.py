"""
dues_ledger.py
--------------
Customer Dues Ledger / Credit tracker window.
Tracks customer dues, outstanding balances, and partial repayments.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime

import database as db
from autocomplete import AutocompletePopup
from ui_theme import apply_theme, stripe_treeview, stripe_tag, FONT_BIG, FONT_BOLD, HEADER_BG, HEADER_FG, bordered_table_frame, maximize_window


class DuesLedgerWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("💵 Customer Dues Ledger")
        self.geometry("1150x720")
        self.minsize(1000, 620)
        apply_theme(self)
        # Opens at a comfortable medium size by default; the user can
        # still maximize it themselves (OS maximize button) if needed.
        # maximize_window(self)
        self.grab_set()

        self.selected_customer_id = None
        self.selected_due_id = None

        # Title frame
        title_frame = tk.Frame(self, bg=HEADER_BG, pady=10)
        title_frame.pack(fill="x")
        ttk.Label(title_frame, text="💵 Customer Dues Ledger & Repayments Log", font=FONT_BIG, background=HEADER_BG, foreground=HEADER_FG).pack(anchor="center")

        # Split pane
        main_paned = ttk.PanedWindow(self, orient="horizontal")
        main_paned.pack(fill="both", expand=True, padx=10, pady=10)

        # Left panel: Form + Summary
        left_frame = ttk.Frame(main_paned, padding=10)
        main_paned.add(left_frame, weight=1)

        # Due Entry Form
        form_lbl = ttk.Label(left_frame, text="Add New Due Entry", font=FONT_BOLD)
        form_lbl.pack(anchor="w", pady=(0, 10))

        # Customer field
        ttk.Label(left_frame, text="Customer Name:").pack(anchor="w", pady=2)
        self.e_customer = ttk.Entry(left_frame, font=("Segoe UI", 11))
        self.e_customer.pack(fill="x", pady=2)
        self.e_customer.focus_set()
        
        # Link autocomplete to existing customers
        AutocompletePopup(self.e_customer, self._search_customers, self._pick_customer)

        # Contact field
        ttk.Label(left_frame, text="Contact Number (Optional):").pack(anchor="w", pady=2)
        self.e_contact = ttk.Entry(left_frame, font=("Segoe UI", 11))
        self.e_contact.pack(fill="x", pady=2)

        # Amount field
        ttk.Label(left_frame, text="Due Amount (₹):").pack(anchor="w", pady=2)
        self.e_amount = ttk.Entry(left_frame, font=("Segoe UI", 11))
        self.e_amount.pack(fill="x", pady=2)
        self.e_amount.bind("<Return>", lambda e: self._add_due())

        # Save Button
        btn_add = ttk.Button(left_frame, text="➕ Add Due Entry", style="Success.TButton", command=self._add_due)
        btn_add.pack(fill="x", pady=12)

        # Divider line
        ttk.Separator(left_frame, orient="horizontal").pack(fill="x", pady=15)

        # Summary Frame at bottom-left
        summary_lbl = ttk.Label(left_frame, text="Ledger Summary", font=FONT_BOLD)
        summary_lbl.pack(anchor="w", pady=(0, 10))

        self.lbl_sum_total = ttk.Label(left_frame, text="Total Dues Logged: ₹0.00", font=("Segoe UI", 11))
        self.lbl_sum_total.pack(anchor="w", pady=3)

        self.lbl_sum_balance = ttk.Label(left_frame, text="Total Outstanding: ₹0.00", font=("Segoe UI", 11, "bold"), foreground="#dc2626")
        self.lbl_sum_balance.pack(anchor="w", pady=3)

        # Completed Dues - customers whose dues have been fully paid off.
        # These no longer show in the Dues Registry above (it's active
        # dues only), but nothing is deleted - this button opens a
        # detailed view of every due that's been cleared, with its full
        # payment history.
        ttk.Button(left_frame, text="✅ Completed Dues", style="Success.TButton",
                   command=self._open_completed_dues).pack(fill="x", pady=(8, 3))

        # Right panel: Tables
        right_frame = ttk.Frame(main_paned, padding=10)
        main_paned.add(right_frame, weight=3)

        # Search bar
        search_frame = ttk.Frame(right_frame)
        search_frame.pack(fill="x", pady=(0, 10))
        
        ttk.Label(search_frame, text="🔍 Search Customer:").pack(side="left", padx=(0, 5))
        self.e_search = ttk.Entry(search_frame, font=("Segoe UI", 10), width=25)
        self.e_search.pack(side="left", padx=5)
        self.e_search.bind("<KeyRelease>", self._on_search_key)
        
        btn_clear = ttk.Button(search_frame, text="Clear", command=self._clear_search)
        btn_clear.pack(side="left", padx=5)

        # Dues Treeview Table
        table_lbl = ttk.Label(right_frame, text="Dues Registry", font=FONT_BOLD)
        table_lbl.pack(anchor="w", pady=(0, 5))

        due_grid_frame = bordered_table_frame(right_frame)

        cols = ("id", "name", "contact", "total", "balance", "status", "date")
        self.due_tree = ttk.Treeview(due_grid_frame, columns=cols, show="headings", height=8)
        self.due_tree.heading("id", text="ID")
        self.due_tree.heading("name", text="Customer Name")
        self.due_tree.heading("contact", text="Contact")
        self.due_tree.heading("total", text="Total Due")
        self.due_tree.heading("balance", text="Balance Due")
        self.due_tree.heading("status", text="Status")
        self.due_tree.heading("date", text="Date Added")

        self.due_tree.column("id", width=50, anchor="center")
        self.due_tree.column("name", width=200, anchor="w")
        self.due_tree.column("contact", width=110, anchor="center")
        self.due_tree.column("total", width=110, anchor="e")
        self.due_tree.column("balance", width=110, anchor="e")
        self.due_tree.column("status", width=90, anchor="center")
        self.due_tree.column("date", width=120, anchor="center")

        self.due_tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(due_grid_frame, orient="vertical", command=self.due_tree.yview)
        scroll.pack(side="right", fill="y")
        self.due_tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.due_tree)
        self.due_tree.bind("<<TreeviewSelect>>", self._on_due_select)
        self.due_tree.bind("<Double-1>", self._edit_due_dialog)
        self.due_tree.bind("<Return>", self._edit_due_dialog)

        # Actions buttons frame - packed FIRST with side="bottom" so it
        # always reserves its space and stays visible/on-screen no matter
        # how tall the tables above end up being on a smaller display.
        actions_frame = ttk.Frame(right_frame, padding=(0, 10, 0, 0))
        actions_frame.pack(side="bottom", fill="x")

        self.btn_pay = ttk.Button(actions_frame, text="💰 Record Payment", style="Success.TButton", state="disabled", command=self._record_payment)
        self.btn_pay.pack(side="left", padx=5)

        self.btn_delete = ttk.Button(actions_frame, text="🗑️ Delete Entry", style="Danger.TButton", state="disabled", command=self._delete_due)
        self.btn_delete.pack(side="right", padx=5)

        # Repayments label and history table (shows BOTH partial payments
        # made AND additional dues added, in one combined timeline, until
        # the due is fully cleared - at which point the entry moves out
        # of the active Dues Registry above and into Completed Dues,
        # taking this log with it).
        history_lbl = ttk.Label(right_frame, text="Repayment Log (Partial Payments + Additional Dues Added)", font=FONT_BOLD)
        history_lbl.pack(anchor="w", pady=(15, 5))

        hist_grid_frame = bordered_table_frame(right_frame)

        hist_cols = ("date", "type", "amount", "remarks")
        self.hist_tree = ttk.Treeview(hist_grid_frame, columns=hist_cols, show="headings", height=6)
        self.hist_tree.heading("date", text="Date")
        self.hist_tree.heading("type", text="Type")
        self.hist_tree.heading("amount", text="Amount")
        self.hist_tree.heading("remarks", text="Remarks / Description")

        self.hist_tree.column("date", width=140, anchor="center")
        self.hist_tree.column("type", width=110, anchor="center")
        self.hist_tree.column("amount", width=120, anchor="e")
        self.hist_tree.column("remarks", width=330, anchor="w")

        self.hist_tree.pack(fill="both", expand=True, side="left")
        hist_scroll = ttk.Scrollbar(hist_grid_frame, orient="vertical", command=self.hist_tree.yview)
        hist_scroll.pack(side="right", fill="y")
        self.hist_tree.configure(yscrollcommand=hist_scroll.set)
        stripe_treeview(self.hist_tree)
        self.hist_tree.tag_configure("due_added", foreground="#b45309")
        self.hist_tree.tag_configure("payment", foreground="#166534")
        self.hist_tree.bind("<Double-1>", self._edit_log_entry_dialog)
        self.hist_tree.bind("<Return>", self._edit_log_entry_dialog)

        # Initial load
        self._load_dues()

    def _open_completed_dues(self):
        CompletedDuesWindow(self)

    def _search_customers(self, query):
        if not query:
            return []
        rows = db.search_customers(query)
        return [(r[1], f"{r[1]} - {r[2]} ({r[3]})", r) for r in rows]

    def _pick_customer(self, row):
        name, display, full = row
        cid, cust_name, contact, address = full
        
        self.e_customer.delete(0, "end")
        self.e_customer.insert(0, cust_name)
        
        self.selected_customer_id = cid
        self.e_contact.delete(0, "end")
        if contact:
            self.e_contact.insert(0, contact)

    def _load_dues(self, search_text=""):
        for row in self.due_tree.get_children():
            self.due_tree.delete(row)
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)

        self.selected_due_id = None
        self.btn_pay.configure(state="disabled")
        self.btn_delete.configure(state="disabled")

        try:
            dues = db.get_all_dues(search_text)
            total_sum = 0
            balance_sum = 0
            for i, (did, name, contact, total, balance, status, dt) in enumerate(dues):
                date_str = dt[:10] if dt else ""
                self.due_tree.insert("", "end", values=(did, name, contact or "-", f"₹{total:,.2f}", f"₹{balance:,.2f}", status, date_str), tags=(stripe_tag(i),))
                total_sum += total
                balance_sum += balance

            self.lbl_sum_total.configure(text=f"Total Dues Logged: ₹{total_sum:,.2f}")
            self.lbl_sum_balance.configure(text=f"Total Outstanding: ₹{balance_sum:,.2f}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load dues registry:\n{str(e)}", parent=self)

    def _on_search_key(self, event=None):
        self._load_dues(self.e_search.get().strip())

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self._load_dues()

    def _add_due(self):
        name = self.e_customer.get().strip()
        contact = self.e_contact.get().strip()
        amt_str = self.e_amount.get().strip()

        if not name:
            messagebox.showerror("Validation Error", "Please enter a Customer Name.", parent=self)
            return
        if not amt_str:
            messagebox.showerror("Validation Error", "Please enter a Due Amount.", parent=self)
            return

        try:
            amt = float(amt_str)
            if amt <= 0:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Validation Error", "Due Amount must be a positive number.", parent=self)
            return

        try:
            db.add_customer_due(self.selected_customer_id, name, contact, amt)
            messagebox.showinfo("Success", "Credit entry added successfully!", parent=self)
            
            # Clear form
            self.e_customer.delete(0, "end")
            self.e_contact.delete(0, "end")
            self.e_amount.delete(0, "end")
            self.selected_customer_id = None
            
            self._load_dues()
            self.e_customer.focus_set()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to save credit entry:\n{str(e)}", parent=self)

    def _on_due_select(self, event=None):
        selected = self.due_tree.selection()
        if not selected:
            return
        
        item = self.due_tree.item(selected[0])
        self.selected_due_id = item["values"][0]
        status = item["values"][5]

        # Enable/Disable repayment recording based on status
        if status == "Paid":
            self.btn_pay.configure(state="disabled")
        else:
            self.btn_pay.configure(state="normal")
            
        self.btn_delete.configure(state="normal")

        # Load payment history
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)

        try:
            events = db.get_due_payments(self.selected_due_id)
            for i, (eid, amount, edate, remarks, entry_type) in enumerate(events):
                is_due_added = (entry_type == "due_added")
                type_label = "➕ Due Added" if is_due_added else "💰 Payment"
                # iid is the real due_payments row id, so double-clicking or
                # pressing Enter on a row can look the exact entry back up
                # to edit/correct it.
                self.hist_tree.insert(
                    "", "end", iid=str(eid),
                    values=(edate[:16], type_label, f"₹{amount:,.2f}", remarks or "-"),
                    tags=("due_added" if is_due_added else "payment",)
                )
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to load repayments list:\n{str(e)}", parent=self)

    def _record_payment(self):
        if not self.selected_due_id:
            return

        # Fetch current balance
        selected = self.due_tree.selection()
        item = self.due_tree.item(selected[0])
        balance_str = item["values"][4].replace("₹", "").replace(",", "")
        balance = float(balance_str)

        # Prompt for payment amount
        amt_str = simpledialog.askstring("Record Payment", f"Enter Amount Paid (Remaining: ₹{balance:,.2f}):", parent=self)
        if not amt_str:
            return

        try:
            amt = float(amt_str)
            if amt <= 0:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Validation Error", "Payment must be a positive number.", parent=self)
            return

        # If the customer hands over more than what's actually due (e.g.
        # balance is ₹200 but they give ₹300), don't reject it - clear the
        # due with exactly the balance amount and tell the shopkeeper how
        # much change/excess needs to be handed back to the customer.
        change_to_return = 0.0
        amt_to_record = amt
        if amt > balance:
            change_to_return = amt - balance
            amt_to_record = balance

        remarks = simpledialog.askstring("Payment Remarks", "Enter remarks / transaction details (optional):", parent=self) or ""
        if change_to_return > 0:
            note = f"(Customer paid ₹{amt:,.2f}; ₹{change_to_return:,.2f} returned as change)"
            remarks = f"{remarks} {note}".strip()

        try:
            fully_paid = db.record_due_payment(self.selected_due_id, amt_to_record, remarks)

            if change_to_return > 0:
                messagebox.showinfo(
                    "Excess Payment - Return Change to Customer",
                    f"Amount due was ₹{amt_to_record:,.2f}, but the customer paid ₹{amt:,.2f}.\n\n"
                    f"💰 Return ₹{change_to_return:,.2f} change to the customer.",
                    parent=self,
                )

            if fully_paid:
                messagebox.showinfo(
                    "Due Cleared", f"Repayment of ₹{amt_to_record:,.2f} recorded.\n\nThis due is now fully paid - "
                    f"it has moved to Completed Dues.", parent=self)
            else:
                messagebox.showinfo("Success", f"Repayment of ₹{amt_to_record:,.2f} recorded successfully!", parent=self)
            self._load_dues()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to record repayment:\n{str(e)}", parent=self)

    def _delete_due(self):
        if not self.selected_due_id:
            return
        
        selected = self.due_tree.selection()
        item = self.due_tree.item(selected[0])
        name = item["values"][1]

        if not messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the credit ledger entry and all payment history for '{name}'?", parent=self):
            return

        try:
            db.delete_customer_due(self.selected_due_id)
            messagebox.showinfo("Success", "Credit entry deleted successfully!", parent=self)
            self._load_dues()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to delete entry:\n{str(e)}", parent=self)

    # ---------------- EDIT DIALOGS (correcting wrong entries) ----------------
    def _refresh_due_and_history(self, due_id):
        """Reload the Dues Registry, then try to re-select the same due
        row so its Repayment Log underneath refreshes to match it. If the
        due no longer exists (e.g. a correction just fully cleared it),
        the history table below is simply left empty."""
        self._load_dues()
        for item in self.due_tree.get_children():
            vals = self.due_tree.item(item, "values")
            if vals and str(vals[0]) == str(due_id):
                self.due_tree.selection_set(item)
                self.due_tree.see(item)
                self._on_due_select()
                return
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)

    def _edit_due_dialog(self, event=None):
        """Double-click or Enter on a Dues Registry row - lets you correct
        the customer name / contact number on that entry. Deliberately
        does not let you edit Total Due / Balance Due directly here: those
        numbers are always derived from the Repayment Log underneath, so
        amount corrections happen there instead (one source of truth)."""
        selected = self.due_tree.selection()
        if not selected:
            return
        item = self.due_tree.item(selected[0])
        due_id, name, contact, total, balance, status, date_str = item["values"]

        dlg = tk.Toplevel(self)
        dlg.title(f"Edit Due Entry #{due_id}")
        dlg.geometry("400x280")
        dlg.resizable(False, False)
        apply_theme(dlg)
        dlg.transient(self)
        dlg.grab_set()

        frm = ttk.Frame(dlg, padding=15)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text=f"Editing Due Entry #{due_id}", font=FONT_BOLD).pack(anchor="w", pady=(0, 12))

        ttk.Label(frm, text="Customer Name:").pack(anchor="w")
        e_name = ttk.Entry(frm, font=("Segoe UI", 11))
        e_name.insert(0, name)
        e_name.pack(fill="x", pady=(0, 8))

        ttk.Label(frm, text="Contact Number:").pack(anchor="w")
        e_contact = ttk.Entry(frm, font=("Segoe UI", 11))
        e_contact.insert(0, "" if contact == "-" else contact)
        e_contact.pack(fill="x", pady=(0, 8))

       

        def do_save(event=None):
            new_name = e_name.get().strip()
            new_contact = e_contact.get().strip()
            if not new_name:
                messagebox.showerror("Validation Error", "Customer Name cannot be empty.", parent=dlg)
                return
            try:
                db.update_due_customer_info(due_id, new_name, new_contact)
                dlg.destroy()
                self._refresh_due_and_history(due_id)
            except Exception as e:
                messagebox.showerror("Database Error", f"Failed to update entry:\n{str(e)}", parent=dlg)

        e_contact.bind("<Return>", do_save)
        btn_row = ttk.Frame(frm)
        btn_row.pack(fill="x", pady=(6, 0))
        ttk.Button(btn_row, text="💾 Save", style="Success.TButton", command=do_save).pack(side="left")
        ttk.Button(btn_row, text="Cancel", style="Secondary.TButton", command=dlg.destroy).pack(side="left", padx=8)

        e_name.focus_set()
        e_name.selection_range(0, "end")

    def _edit_log_entry_dialog(self, event=None):
        """Double-click or Enter on a Repayment Log row - opens an edit
        dialog to fix a wrongly-typed entry (wrong amount, wrong remarks,
        or even wrong type - accidentally logged as a payment instead of
        an additional due, or vice versa). Saving recalculates this due's
        Total Due / Balance Due fresh from the corrected log, so the
        Dues Registry table above always stays in sync automatically."""
        selected = self.hist_tree.selection()
        if not selected:
            return
        entry_id = int(selected[0])
        item = self.hist_tree.item(selected[0])
        date_str, type_label, amount_str, remarks = item["values"]
        current_type = "due_added" if "Due Added" in type_label else "payment"
        amount_val = float(str(amount_str).replace("₹", "").replace(",", ""))

        dlg = tk.Toplevel(self)
        dlg.title("Edit Repayment Log Entry")
        dlg.geometry("400x320")
        dlg.resizable(False, False)
        apply_theme(dlg)
        dlg.transient(self)
        dlg.grab_set()

        frm = ttk.Frame(dlg, padding=15)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text=f"Editing Log Entry ({date_str})", font=FONT_BOLD).pack(anchor="w", pady=(0, 12))

        ttk.Label(frm, text="Entry Type:").pack(anchor="w")
        type_var = tk.StringVar(value="Due Added" if current_type == "due_added" else "Payment")
        combo = ttk.Combobox(frm, textvariable=type_var, values=["Due Added", "Payment"],
                              state="readonly", font=("Segoe UI", 11))
        combo.pack(fill="x", pady=(0, 8))

        ttk.Label(frm, text="Amount (₹):").pack(anchor="w")
        e_amount = ttk.Entry(frm, font=("Segoe UI", 11))
        e_amount.insert(0, f"{amount_val:g}")
        e_amount.pack(fill="x", pady=(0, 8))

        ttk.Label(frm, text="Remarks:").pack(anchor="w")
        e_remarks = ttk.Entry(frm, font=("Segoe UI", 11))
        e_remarks.insert(0, "" if remarks == "-" else remarks)
        e_remarks.pack(fill="x", pady=(0, 8))

        

        def do_save(event=None):
            amt_str = e_amount.get().strip()
            try:
                amt = float(amt_str)
                if amt <= 0:
                    raise ValueError()
            except ValueError:
                messagebox.showerror("Validation Error", "Amount must be a positive number.", parent=dlg)
                return
            new_type = "due_added" if type_var.get() == "Due Added" else "payment"
            new_remarks = e_remarks.get().strip()

            try:
                due_id, fully_paid = db.update_due_payment_entry(entry_id, amt, new_remarks, new_type)
                dlg.destroy()
                if fully_paid:
                    messagebox.showinfo(
                        "Due Cleared",
                        "That correction brought the balance to ₹0 - this due entry has been "
                        "moved to Completed Dues.",
                        parent=self
                    )
                    self._load_dues()
                else:
                    messagebox.showinfo("Success", "Log entry updated successfully!", parent=self)
                    self._refresh_due_and_history(due_id)
            except Exception as e:
                messagebox.showerror("Database Error", f"Failed to update log entry:\n{str(e)}", parent=dlg)

        e_remarks.bind("<Return>", do_save)
        btn_row = ttk.Frame(frm)
        btn_row.pack(fill="x", pady=(6, 0))
        ttk.Button(btn_row, text="💾 Save", style="Success.TButton", command=do_save).pack(side="left")
        ttk.Button(btn_row, text="Cancel", style="Secondary.TButton", command=dlg.destroy).pack(side="left", padx=8)

        e_amount.focus_set()
        e_amount.selection_range(0, "end")


class CompletedDuesWindow(tk.Toplevel):
    """Shows every due that has been fully paid off - customer, contact,
    total amount cleared, when it was opened, when it was completed, and
    the full repayment timeline that led to it - so old dues aren't just
    gone once they're settled, they're still reviewable here."""

    def __init__(self, master):
        super().__init__(master)
        self.title("✅ Completed Dues")
        self.minsize(850, 500)
        apply_theme(self)
        self.transient(master)
        self.grab_set()

        # Set a sane fallback geometry first (centered, capped to the
        # screen) in case maximize isn't supported by the window
        # manager, then open full screen by default - this view showed
        # many columns/details that were getting clipped at the old
        # fixed medium size, so it now always starts maximized. The
        # user can still un-maximize/resize it themselves afterward.
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        win_w = min(1000, sw - 80)
        win_h = min(620, sh - 80)
        px = (sw - win_w) // 2
        py = (sh - win_h) // 2
        self.geometry(f"{win_w}x{win_h}+{max(0, px)}+{max(0, py)}")
        maximize_window(self)
        self.lift()
        self.focus_force()

        title_frame = tk.Frame(self, bg=HEADER_BG, pady=10)
        title_frame.pack(fill="x")
        ttk.Label(title_frame, text="✅ Completed Dues - Fully Paid Customers", font=FONT_BIG,
                  background=HEADER_BG, foreground=HEADER_FG).pack(anchor="center")

        main_paned = ttk.PanedWindow(self, orient="horizontal")
        main_paned.pack(fill="both", expand=True, padx=10, pady=10)

        # ---- Left: list of completed dues ----
        left_frame = ttk.Frame(main_paned, padding=10)
        main_paned.add(left_frame, weight=2)

        search_frame = ttk.Frame(left_frame)
        search_frame.pack(fill="x", pady=(0, 10))
        ttk.Label(search_frame, text="🔍 Search Customer:").pack(side="left", padx=(0, 5))
        self.e_search = ttk.Entry(search_frame, font=("Segoe UI", 10), width=22)
        self.e_search.pack(side="left", padx=5)
        self.e_search.bind("<KeyRelease>", lambda e: self._load_completed(self.e_search.get().strip()))
        ttk.Button(search_frame, text="Clear", command=self._clear_search).pack(side="left", padx=5)

        table_lbl = ttk.Label(left_frame, text="Completed Dues", font=FONT_BOLD)
        table_lbl.pack(anchor="w", pady=(0, 5))

        grid_frame = bordered_table_frame(left_frame)
        cols = ("id", "name", "contact", "total", "opened", "completed")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=16)
        self.tree.heading("id", text="ID")
        self.tree.heading("name", text="Customer Name")
        self.tree.heading("contact", text="Contact")
        self.tree.heading("total", text="Total Cleared")
        self.tree.heading("opened", text="Opened On")
        self.tree.heading("completed", text="Completed On")
        self.tree.column("id", width=45, anchor="center")
        self.tree.column("name", width=160, anchor="w")
        self.tree.column("contact", width=100, anchor="center")
        self.tree.column("total", width=110, anchor="e")
        self.tree.column("opened", width=110, anchor="center")
        self.tree.column("completed", width=110, anchor="center")
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        stripe_treeview(self.tree)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        self.lbl_total = ttk.Label(left_frame, text="Total Completed: 0 due(s), ₹0.00 cleared",
                                    font=("Segoe UI", 11, "bold"), foreground="#166534")
        self.lbl_total.pack(anchor="w", pady=(10, 0))

        # ---- Right: full detail + repayment timeline of selected due ----
        right_frame = ttk.Frame(main_paned, padding=10)
        main_paned.add(right_frame, weight=3)

        self.lbl_detail_name = ttk.Label(right_frame, text="Select a completed due to see details",
                                          font=FONT_BOLD)
        self.lbl_detail_name.pack(anchor="w", pady=(0, 4))
        self.lbl_detail_info = ttk.Label(right_frame, text="", font=("Segoe UI", 10))
        self.lbl_detail_info.pack(anchor="w", pady=(0, 10))

        hist_lbl = ttk.Label(right_frame, text="Full Repayment Timeline", font=FONT_BOLD)
        hist_lbl.pack(anchor="w", pady=(0, 5))

        hist_grid_frame = bordered_table_frame(right_frame)
        hist_cols = ("date", "type", "amount", "remarks")
        self.hist_tree = ttk.Treeview(hist_grid_frame, columns=hist_cols, show="headings", height=18)
        self.hist_tree.heading("date", text="Date")
        self.hist_tree.heading("type", text="Type")
        self.hist_tree.heading("amount", text="Amount")
        self.hist_tree.heading("remarks", text="Remarks / Description")
        self.hist_tree.column("date", width=140, anchor="center")
        self.hist_tree.column("type", width=110, anchor="center")
        self.hist_tree.column("amount", width=110, anchor="e")
        self.hist_tree.column("remarks", width=280, anchor="w")
        self.hist_tree.pack(fill="both", expand=True, side="left")
        hist_scroll = ttk.Scrollbar(hist_grid_frame, orient="vertical", command=self.hist_tree.yview)
        hist_scroll.pack(side="right", fill="y")
        self.hist_tree.configure(yscrollcommand=hist_scroll.set)
        stripe_treeview(self.hist_tree)
        self.hist_tree.tag_configure("due_added", foreground="#b45309")
        self.hist_tree.tag_configure("payment", foreground="#166534")

        self._load_completed()

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self._load_completed()

    def _load_completed(self, search_text=""):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)
        self.lbl_detail_name.configure(text="Select a completed due to see details")
        self.lbl_detail_info.configure(text="")

        try:
            rows = db.get_completed_dues(search_text)
            total_cleared = 0
            for i, (did, name, contact, total, opened_at, completed_at) in enumerate(rows):
                opened_str = opened_at[:10] if opened_at else ""
                completed_str = completed_at[:10] if completed_at else ""
                self.tree.insert(
                    "", "end", iid=str(did),
                    values=(did, name, contact or "-", f"₹{total:,.2f}", opened_str, completed_str),
                    tags=(stripe_tag(i),)
                )
                total_cleared += total
            self.lbl_total.configure(
                text=f"Total Completed: {len(rows)} due(s), ₹{total_cleared:,.2f} cleared"
            )
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load completed dues:\n{str(e)}", parent=self)

    def _on_select(self, event=None):
        selected = self.tree.selection()
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)
        if not selected:
            return
        due_id = int(selected[0])
        item = self.tree.item(selected[0])
        did, name, contact, total, opened_str, completed_str = item["values"]
        self.lbl_detail_name.configure(text=f"{name}  (Due #{did})")
        self.lbl_detail_info.configure(
            text=f"Contact: {contact}    Total Cleared: {total}    "
                 f"Opened: {opened_str}    Completed: {completed_str}"
        )
        try:
            logs = db.get_due_payments(due_id)
            for entry_id, amount, date, remarks, entry_type in logs:
                date_str = date[:16].replace("T", " ") if date else ""
                type_label = "➕ Due Added" if entry_type == "due_added" else "💰 Payment"
                tag = "due_added" if entry_type == "due_added" else "payment"
                self.hist_tree.insert(
                    "", "end", iid=str(entry_id),
                    values=(date_str, type_label, f"₹{amount:,.2f}", remarks or "-"),
                    tags=(tag,)
                )
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load repayment timeline:\n{str(e)}", parent=self)
