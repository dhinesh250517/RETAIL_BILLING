import os
import sys

# Unga project folder path-ah Windows DLL search path-la add pandrom
if getattr(sys, 'frozen', False):
    # Idhu .exe ah maaruna apram work aagurathuku
    os.add_dll_directory(sys._MEIPASS)
else:
    # Idhu ippo VS Code-la run aagurathuku
    os.add_dll_directory(os.path.dirname(os.path.abspath(__file__)))

# Idhuku apram dhaan PIL-ae import aaganum!
from PIL import features
print("Raqm Status:", features.check("raqm"))