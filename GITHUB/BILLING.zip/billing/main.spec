# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[
        ('libraqm-0.dll', '.'),
        ('libfribidi-0.dll', '.'),
        ('libharfbuzz-0.dll', '.')
    ],
    datas=[('assets', 'assets')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='main',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    # upx=True was compressing the raqm/fribidi/harfbuzz .dll files that
    # Pillow bundles for correct Tamil text shaping. UPX is known to
    # corrupt some native DLLs like these - Pillow doesn't crash when
    # that happens, it just silently falls back to NO complex-script
    # shaping at all, which is exactly what produced the broken spacing
    # ("நியூட் ரி சாய் ஸ்" instead of "நியூட்ரி சாய்ஸ்") only in the
    # built .exe and not when running main.py directly (python runs
    # never went through UPX). Turned off so those DLLs reach the exe
    # unmodified and Tamil shaping works the same as it did in testing.
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets\\logo.ico'],
    version='version_info.txt',
)