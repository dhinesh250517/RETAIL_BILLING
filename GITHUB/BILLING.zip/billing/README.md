# Billing Software (Offline)

A fully offline billing app. No internet needed. All data is stored in
one local file: `shop_data.db` (SQLite database) sitting in the same
folder as the program.

The **app itself** is a plain, general-purpose billing tool (title bar
just says "Billing Software"), but every **printed bill / saved PDF**
shows **SAKTHI STORES** at the top - that's set in `printer.py` and
never changes unless you edit it there.

## What's new in this version
- **Total Sales Report -> Export to Excel (GST filing format).** A new
  button on the Total Sales Report tab (Stats) saves that report as a
  real `.xlsx` file, laid out as an invoice-wise Sales Register the way
  an accountant needs it for GST return filing: S.No, Invoice No,
  Invoice Date, Customer Name, Contact, **Taxable Value**, **CGST**,
  **SGST** (GST is split evenly across the two for intra-state sales -
  **IGST** is left at 0 since this is one local shop), Total Invoice
  Value, and Payment Status - with a totals row at the bottom. Needs
  the `openpyxl` package (`pip install -r requirements.txt` picks it
  up); if it's missing, the button just tells you to install it -
  nothing else in the app is affected.
- **Product Stock Entry (new top-bar button).** Search for any existing
  product, select it, and update its **Stock Count**, **Cost Price**,
  and **Selling Price** all in one place. Selling Price here is the
  exact same price used everywhere else in the app (billing screen,
  Products list, receipts), so changing it updates it instantly
  app-wide. Cost Price is used only to work out **profit** in Stats -
  it's never shown or printed on a bill. Opening a product for editing
  pre-fills all three boxes with what was last saved, so you only type
  what actually changed. Every bill sold now automatically reduces that
  product's stock by the qty sold - if stock runs out and selling
  continues anyway, the count simply goes **negative**, no error is
  ever shown. Editing/re-saving a bill correctly adjusts stock (puts
  the old quantities back, then takes out the new ones), so re-editing
  a bill never double-counts stock.
- **Stats -> Profit Report (new tab, password protected).** Shows
  **today's profit** and **this month's profit**, automatically worked
  out from each bill's Selling Price minus Cost Price - nothing to
  type in. Below that, a table lists **every bill's own profit**
  individually. Cost Price is captured automatically at the moment
  each bill is saved (from whatever was last set in Stock Entry), so
  later Cost Price changes never rewrite the profit of old bills. This
  tab is locked behind its own password (default `12345`), which - like
  the other passwords - can be changed any time from **Settings**
  (now a bit bigger to fit the new "Profit Report Pwd" box).
- **Tamil text in PDF bills - fixed for good.** The app now scans your
  PC properly for a Tamil-capable font instead of only checking one or
  two exact filenames (this was the cause of "no Tamil font found" -
  newer Windows versions ship the font as `Nirmala.ttc`, not
  `Nirmala.ttf`, which the old code didn't know to look for). It now
  also checks your personal fonts folder and, as a last resort, scans
  every font installed on the PC and tests each one directly, so it
  works regardless of which exact Tamil font you have. Run
  `pip install -r requirements.txt` again to pick up the extra
  `fonttools` package this uses. See "Tamil text in PDF bills" below.
- **Amount Received / Balance.** Type what the customer physically
  handed over into the new **Amount Received** box (next to Grand
  Total) - the **Balance** updates live: shown in green as change to
  give back if they paid enough, or in red as a **minus (-)** amount
  still due if they paid less than the bill. This is saved with the
  bill and now also printed on the receipt/PDF and shown in Invoices.
- **Bills are now auto-deleted after 3 months** (was 6) to keep the
  list tidy - **Products and Customers are never auto-deleted**, they
  stay forever until you delete them yourself.
- **Keyboard shortcuts**: F2 Save Bill, F3 Print Bill, F4 Save as PDF,
  F5 New Bill, F9 Exit - work from anywhere on the billing screen, in
  addition to clicking the buttons (each button also shows its key).
- **Only one Exit button now** (bottom-right, with the other bill
  actions) instead of two.
- **Printing a bill now automatically clears the screen** and starts a
  fresh bill for the next customer - no extra clicks needed.
- **Scrollbar added to the Current Bill list** on the right, so long
  bills with lots of items are easy to scroll through.
- **Product and Customer popups**: Enter now moves you through every
  box in order, and pressing Enter on the last box saves the record
  (Add New, or Update if that Product ID / selected customer already
  exists) and jumps back to the first box - no mouse needed there
  either.
- **Grand Total** is a plain read-only display (was already a label,
  not a box) so it can never be accidentally typed into; the per-line
  **Total** box now also updates live as soon as you type Qty & Price,
  and stays non-editable (calculated only).
- **Enter now moves you through every box in order**: Customer Name →
  Product ID → Product Name → Qty → Price → (Enter) adds the item and
  jumps back to Product ID for the next one. No mouse needed anywhere
  on the billing screen.
- **Product Name in the billing screen is now editable.** Type a new
  name (or correct an existing one) right there - the moment the item
  is added to the bill it's saved back into your product list
  automatically (same Product ID is fine, it just updates that
  product's saved name/price).
- **Click/select a row in the Current Bill list on the right, then
  press Enter (or double-click it)** - that item comes back into the
  Product Entry boxes on the left so you can fix the qty/price/name,
  then Enter adds it back in, updated.
- Bigger fonts and bigger entry boxes throughout the billing screen,
  with more breathing room, plus a "Quick Tips" panel that fills what
  used to be empty space and reminds you of the keyboard shortcuts.
- More colorful, varied buttons (Products/Customers/Invoices/Add Item
  each have their own icon + color) so the screen is easier to scan.
- Colorful, modern-looking screens with icons on every button.
- Product entry is **one single line**: Product ID → Product Name →
  Qty → Price → Total (type the name however you want it printed,
  Tamil or English, directly).
- Stock-count box removed from the product form (kept quietly in the
  database in case you want it back later, but not shown anywhere).
- Every popup suggestion list (Customer Name, Product ID) is fully
  keyboard-operable: type to search, **↑ / ↓** to move, **Enter** to
  pick - no mouse needed.
- Product and Customer manager windows have a **search box** at the
  top to instantly find and edit any record.
- **Print Bill** automatically saves the bill first if it hasn't been
  saved yet - no extra prompt.
- **Save as PDF** button - saves the bill as a real `.pdf` file you
  choose the name/location for.
- **Invoices**: click a bill, then "Open in Billing (Edit)" (or just
  double-click it) - it loads straight back into the billing screen so
  you can add more products or fix anything, then Save again updates
  that same bill (it won't create a duplicate).
- An optional **GST** section (checkbox + %) sits in the billing
  screen for later use - leave it unchecked and it does nothing.

## Files in this folder
- `main.py` – start the program from here
- `database.py` – all data storage (products, customers, bills)
- `billing_app.py` – the main billing screen
- `product_manager.py` – Add/Edit/Delete product popup
- `customer_manager.py` – Add/Edit/Delete customer popup
- `invoice_viewer.py` – view all past bills, open one for editing
- `printer.py` – formats the receipt, prints it, and saves it as PDF
- `ui_theme.py` – shared colors/fonts/icons for a consistent look
- `autocomplete.py` – the keyboard-navigable suggestion popup
- `shop_data.db` – created automatically the first time you run it
  (this is your entire database)

## How to run (any Windows PC)

### Option A – Run with Python installed
1. Install Python 3.10+ from python.org (tick "Add to PATH" during install).
2. Open Command Prompt in this folder and run once:
   ```
   pip install -r requirements.txt
   ```
   (`pywin32` lets the program talk directly to your thermal printer;
   `reportlab` + `pillow` are needed for Tamil text to show correctly
   in saved PDF bills - see "Tamil text in PDF bills" below. The app
   still runs without them, it just falls back to English-only PDFs
   and a text-file print preview.)
3. Start the app:
   ```
   python main.py
   ```

### Option B – Turn it into a single .exe (recommended for the shop PC)
This way your PC doesn't need Python installed at all - perfect for
copying to a pendrive and running on any computer.

1. On any PC with Python installed, open this folder in Command Prompt and run:
   ```
   pip install pyinstaller pywin32 reportlab pillow
   pyinstaller --onefile --noconsole --name BillingSoftware main.py
   ```
   If you're using a custom font in a `fonts` folder (see "Tamil text
   in PDF bills" below), copy that `fonts` folder next to the finished
   `BillingSoftware.exe` too.
2. PyInstaller creates a `dist` folder containing `BillingSoftware.exe`.
3. Copy `BillingSoftware.exe` to a fresh folder - this .exe is now
   self-contained.
4. Copy that whole folder to a pendrive. Plug it into any Windows PC
   and double-click `BillingSoftware.exe` - it runs immediately, no
   install needed.
5. The first time it runs on a PC, it creates `shop_data.db` next to
   the .exe. **That single file is your entire product/customer/bill
   database.**

## Moving / backing up your data
- Just copy the **whole folder** (exe + `shop_data.db`) to a pendrive.
- Paste it on the new PC and run the .exe from there - all your data
  comes with it.
- To back up, simply copy `shop_data.db` somewhere safe regularly.

## How the software works

**Top bar**
- **Products** – opens a popup to manage products: Product ID, Product
  Name (type it in Tamil or English, whatever you want on the bill),
  Price, and an optional GST % (leave as 0 if you're not using it). A
  search box on top finds any product instantly. Products are never
  auto-deleted - they stay until you delete them yourself.
- **Customers** – opens a popup to manage customers: Name, Contact,
  Address, with the same search box. Also never auto-deleted.
- **Invoices** – shows every bill from the last 3 months (older bills
  are automatically cleared out to keep the list tidy). Click a bill
  and press "Open in Billing (Edit)" (or double-click it) to bring it
  back into the billing screen, change anything, and Save again -
  it updates that same bill.
- **New Bill (F5)** – clears the screen to start a fresh bill.

**Left side (entry area)**
- Type in the **Customer Name** box - matching customers pop up; use
  ↑ / ↓ and Enter (or click) to pick one; Contact/Address fill in.
- Type in the **Product ID** box - matching products pop up the same
  way. Pick one and the Name and Price fill in (Name can't be edited
  here; Price can be corrected if needed).
- Type the **Qty** and press **Enter** to add the item to the bill.
- Optionally tick **Apply GST** and set a %, if you ever want to use it.
- Choose **Paid / Not Paid**.

**Right side (current bill)**
- **Bill No** and **Grand Total** shown large on top.
- **Amount Received** box - type what the customer handed over and
  **Balance** updates live: green = change to give back, red minus
  (-) = amount still due (they paid less than the bill).
- Table lists S.No, Product Name, Count, Price, Total for each item,
  with a scrollbar for long bills.
- **Save Bill (F2)** – writes the bill to the database.
- **Print Bill (F3)** – saves automatically if needed, prints a
  formatted receipt (SAKTHI STORES, phone, address, items, total,
  amount received/balance) to your default 3-inch thermal printer,
  then automatically clears the screen for the next bill. If no
  thermal printer is set up, it saves a text preview instead
  (`last_receipt_preview.txt`).
- **Save as PDF (F4)** – saves automatically if needed, then lets you
  pick a filename/location to save the bill as a real PDF file.
- **Exit (F9)** – closes the program. (There's only the one Exit
  button now, next to Save/Print/PDF.)

## Thermal printer setup notes
- Most 3-inch (58mm) receipt printers install on Windows as a normal
  printer (via USB). Set it as your **default printer** in Windows
  Settings → Printers, and the app will send bills to it directly.
- The receipt is formatted for 32 characters per line, which fits
  standard 58mm thermal paper. If your printer uses 80mm paper instead,
  tell me and I'll widen the layout.

## Tamil text in PDF bills
Saved PDF bills (`Save as PDF`) show real Tamil letters, using
**NIRMALA** - the Tamil-capable font Windows itself ships with on
every Windows 8/10/11 PC. This app does NOT bundle its own font file
anymore; it simply uses Nirmala directly, so there's nothing extra to
download or carry inside the .exe:
- The app checks the usual Windows locations for Nirmala first
  (including `Nirmala.ttc`, the file name used on newer Windows 10/11
  PCs - older versions of this app only looked for `Nirmala.ttf`,
  which is why some PCs showed "no Tamil font found" even though
  Tamil text was typed correctly), falling back to Latha/Vijaya (older
  Windows Tamil fonts) only if Nirmala truly isn't present. This
  normally just works with no extra steps, as long as
  `pip install -r requirements.txt` was run (see install steps above)
  - that installs `reportlab`, `pillow`, and `fonttools`, which this
    detection uses.
- If truly no Tamil-capable font is found on the PC at all, the PDF
  still saves fine, but Tamil letters show as `?` in that PDF only
  (nothing else is affected) - the app tells you this in the "Saved"
  popup when it happens. In that rare case you can still drop any
  Tamil `.ttf` font into a `fonts` folder next to `main.py` /
  `BillingSoftware.exe` and name it `tamil_font.ttf`, and the app will
  use it automatically - see the comments in `printer.py` /
  `_find_tamil_font()`.
- **Important - Tamil "shaping" note:** correctly drawing Tamil
  (getting vowel signs like the one in "மேரி" in the right visual
  order, no stray gaps in words like "நியூட்ரி") needs Pillow's
  `raqm` text-shaping engine, not just "having a Tamil font". This is
  a Pillow/OS-level thing, independent of WHICH font is used - Nirmala
  does not fix a missing-`raqm` PC any more than any other font would.
  If a bill's Tamil looks like letters are in the wrong order or have
  odd gaps, and the Print/Save popup shows a "⚠ Tamil text shaping
  engine (raqm) not detected" warning, the fix is
  `pip install --upgrade pillow` (and, if you build a .exe, making
  sure PyInstaller/UPX isn't stripping Pillow's bundled raqm/harfbuzz
  DLLs - `main.spec` already sets `upx=False` for this reason).
- The printed thermal receipt and the on-screen bill are never
  affected by any of this either way.

## Customizing shop details (what shows on the printed/PDF bill)
Set at the top of `printer.py`:
```python
SHOP_NAME = "SAKTHI STORES"
SHOP_PHONE = "Ph: 9944993944"
SHOP_ADDRESS = "Bhuvanagiri"
```
Change these any time and rebuild the .exe (or just re-run
`python main.py` if using Option A). This is separate from the app's
own window title, which stays generic.

## Machine-lock license (anti-piracy)

This copy has a hardware-lock license added (`license_lock.py`, hooked
into `main.py`). Read the big comment at the top of `license_lock.py`
for full details. Short version:

- **Before shipping**: open `license_lock.py` and change the `SECRET`
  value to your own random string. Keep `license_lock.py`'s SECRET and
  `keygen.py` private - never put them on a customer's pendrive.
- **Build the exe as usual** (`pyinstaller main.spec`) and give the
  customer the exe + `shop_data.db` as before.
- **First run on a new PC**: the app shows a "Machine Code" and asks
  for a "License Key". Get the Machine Code from the customer, run
  `python keygen.py` on your own PC to turn it into a License Key,
  and send that back. They type it in once and it's saved outside the
  app folder (so it doesn't travel with pendrive copies).
- If someone copies the whole exe+db folder to a different PC, that
  PC will show the activation screen again instead of opening
  normally - the old license key won't match the new machine.
