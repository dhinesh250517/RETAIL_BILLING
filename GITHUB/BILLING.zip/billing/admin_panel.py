"""
admin_panel.py
--------------
Admin panel window (secret area) accessible by entering "DHINESH"
in the GST % entry box. Allows backing up/restoring the database
and deleting all customers, products, or bills. Fully scrollable.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import shutil
import os

import database as db
import license_lock
from ui_theme import apply_theme, ICON, FONT_BOLD, FONT_BIG


class AdminPanelWindow(tk.Toplevel):
    def __init__(self, master, on_change=None):
        super().__init__(master)
        self.title("🛠️ Admin Control Center (Secret Area)")
        self.geometry("540x560")
        apply_theme(self)
        self.on_change = on_change
        self.grab_set()  # Modal dialog

        # --- Create Scrollable Container ---
        # Using a Canvas + Scrollbar to make the window scrollable
        self.canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0, bg=self.cget("bg"))
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.container = ttk.Frame(self.canvas)

        self.container.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.container, anchor="nw")
        
        # Ensure the scrollable frame stretches to fill the canvas width
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )

        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        # Mouse wheel scrolling support
        def _on_mousewheel(event):
            # Only scroll if the canvas exists and is active
            try:
                self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            except Exception:
                pass

        self.canvas.bind_all("<MouseWheel>", _on_mousewheel)
        self.bind("<Destroy>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

        # --- Title Label ---
        title_frame = ttk.Frame(self.container, padding=15)
        title_frame.pack(fill="x")
        ttk.Label(title_frame, text="🛠️ Admin Control Center", font=FONT_BIG, foreground="#dc2626").pack(anchor="center")
        ttk.Label(title_frame, text="Secret Area - Use with caution!", font=("Segoe UI", 10, "italic"), foreground="#475569").pack(anchor="center")

        # --- License & Security (Owner Only) ---
        # Revoke / change-password actions here are behind a SEPARATE
        # admin password (not the "type DHINESH in GST box" trick that
        # gets you into this window in the first place) - that trick is
        # baked into every copy of the app and could leak, but the admin
        # password is stored per-installation in this shop's own
        # database, so it's a second, owner-only gate over the sensitive
        # actions specifically.
        lic_frame = ttk.LabelFrame(self.container, text=" 🔑 License & Security (Owner Only) ", padding=15)
        lic_frame.pack(fill="x", padx=15, pady=10)

        self.lbl_machine = ttk.Label(lic_frame, text="Machine Code: -", font=FONT_BOLD)
        self.lbl_machine.pack(anchor="w", pady=3)

        self.lbl_lic_status = ttk.Label(lic_frame, text="License: -", font=FONT_BOLD)
        self.lbl_lic_status.pack(anchor="w", pady=3)

        lic_btns = ttk.Frame(lic_frame)
        lic_btns.pack(fill="x", pady=(8, 0))
        ttk.Button(lic_btns, text="🔒 Revoke License (Lock This PC Now)", style="Danger.TButton",
                   command=self.revoke_license).pack(side="left", padx=4)
        ttk.Button(lic_btns, text="🔑 Change Admin Password", style="Secondary.TButton",
                   command=self.change_admin_password).pack(side="left", padx=4)

        self.refresh_license_info()

        # --- Stats Frame ---
        stats_lbl_frame = ttk.LabelFrame(self.container, text=" Database Statistics ", padding=15)
        stats_lbl_frame.pack(fill="x", padx=15, pady=10)

        self.lbl_cust = ttk.Label(stats_lbl_frame, text="Total Customers: -", font=FONT_BOLD)
        self.lbl_cust.pack(anchor="w", pady=4)

        self.lbl_prod = ttk.Label(stats_lbl_frame, text="Total Products: -", font=FONT_BOLD)
        self.lbl_prod.pack(anchor="w", pady=4)

        self.lbl_bills = ttk.Label(stats_lbl_frame, text="Total Bills: -", font=FONT_BOLD)
        self.lbl_bills.pack(anchor="w", pady=4)

        self.lbl_dues = ttk.Label(stats_lbl_frame, text="Pending Dues: -", font=FONT_BOLD)
        self.lbl_dues.pack(anchor="w", pady=4)

        # --- Actions Frame ---
        actions_frame = ttk.LabelFrame(self.container, text=" Control Actions ", padding=15)
        actions_frame.pack(fill="both", expand=True, padx=15, pady=10)

        # Row 0: Backup Products / Restore Products - a standalone
        # products-only backup (no customers/bills/dues data mixed in),
        # separate from the full database backup below.
        ttk.Button(actions_frame, text=f"{ICON['product']} Backup Products", style="Success.TButton",
                   command=self.backup_products).grid(row=0, column=0, sticky="ew", pady=6, padx=5)

        ttk.Button(actions_frame, text=f"{ICON['back']} Restore Products", style="Primary.TButton",
                   command=self.restore_products).grid(row=0, column=1, sticky="ew", pady=6, padx=5)

        # Row 1: Backup Database / Restore Database (everything)
        ttk.Button(actions_frame, text=f"{ICON['save']} Backup Database", style="Success.TButton",
                   command=self.backup_db).grid(row=1, column=0, sticky="ew", pady=6, padx=5)

        ttk.Button(actions_frame, text=f"{ICON['back']} Restore Database", style="Primary.TButton",
                   command=self.restore_db).grid(row=1, column=1, sticky="ew", pady=6, padx=5)

        # Row 2: Delete Customers / Delete Products
        ttk.Button(actions_frame, text=f"{ICON['delete']} Delete All Customers", style="Danger.TButton",
                   command=self.delete_customers).grid(row=2, column=0, sticky="ew", pady=6, padx=5)

        ttk.Button(actions_frame, text=f"{ICON['delete']} Delete All Products", style="Danger.TButton",
                   command=self.delete_products).grid(row=2, column=1, sticky="ew", pady=6, padx=5)

        # Row 3: Delete Bills
        ttk.Button(actions_frame, text=f"{ICON['delete']} Delete All Bills", style="Danger.TButton",
                   command=self.delete_bills).grid(row=3, column=0, columnspan=2, sticky="ew", pady=6, padx=5)

        # Row 4: Delete Dues
        ttk.Button(actions_frame, text=f"{ICON['delete']} Delete All Dues", style="Danger.TButton",
                   command=self.delete_dues).grid(row=4, column=0, columnspan=2, sticky="ew", pady=6, padx=5)

        # Row 5: Reset everything (customers + products + bills + dues +
        # shop name/address/phone) in one go - for reusing this install
        # of the app for a completely different shop.
        ttk.Separator(actions_frame, orient="horizontal").grid(row=5, column=0, columnspan=2, sticky="ew", pady=(10, 6))

        ttk.Button(actions_frame, text=f"{ICON['delete']} DELETE ALL DATA (Reset for New Shop)", style="Danger.TButton",
                   command=self.reset_everything).grid(row=6, column=0, columnspan=2, sticky="ew", pady=6, padx=5)

        actions_frame.columnconfigure(0, weight=1)
        actions_frame.columnconfigure(1, weight=1)

        self.refresh_stats()

    def refresh_license_info(self):
        try:
            code = license_lock.get_machine_fingerprint()
            self.lbl_machine.configure(text=f"Machine Code: {code}")
            status = license_lock.get_saved_license_status()
            if not status:
                self.lbl_lic_status.configure(text="License: not activated", foreground="#dc2626")
            elif status["kind"] == "permanent":
                self.lbl_lic_status.configure(text="License: Permanent (never expires)", foreground="#16a34a")
            else:
                expiry_text = status["expiry"].strftime("%d-%m-%Y")
                if status["expired"]:
                    self.lbl_lic_status.configure(text=f"License: Subscription - EXPIRED on {expiry_text}", foreground="#dc2626")
                else:
                    self.lbl_lic_status.configure(
                        text=f"License: Subscription - expires {expiry_text} ({status['days_left']} day(s) left)",
                        foreground="#334155",
                    )
        except Exception as e:
            self.lbl_lic_status.configure(text=f"License: error reading status ({e})", foreground="#dc2626")

    def _ask_admin_password(self):
        """Second, owner-only gate for sensitive license actions. Stored
        per-installation in this shop's own database (pwd_admin), so it's
        independent of the 'DHINESH' trick used to reach this window."""
        pwd = simpledialog.askstring("Admin Password", "Enter admin password:", show="*", parent=self)
        if pwd is None:
            return False
        saved = db.get_setting("pwd_admin", "ADMIN@2026")
        if pwd != saved:
            messagebox.showerror("Error", "Incorrect admin password.", parent=self)
            return False
        return True

    def revoke_license(self):
        if not self._ask_admin_password():
            return
        if not messagebox.askyesno(
            "Confirm Revoke",
            "This immediately locks THIS PC - the app will require a new "
            "License Key to reopen. Continue?",
            parent=self,
        ):
            return
        license_lock.revoke_activation()
        messagebox.showinfo(
            "License Revoked",
            "License revoked on this PC. The app will now close and will "
            "ask for a new License Key the next time it's opened.",
            parent=self,
        )
        # Close the whole app right away so the lock takes effect immediately.
        self.master.destroy()

    def change_admin_password(self):
        if not self._ask_admin_password():
            return
        new1 = simpledialog.askstring("New Admin Password", "Enter NEW admin password:", show="*", parent=self)
        if not new1:
            return
        new2 = simpledialog.askstring("Confirm New Password", "Re-enter NEW admin password:", show="*", parent=self)
        if new1 != new2:
            messagebox.showerror("Error", "Passwords didn't match. Nothing changed.", parent=self)
            return
        db.save_setting("pwd_admin", new1)
        messagebox.showinfo("Success", "Admin password changed for this installation.", parent=self)

    def refresh_stats(self):
        try:
            stats = db.get_db_stats()
            self.lbl_cust.configure(text=f"Total Customers: {stats['customers']}")
            self.lbl_prod.configure(text=f"Total Products: {stats['products']}")
            self.lbl_bills.configure(text=f"Total Bills: {stats['bills']}")
            self.lbl_dues.configure(text=f"Pending Dues: {stats['dues_count']} entries (₹{stats['dues_sum']:,.2f})")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load statistics:\n{str(e)}", parent=self)

    def delete_customers(self):
        if not messagebox.askyesno("CONFIRM DELETION", "Are you sure you want to delete ALL customers?\nThis action CANNOT be undone!", parent=self):
            return
        if not messagebox.askyesno("FINAL WARNING", "Do you really want to delete ALL customers? All bills will lose their link to these customers.", parent=self):
            return

        try:
            db.delete_all_customers()
            messagebox.showinfo("Success", "All customers deleted successfully!", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete customers:\n{str(e)}", parent=self)

    def delete_products(self):
        if not messagebox.askyesno("CONFIRM DELETION", "Are you sure you want to delete ALL products?\nThis action CANNOT be undone!", parent=self):
            return
        if not messagebox.askyesno("FINAL WARNING", "Do you really want to delete ALL products? This clears your entire inventory list.", parent=self):
            return

        try:
            db.delete_all_products()
            messagebox.showinfo("Success", "All products deleted successfully!", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete products:\n{str(e)}", parent=self)

    def delete_bills(self):
        if not messagebox.askyesno("CONFIRM DELETION", "Are you sure you want to delete ALL bills and transaction history?\nThis action CANNOT be undone!", parent=self):
            return
        if not messagebox.askyesno("FINAL WARNING", "Do you really want to delete ALL bills? All invoices and bills will be permanently erased.", parent=self):
            return

        try:
            db.delete_all_bills()
            messagebox.showinfo("Success", "All bills deleted successfully!", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete bills:\n{str(e)}", parent=self)

    def delete_dues(self):
        if not messagebox.askyesno("CONFIRM DELETION", "Are you sure you want to delete ALL customer dues and payment ledger history?\nThis action CANNOT be undone!", parent=self):
            return
        if not messagebox.askyesno("FINAL WARNING", "Do you really want to delete ALL customer dues? All credits and repayment logs will be permanently erased.", parent=self):
            return

        try:
            db.delete_all_dues()
            messagebox.showinfo("Success", "All customer dues and logs deleted successfully!", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete dues:\n{str(e)}", parent=self)

    def reset_everything(self):
        """Wipes customers, products, bills, dues, and shop settings all at
        once - for handing this same app installation over to a different
        shop. Guarded with a typed confirmation since it cannot be undone."""
        if not messagebox.askyesno(
            "CONFIRM FULL RESET",
            "This will permanently delete EVERYTHING in this app:\n\n"
            "• All customers\n• All products & stock\n• All bills\n"
            "• All customer dues & payment history\n• Shop name/address/phone\n\n"
            "This CANNOT be undone. Continue?",
            parent=self
        ):
            return

        answer = simpledialog.askstring(
            "FINAL CONFIRMATION",
            "Type DELETE ALL (in capitals) to confirm you want to erase everything:",
            parent=self
        )
        if answer != "DELETE ALL":
            messagebox.showinfo("Cancelled", "Reset cancelled - no data was deleted.", parent=self)
            return

        try:
            db.reset_everything()
            messagebox.showinfo(
                "Success",
                "All data has been erased. This app is now a clean slate.\n\n"
                "Please set up the shop name, address, and phone number again "
                "before billing for the new shop.",
                parent=self
            )
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to reset data:\n{str(e)}", parent=self)

    def backup_products(self):
        """Saves ONLY the products table (ID, name, stock, price, GST %,
        cost price) to a JSON file - no customers, bills, or dues data
        included at all. Kept separate from the full database backup
        below for exactly that reason."""
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Backup Products",
            defaultextension=".json",
            filetypes=[("Products Backup", "*.json")],
            initialfile="products_backup.json"
        )
        if not path:
            return
        try:
            count = db.export_products_to_file(path)
            messagebox.showinfo("Success", f"{count} product(s) backed up successfully to:\n{path}", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to backup products:\n{str(e)}", parent=self)

    def restore_products(self):
        """Restores products from a Backup Products JSON file. Replaces
        the current product list entirely - customers, bills, and dues
        are completely untouched."""
        path = filedialog.askopenfilename(
            parent=self,
            title="Restore Products",
            filetypes=[("Products Backup", "*.json")]
        )
        if not path:
            return

        if not messagebox.askyesno(
            "Warning",
            "Restoring products will REPLACE the current product list with "
            "what's in this file. Customers, bills, and dues are not "
            "affected. Are you sure you want to proceed?",
            parent=self
        ):
            return

        try:
            count = db.import_products_from_file(path)
            messagebox.showinfo("Success", f"{count} product(s) restored successfully!", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to restore products:\n{str(e)}", parent=self)

    def backup_db(self):
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Backup Database",
            defaultextension=".db",
            filetypes=[("Database Files", "*.db")],
            initialfile="shop_data_backup.db"
        )
        if not path:
            return
        try:
            shutil.copy2(db.DB_FILE, path)
            messagebox.showinfo("Success", f"Database backed up successfully to:\n{path}", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to backup database:\n{str(e)}", parent=self)

    def restore_db(self):
        path = filedialog.askopenfilename(
            parent=self,
            title="Restore Database",
            filetypes=[("Database Files", "*.db")]
        )
        if not path:
            return

        if not messagebox.askyesno("Warning", "Restoring a database will OVERWRITE all current data. Are you sure you want to proceed?", parent=self):
            return

        try:
            shutil.copy2(path, db.DB_FILE)
            messagebox.showinfo("Success", "Database restored successfully! Please restart the application to reload the restored data.", parent=self)
            self.refresh_stats()
            if self.on_change:
                self.on_change()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to restore database:\n{str(e)}", parent=self)

