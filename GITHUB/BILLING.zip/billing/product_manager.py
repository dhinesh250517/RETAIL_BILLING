"""
product_manager.py
-------------------
Popup window to Add / Edit / Delete products.
Fields: Product ID, Product Name (type it directly in Tamil or
English - whatever you want printed on the bill), Price, and an
optional GST % (kept for later use, leave as 0 if you don't use GST).

A search box at the top lets you find and edit any product quickly,
and the table itself is fully keyboard-navigable (Up/Down arrows +
Enter) - no mouse required.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import database as db
from ui_theme import apply_theme, ICON, FONT_BOLD, stripe_treeview, stripe_tag, bordered_table_frame, open_like_invoice


class ProductManagerWindow(tk.Toplevel):
    def __init__(self, master, on_change=None, initial_pid=None, initial_name=None, initial_price=None):
        super().__init__(master)
        self.title(f"{ICON['product']} Manage Products")
        self.configure(bg="#eef2f7")
        apply_theme(self)
        # Opens at a smaller, roughly-square size (not full-screen) - use
        # the window's own maximize button any time you want it bigger.
        open_like_invoice(self)
        # Keep this window tied to the main billing window in the stacking
        # order (transient), so when a Yes/No confirm popup (e.g. on
        # Delete) opens and closes, this window comes back on TOP of the
        # main window instead of slipping behind it.
        self.transient(master)
        self.lift()
        self.focus_force()
        self.on_change = on_change  # callback to refresh main billing screen

        form = ttk.Frame(self, padding=12)
        form.pack(fill="x")

        ttk.Label(form, text="Product ID").grid(row=0, column=0, sticky="w", pady=4)
        self.e_id = ttk.Entry(form, width=18, font=("Segoe UI", 10))
        self.e_id.grid(row=0, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Product Name (Tamil or English)").grid(row=0, column=2, sticky="w", pady=4, padx=(20, 0))
        self.e_name = ttk.Entry(form, width=28, font=("Segoe UI", 11))
        self.e_name.grid(row=0, column=3, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Price ₹").grid(row=1, column=0, sticky="w", pady=4)
        self.e_price = ttk.Entry(form, width=18, font=("Segoe UI", 10))
        self.e_price.grid(row=1, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text=f"GST {ICON['gst']} (optional, later use)").grid(row=1, column=2, sticky="w", pady=4, padx=(20, 0))
        self.e_gst = ttk.Entry(form, width=10, font=("Segoe UI", 10))
        self.e_gst.insert(0, "0")
        self.e_gst.grid(row=1, column=3, sticky="w", pady=4, padx=4)

        # ---- Stock Count and Cost Price: only used when adding a BRAND
        # NEW product for the very first time. Once a product exists,
        # these two fields are locked here - use the Stock Entry (📦
        # Stock) screen to update stock/cost price/selling price from
        # then on, so there's only one place stock ever gets changed. ----
        ttk.Label(form, text="Initial Stock Count").grid(row=2, column=0, sticky="w", pady=4)
        self.e_stock = ttk.Entry(form, width=18, font=("Segoe UI", 10))
        self.e_stock.insert(0, "0")
        self.e_stock.grid(row=2, column=1, sticky="w", pady=4, padx=4)

        ttk.Label(form, text="Cost Price ₹ (buying price)").grid(row=2, column=2, sticky="w", pady=4, padx=(20, 0))
        self.e_cost = ttk.Entry(form, width=18, font=("Segoe UI", 10))
        self.e_cost.insert(0, "0")
        self.e_cost.grid(row=2, column=3, sticky="w", pady=4, padx=4)

        note = ttk.Label(
            form,
            text="Note: Stock Count & Cost Price above are for NEW products only. "
                 "To update stock/cost price/selling price of an existing product, "
                 "use the 📦 Stock button on the main billing screen instead.",
            font=("Segoe UI", 9, "italic"), foreground="#64748b", wraplength=560, justify="left"
        )
        note.grid(row=3, column=0, columnspan=4, sticky="w", pady=(2, 0))

        # ---- Enter moves through the fields in order; Enter on the last
        # field (GST) saves the record - Add New for a fresh Product ID,
        # or Update Selected if a row is currently selected in the table
        # below. No mouse needed to add/edit a product. ----
        self.e_id.bind("<Return>", self._goto(lambda: self.e_name))
        self.e_name.bind("<Return>", self._goto(lambda: self.e_price))
        self.e_price.bind("<Return>", self._goto(lambda: self.e_gst))
        self.e_gst.bind("<Return>", self._goto(lambda: self.e_stock))
        self.e_stock.bind("<Return>", self._goto(lambda: self.e_cost))
        self.e_cost.bind("<Return>", self._submit_on_enter)

        btns = ttk.Frame(form)
        btns.grid(row=4, column=0, columnspan=4, pady=12, sticky="w")
        ttk.Button(btns, text=f"{ICON['add']} Add New", style="Success.TButton",
                   command=self.add_product).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['update']} Update Selected", style="Primary.TButton",
                   command=self.update_product).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['delete']} Delete Selected", style="Danger.TButton",
                   command=self.delete_product).pack(side="left", padx=4)
        ttk.Button(btns, text=f"{ICON['clear']} Clear", style="Secondary.TButton",
                   command=self.clear_form).pack(side="left", padx=4)

        # ---- search bar ----
        search_frame = ttk.Frame(self, padding=(12, 0))
        search_frame.pack(fill="x")
        ttk.Label(search_frame, text=f"{ICON['search']} Search:", font=FONT_BOLD).pack(side="left")
        self.e_search = ttk.Entry(search_frame, width=40, font=("Segoe UI", 10))
        self.e_search.pack(side="left", padx=8)
        self.e_search.bind("<KeyRelease>", lambda e: self.refresh_table())
        ttk.Button(search_frame, text="Clear Search", style="Secondary.TButton",
                   command=self._clear_search).pack(side="left")

        # Table of existing products
        table_frame = ttk.Frame(self, padding=12)
        table_frame.pack(fill="both", expand=True)

        grid_frame = bordered_table_frame(table_frame)

        cols = ("id", "name", "price", "gst")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=14)
        headings = {"id": "Product ID", "name": "Product Name", "price": "Price", "gst": "GST %"}
        widths = {"id": 120, "name": 300, "price": 100, "gst": 80}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c])
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Return>", self.on_select)
        stripe_treeview(self.tree)

        self.refresh_table()

        if initial_pid:
            # Opened from the billing screen for a Product ID that
            # doesn't exist yet - prefill what was already typed there
            # (ID/Name/Price) and send focus straight to Stock Count,
            # since that's the one thing the billing screen can't supply.
            self.e_id.insert(0, initial_pid)
            if initial_name:
                self.e_name.insert(0, initial_name)
            if initial_price is not None:
                self.e_price.delete(0, "end")
                self.e_price.insert(0, f"{initial_price:g}")
            self.e_stock.focus_set()
            self.e_stock.selection_range(0, "end")
        else:
            self.e_id.focus_set()

    # ---- helper: Enter key moves focus to the next box and selects its text ----
    def _goto(self, widget_getter):
        def handler(event=None):
            widget = widget_getter()
            widget.focus_set()
            try:
                widget.selection_range(0, "end")
            except Exception:
                pass
            return "break"
        return handler

    def _submit_on_enter(self, event=None):
        """Enter on the last field (GST) saves the record: Update if this
        Product ID already exists in the list, otherwise Add New - then
        jumps back to Product ID for the next one."""
        pid = self.e_id.get().strip()
        if pid and db.get_product(pid):
            self.update_product()
        else:
            self.add_product()
        self.e_id.focus_set()
        return "break"

    def _clear_search(self):
        self.e_search.delete(0, "end")
        self.refresh_table()

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        text = self.e_search.get().strip()
        rows = db.search_products(text) if text else db.get_all_products()
        for i, p in enumerate(rows):
            pid, name, price, gst = p
            self.tree.insert("", "end", values=(pid, name, f"{price:.2f}", f"{gst:g}"), tags=(stripe_tag(i),))

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        self.clear_form()
        self.e_id.insert(0, vals[0])
        self.e_name.insert(0, vals[1])
        self.e_price.insert(0, vals[2])
        self.e_gst.delete(0, "end")
        self.e_gst.insert(0, vals[3])

        # Existing product selected: Stock/Cost Price are managed only
        # from the 📦 Stock screen from here on, so lock them here.
        self.e_stock.delete(0, "end")
        self.e_stock.insert(0, "-")
        self.e_stock.configure(state="disabled")
        self.e_cost.delete(0, "end")
        self.e_cost.insert(0, "-")
        self.e_cost.configure(state="disabled")

    def clear_form(self):
        for e in (self.e_id, self.e_name, self.e_price):
            e.delete(0, "end")
        self.e_gst.delete(0, "end")
        self.e_gst.insert(0, "0")
        # Re-enable Stock/Cost Price for entering a brand new product.
        self.e_stock.configure(state="normal")
        self.e_stock.delete(0, "end")
        self.e_stock.insert(0, "0")
        self.e_cost.configure(state="normal")
        self.e_cost.delete(0, "end")
        self.e_cost.insert(0, "0")

    def _read_form(self):
        pid = self.e_id.get().strip()
        name = self.e_name.get().strip()
        price = self.e_price.get().strip() or "0"
        gst = self.e_gst.get().strip() or "0"
        if not pid or not name:
            messagebox.showerror("Missing info", "Product ID and Product Name are required.", parent=self)
            return None
        try:
            price = float(price)
            gst = float(gst)
        except ValueError:
            messagebox.showerror("Invalid number", "Price and GST must be numbers.", parent=self)
            return None
        return pid, name, price, gst

    def add_product(self):
        data = self._read_form()
        if not data:
            return
        pid, name, price, gst = data
        existing = db.get_product_by_name(name)
        if existing and existing[0] != pid:
            messagebox.showwarning("Product already exists", f"{name}", parent=self)
            return
        stock_text = self.e_stock.get().strip() or "0"
        cost_text = self.e_cost.get().strip() or "0"
        try:
            stock = float(stock_text)
            cost_price = float(cost_text)
        except ValueError:
            messagebox.showerror("Invalid number", "Initial Stock Count and Cost Price must be numbers.", parent=self)
            return
        try:
            db.add_product(pid, name, price, gst, cost_price=cost_price, stock=stock)
        except Exception as e:
            messagebox.showerror("Error", f"Could not add product (maybe ID already exists).\n{e}", parent=self)
            return
        self.refresh_table()
        self.clear_form()
        if self.on_change:
            self.on_change()

    def update_product(self):
        data = self._read_form()
        if not data:
            return
        pid, name, price, gst = data
        db.update_product(pid, name, price, gst)
        self.refresh_table()
        self.clear_form()
        if self.on_change:
            self.on_change()

    def delete_product(self):
        pid = self.e_id.get().strip()
        if not pid:
            messagebox.showerror("Missing info", "Select or type a Product ID to delete.", parent=self)
            self.lift()
            self.focus_force()
            return
        answer = messagebox.askyesno("Confirm", f"Delete product '{pid}'?", parent=self)
        # Bring this window back to the front no matter what was chosen,
        # since the confirm popup can otherwise leave the main billing
        # window on top of this one.
        self.lift()
        self.focus_force()
        if answer:
            db.delete_product(pid)
            self.refresh_table()
            self.clear_form()
            if self.on_change:
                self.on_change()
